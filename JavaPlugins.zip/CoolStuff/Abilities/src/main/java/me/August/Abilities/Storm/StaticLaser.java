package me.August.Abilities.Storm;

import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Firework;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class StaticLaser extends Skill {

	BukkitTask charge = null;
	int time = 0;
	double power = 0;
	
	public StaticLaser(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		if (power < 100)
			player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.3F, (float) (0.5 + (power/100)));
		if (charge == null)
		{
			time = 5;
			charge = new BukkitRunnable()
			{
				Location loc;
				@Override
				public void run()
				{
					time--;
					if (power >= 100)
						power = 100;
					else
						power = power + 1.8 + 0.2 * level;
					displayChargeBar(power);
					loc = player.getLocation().clone().add(player.getLocation().getDirection().clone().normalize().multiply(0.8).add(new Vector(0, 1, 0)));
					player.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 1, 0, 0, 0, 0.05, null, true);
					if (!acceptable.containsKey(player.getInventory().getItemInMainHand().getType()))
					{
						power = 0;
						charge = null;
						startCooldown(140, true);
						cancel();
					}
					if (time == 0)
					{
						shootLaser(power, level);
						power = 0;
						charge = null;
						startCooldown(140, true);
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
		else
		{
			time = 5;
		}
	}
	
	private void displayChargeBar(double power2)
	{
		double counter = power2;
		TextComponent component = Component.text("Charge : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - 2.5;
			if (counter >= 0)
				component = component.append(Component.text("|").color(TextColor.color(40, 255, 100)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		player.sendActionBar(component);
	}
	
	private void shootLaser(double power, int level)
	{
		Location loc = player.getLocation().clone().add(player.getLocation().getDirection().clone().normalize().multiply(0.8).add(new Vector(0, 1, 0)));
		Vector dir = loc.getDirection().clone().multiply(0.2);
		player.getWorld().playSound(loc, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1F, 1F);
		for (int i = 0; i < 200 + 20 * level; i++)
		{
			player.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 1, 0, 0, 0, 0, null, true);
			loc.add(dir);
			if (entitiesHit(loc, power, level))
			{
				i = 20000;
			}
			else if (!loc.getBlock().isPassable())
			{
				i = 20000;
				loc.subtract(dir);
			}
		}
		spawnFirework(loc);
	}
	
	private boolean entitiesHit(Location loc, double power, int level)
	{
		boolean hit = false;
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector()))
			{
				hit = true;
				entity.damage(power/10 * (1 + level * 0.2));
			}
		}
		return hit;
	}
	
	private void spawnFirework(Location loc)
	{
		Firework firework = (Firework) player.getWorld().spawn(loc, Firework.class);
		FireworkMeta meta = firework.getFireworkMeta();
		meta.addEffect(FireworkEffect.builder().withColor(Color.WHITE).with(Type.BALL_LARGE).with(Type.STAR).build());
		firework.setFireworkMeta(meta);
		firework.addScoreboardTag("nodamage");
		firework.detonate();
	}
}
