package me.August.InfinityGauntlet;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener {
	
	HashMap<Player, InvM> invs = new HashMap<Player, InvM>();
	HashMap<ItemMeta, Integer> abilities = new HashMap<ItemMeta, Integer>();
	
	@Override
	public void onEnable() {
		
		Bukkit.getPluginManager().registerEvents(this, this);
		abilities = initabilities();
		
	}
	
	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		
		Player player = e.getPlayer();
		if(!invs.containsKey(player)) {
			invs.put(player, new InvM(player));
		}
		player.getInventory().addItem(gauntlet());
		
	}
	
	@EventHandler
	public void onClick(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		if(player.getInventory().getItemInMainHand().isSimilar(gauntlet())) {
			if(e.getAction() == Action.RIGHT_CLICK_AIR) {
				if(invs.get(player).isActive()) {
					invs.get(player).deactivate();
				} else {
					invs.get(player).activate();
				}
			} else if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
				if(invs.get(player).isActive()) {
					invs.get(player).deactivate();
				} else {
					invs.get(player).activate();
				}
			}
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent e) {
		Player player = e.getPlayer();
		if(e.getItemDrop().getItemStack().isSimilar(gauntlet()) && invs.get(player).isActive()) {
			e.setCancelled(true);
			invs.get(player).next();
		}
	}
	
	@EventHandler
	public void onSelect(PlayerItemHeldEvent e) {
		Player player = e.getPlayer();
		if(invs.get(player).isActive() && abilities.get(player.getInventory().getItem(e.getNewSlot()).getItemMeta()) != null) {
			switch (abilities.get(player.getInventory().getItem(e.getNewSlot()).getItemMeta())) {
			case 0:
				new PowerBlast(player, this);
				player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SILVERFISH_STEP, 1, 0.7F + (float) Math.random() * 0.5F);
				break;
			case 1:
				new TimeWarp(player, this);
				player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SILVERFISH_DEATH, 1, 1);
				break;
			case 2:
				new TimeBlast(player, this);
				player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SILVERFISH_DEATH, 1, 1.4F);
				break;
			case 3:
				new PowerWave(player, this);
				player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SILVERFISH_STEP, 1, 0.7F + (float) Math.random() * 0.5F);
				break;
			case 4:
				new SpaceStrike(player, this);
				break;
			case 5:
				new SpaceWarp(player, this);
				break;
			default:
				break;
			}
			e.setCancelled(true);
		}
	}
	
	public static ItemStack gauntlet() {
		ItemStack item = new ItemStack(Material.GOLD_INGOT, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Infinity Gauntlet");
		meta.setCustomModelData(69);
		item.setItemMeta(meta);
		return item;
	}
	
	public HashMap<ItemMeta, Integer> initabilities() {
		HashMap<ItemMeta, Integer> items = new HashMap<ItemMeta, Integer>();
		items.put(Abilities.powerblast().getItemMeta(), 0);
		items.put(Abilities.timewarp().getItemMeta(), 1);
		items.put(Abilities.timeblast().getItemMeta(), 2);
		items.put(Abilities.powerwave().getItemMeta(), 3);
		items.put(Abilities.spacestrike().getItemMeta(), 4);
		items.put(Abilities.spacewarp().getItemMeta(), 5);
		return items;
	}

}
