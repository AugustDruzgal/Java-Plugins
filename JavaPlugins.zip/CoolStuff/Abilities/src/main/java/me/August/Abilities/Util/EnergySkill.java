package me.August.Abilities.Util;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import me.August.Abilities.Main;

public class EnergySkill extends Skill {
	
	BukkitTask cooldowntask = null;
	
	EnergySkill(Player p, Plugin pl) {
		super(p, pl);
	}
	
	@Override
	public void activate(int level)
	{
		if (Main.getManager(player).getManaManager().getMana() > 10)
		{
			effect(level);
		}
	}
}
