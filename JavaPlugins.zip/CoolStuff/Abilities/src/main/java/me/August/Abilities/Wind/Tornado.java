package me.August.Abilities.Wind;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.Skill;

public class Tornado extends Skill {
	
	Location tornadoloc;
	DustOptions color;

	public Tornado(Player p, Plugin pl) {
		super(p, pl);
		color = new DustOptions(Color.WHITE, 1F);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() < 100)
			return;
		manager.removeMana(100);
		player.setVelocity(player.getLocation().getDirection().clone().setY(0).normalize().multiply(-0.7).setY(0.3));
		createTornado();
	}
	
	private void createTornado()
	{
		new BukkitRunnable()
		{
			Location loc = player.getLocation().clone();
			Vector dir = loc.getDirection().clone().setY(0).normalize().multiply(0.3);
			int time = 0;
			@Override
			public void run()
			{
				loc = loc.add(dir);
				tornadoloc = loc;
				spawnParticle();
				hitEntities(loc);
				time++;
				if (time > 100)
				{
					tornadoloc.add(new Vector(0, 1, 0));
					player.getWorld().spawnParticle(Particle.CLOUD, tornadoloc, 50, 0.3, 1, 0.3, 0.3, null, true);
					cancel();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private void spawnParticle()
	{
		player.getWorld().spawnParticle(Particle.CLOUD, tornadoloc, 5, 0.3, 0.3, 0.3, 0.2, null, true);
		new BukkitRunnable()
		{
			double time = 0;
			Location loc;
			Vector offset = new Vector(0, 0, 1).rotateAroundY(Math.random() * Math.PI * 2);
			@Override
			public void run()
			{
				offset.normalize().multiply(time * 0.7 * 0.1667 + 2);
				offset.rotateAroundY(Math.PI/20);
				loc = tornadoloc.clone().add(offset).add(new Vector(0, time * 0.05 * 6, 0));

				player.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0, color, true);
				time++;
				if (time > 20)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private void hitEntities(Location loc)
	{
		Vector diff;
		Vector diff2d;
		double height;
		double targetlen;
		Vector vel;
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player)
			{
				diff = loc.clone().subtract(entity.getLocation()).toVector();
				diff2d = diff.clone().setY(0).normalize().multiply(diff.length());
				height = entity.getLocation().getY() - loc.getY();
				if (diff2d.length() < 7 && height < 6 && height > -2)
				{
					targetlen = height * 0.7 + 2;
					if (diff2d.length() < targetlen)
						vel = diff2d.clone().normalize().multiply(-0.3);
					else
						vel = diff2d.clone().normalize().multiply(0.3);
					vel.add(diff2d.clone().rotateAroundY(Math.PI/2).normalize().multiply(0.7));
					if (height < 5)
						vel.add(new Vector(0, 0.2, 0));
					entity.setVelocity(vel);
					entity.setFallDistance(5);
				}
			}	
		}
	}
}
