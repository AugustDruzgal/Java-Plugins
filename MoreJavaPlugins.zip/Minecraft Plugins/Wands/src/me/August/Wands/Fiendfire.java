package me.August.Wands;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Fiendfire extends Spell {

	Fiendfire(Player p, Plugin pl) {
		super(p, pl);
		setIcons(Material.BLAZE_POWDER, 1, Material.BLAZE_POWDER, 2);
		setMaxCooldown(200);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
	}
	
	@Override
	public void spellEffect() {
		
		new BukkitRunnable() {
			
			int timer = 0;
			Vector sideoffset;
			Location pieceloc;
			ArrayList<FiendFirePiece> pieces = new ArrayList<FiendFirePiece>();
			
			@Override
			public void run() {
				
				if (timer == 0) {

					Main.wandManagers.get(player).setCooldowns(30);
					player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PHANTOM_AMBIENT, 2F, 1.3F);
					
				} else if (timer < 30) {
					
					player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 4, 4, true));
					player.getWorld().spawnParticle(Particle.LAVA, player.getLocation().clone().add(new Vector(0,0.7,0)), 3, 1, 1, 1, 1, null, true);
					
					if (timer == 28) {
						
						player.getWorld().playSound(player.getLocation(), Sound.ENTITY_CAT_HISS, 0.9F, 1.2F);
						
					}
					
				} else {
					
					player.removePotionEffect(PotionEffectType.SLOW);
					player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 2F, 1.3F);
						player.getWorld().playSound(player.getLocation(), Sound.ENTITY_CAT_HISS, 0.7F, 2F);
					sideoffset = player.getLocation().clone().getDirection().setY(0).rotateAroundY(Math.PI/2).normalize().multiply(0.5);
					
					for (int i = 0 ; i < 11 ; i++) {
						pieceloc = player.getLocation().add(sideoffset.clone().multiply(5-i)).add(new Vector(0,1.25,0));
						pieces.add(new FiendFirePiece(player, plugin, pieceloc));
						
					}
					
					new BukkitRunnable() {
						

						HashMap<LivingEntity, Integer> hitentities = new HashMap<LivingEntity, Integer>();
						HashMap<LivingEntity, Integer> hitamount = new HashMap<LivingEntity, Integer>();
						int timer = 0;
						
						@Override
						public void run() {
							
							hitentities.put(player, 1000);
							
							timer++;
							
							for (LivingEntity entity:player.getWorld().getLivingEntities()) {
								
								if (hitentities.containsKey(entity)) {
									
									if (hitentities.get(entity) == 1) {
										
										hitentities.remove(entity);
										
									} else {
										
										hitentities.put(entity, hitentities.get(entity) - 1);
										
									}
									
								}
								
							}
							
							ArrayList<FiendFirePiece> remove = new ArrayList<FiendFirePiece>();
							
							for (FiendFirePiece piece:pieces) {

								for (int i = 0 ; i < 3 ; i++) {
									
									if (!piece.move()) {
										
										setFire(1.5F, piece.loc);
										piece.loc.getWorld().playSound(piece.loc, Sound.ITEM_FIRECHARGE_USE, 2, 0.6F);
										i = 10;
										remove.add(piece);

									}
									
									for (LivingEntity entity:piece.hit()) {
										
										if (!hitamount.containsKey(entity)) {
											
											hitamount.put(entity, 0);
											
										}
										
										if (!hitentities.containsKey(entity) && hitamount.get(entity) < 4) {
											
											setFire(2.35F, entity.getLocation());
											hit(entity);
											
											hitentities.put(entity, 4);
											hitamount.put(entity, hitamount.get(entity) + 1);
											
										}
										
									}
									
								}
								
							}
							
							pieces.removeAll(remove);
							
							if (timer > 100) {
								
								cancel();
								
							}
							
						}
						
					}.runTaskTimer(plugin, 0, 1);
					
					cancel();
					
				}
				
				timer++;
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void setFire(float area, Location eloc) {
		
		Location location;
		
		for (float x = 0 - area; x < area ; x++) {
			
			for (float y = 0 - area; y < area ; y++) {
				
				for (float z = 0 - area; z < area ; z++) {
					
					location = eloc.clone().add(new Vector(x,y,z));
					
					if (location.getBlock().isPassable() && eloc.distance(location) < area) {
						
						TemporaryBlockManager.setBlock(location, Material.FIRE, 60 + 20*(area-eloc.distance(location)), plugin);
						
					}
					
				}
				
			}
			
		}
		
	}
	
	public void hit(LivingEntity entity) {
		
		Vector dir = player.getLocation().getDirection().clone().normalize().multiply(2.2);
		
		entity.setNoDamageTicks(0);
		entity.damage(2);
		entity.setFireTicks(100);
		entity.setVelocity(dir);
		entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_PHANTOM_DEATH, 1, 2F);
		entity.getWorld().playSound(entity.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1, 2F);
		
	}

}
