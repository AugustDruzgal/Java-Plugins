package me.August.InfinityStones;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class Stones {
	
	public static boolean isHoldingStoneInMain(Player player, int stone)
	{
		if (player.getInventory().getItemInMainHand().isSimilar(generateStone(stone)))
			return true;
		return false;
	}
	
	public static boolean isHoldingStoneInMain(Player player)
	{
		for (ItemStack stone:Stones.generateStones())
			if (player.getInventory().getItemInMainHand().isSimilar(stone))
				return true;
		return false;
	}
	
	public static boolean isHoldingStone(Player player)
	{
		ItemStack stone;
		for (int i = 0; i < 6; i++)
		{
			stone = generateStone(i);
			if (player.getInventory().getItemInMainHand().isSimilar(stone))
				return true;
			if (player.getInventory().getItemInOffHand().isSimilar(stone))
				return true;
		}
		return false;
	}
	
	public static boolean isHoldingStone(Player player, int num)
	{
		ItemStack stone = generateStone(num);
		if (player.getInventory().getItemInMainHand().isSimilar(stone))
			return true;
		if (player.getInventory().getItemInOffHand().isSimilar(stone))
			return true;
		return false;
	}
	
	public static ItemStack[] generateStones()
	{
		ItemStack[] s = {};
		ItemMeta[] meta = {};
		TextComponent[] name = {};
		TextColor[] color = {
				TextColor.color(255, 100, 225),
				TextColor.color(20, 10, 255),
				TextColor.color(255, 20, 10),
				TextColor.color(100, 255, 100),
				TextColor.color(255, 100, 0),
				TextColor.color(225, 255, 100),
		};
		String[] nametext = {
				"power",
				"space",
				"reality",
				"time",
				"mind",
				"soul"
		};
		
		for (int i = 0; i < 6; i++)
		{
			s[i] = new ItemStack(Material.AMETHYST_SHARD);
			meta[i] = s[i].getItemMeta();
			meta[i].setCustomModelData(i + 1);
			name[i] = Component.empty();
			name[i].color(color[i]);
			name[i].content(nametext[i] + " stone");
			meta[i].displayName(name[i]);
			s[i].setItemMeta(meta[i]);
		}
		
		return s;
	}
	
	public static ItemStack generateStone(int stone)
	{
		ItemStack s;
		ItemMeta meta;
		TextComponent name;
		TextColor[] color = {
				TextColor.color(255, 100, 225),
				TextColor.color(20, 10, 255),
				TextColor.color(255, 20, 10),
				TextColor.color(100, 255, 100),
				TextColor.color(255, 100, 0),
				TextColor.color(225, 255, 100),
		};
		String[] nametext = {
				"power",
				"space",
				"reality",
				"time",
				"mind",
				"soul"
		};
			
		s = new ItemStack(Material.AMETHYST_SHARD);
		meta = s.getItemMeta();
		meta.setCustomModelData(stone + 2);
		name = Component.text(nametext[stone] + " stone");
		name.color(color[stone]);
		meta.displayName(name);
		s.setItemMeta(meta);
		
		return s;
	}
}
