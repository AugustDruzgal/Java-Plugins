// August Druzgal
// COP 3502, Spring 2022

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListyString.h"

// This function processes the input file given as a command line argument
int main(int argc, char **argv) 
{
	processInputFile(argv[1]);
	
	return 0;
}

// This function opens the specified input file and follows the instructions provided within it
int processInputFile(char *filename)
{
	FILE *ifp = fopen(filename, "r");
	char str[1024];
	char c[1];
	
	if (ifp == NULL)
		return 1;
	
	if (!fscanf(ifp, "%s", str))
		return 1;
	
	ListyString *listy = createListyString(str);
	
	while (EOF != fscanf(ifp, "%s", c))
	{
		// @ = replace all characters key in listy with string str
		if (!strcmp(c,"@"))
		{
			fscanf(ifp, "%s", c);
			fscanf(ifp, "%s", str);
			replaceChar(listy, c[0], str);
		}
		// > = add string str to the end of listy
		else if (!strcmp(c,">"))
		{
			fscanf(ifp, "%s", str);
			listyCat(listy, str);
		}
		// < = add string str to the beginning of listy
		else if (!strcmp(c,"<"))
		{
			fscanf(ifp, "%s", str);
			listyPrepend(listy, str);
		}
		// ~ = reverse the contents of listy
		else if (!strcmp(c,"~"))
		{
			reverseListyString(listy);
		}
		// * = replace all instances of all characters in string str in listy with "*"
		else if (!strcmp(c,"*"))
		{
			fscanf(ifp, "%s", str);
			listyCensor(listy, str);
		}
		// - = remove all instances of character key from listy
		else if (!strcmp(c,"-"))
		{
			fscanf(ifp, "%s", c);
			replaceChar(listy, c[0], "");
		}
		// & = interweave string str within listy, starting with the first character of listy
		else if (!strcmp(c,"&"))
		{
			fscanf(ifp, "%s", str);
			stringWeave(listy, str);
		}
		// # = print the total number of characters c within listy
		else if (!strcmp(c,"#"))
		{
			fscanf(ifp, "%s", c);
			printf("%d\n", charCount(listy, c[0]));
		}
		// ? = print the length of listy
		else if (!strcmp(c,"?"))
		{
			printf("%d\n", listyLength(listy));
		}
		// ! = print listy
		else if (!strcmp(c,"!"))
		{
			printListyString(listy);
		}
	}
	
	return 0;
}

// This function creates a ListyString out of the target string
ListyString *createListyString(char *str)
{
	int i;
	int len = 0;
	ListyNode *node;
	
	ListyString* newLSTR = malloc(sizeof(ListyString));
	if (str != NULL)
		len = strlen(str);
	
	newLSTR->length = len;
	
	if (len != 0)
	{
		newLSTR->head = malloc(sizeof(ListyNode));
		newLSTR->head->data = str[0];
		node = newLSTR->head;
	}
	else
	{
		newLSTR->head = NULL;
	}
	
	// iterate through str and allocate nodes in newLSTR containing each character
	for (i = 1; i < len; i++) {
		node->next = malloc(sizeof(ListyNode));
		node = node->next;
		node->data = str[i];
	}
	
	if (len > 0)
		node->next = NULL;
	
	return newLSTR;
}

// This function deallocates the target ListyString and all ListyNodes connected to it
ListyString *destroyListyString(ListyString *listy)
{
	ListyNode *node;
	ListyNode *next = NULL;
	
	if (listy == NULL)
		return NULL;
	
	node = listy->head;
	if (node != NULL)
		next = node->next;
	
	while (next != NULL)
	{
		free(node);
		node = next;
		next = next->next;
	}
	
	if (node != NULL)
		free(node);
	
	free(listy);
	
	return NULL;
}

// This function creates a new ListyString with the same data as the target ListyString
ListyString *cloneListyString(ListyString *listy)
{
	int i, len;
	ListyNode *newnode, *cpynode;
	
	if (listy == NULL)
		return NULL;
	
	len	= listy->length;
	
	ListyString* newLSTR = malloc(sizeof(ListyString));
	if (listy->length > 0)
	{
		// Iterate though both listy and newLSTR, copying data from listy into newLSTR
		newLSTR->head = malloc(sizeof(ListyNode));
		newnode = newLSTR->head;
		cpynode = listy->head;
		newnode->data = cpynode->data;
	
		for (i = 1; i < len; i++) {
			newnode->next = malloc(sizeof(ListyNode));
			newnode = newnode->next;
			cpynode = cpynode->next;
			newnode->data = cpynode->data;
		}
		newnode->next = NULL;
	}
	else
	{
		newLSTR->head = NULL;
	}
	
	newLSTR->length = len;
	
	return newLSTR;
}

// This function appends str to the end of the target ListyString
ListyString *listyCat(ListyString *listy, char *str)
{
	int len, listylen, i;
	ListyNode *node;
	if (str == NULL)
		if (listy == NULL)
			return NULL;
		else
			return listy;
	
	if (listy == NULL)
	{
		return createListyString(str);
	}
	
	len = strlen(str);
	if (len == 0)
		return listy;
	
	listylen = listy->length;
	node = listy->head;
	
	for (i = 0; i < listylen - 1; i++)
		node = node->next;
	
	i = 0;
	
	// Add each character in str to the end of listy
	if (node == NULL)
	{
		listy->length++;
		listy->head = malloc(sizeof(ListyNode));
		node = listy->head;
		node->data = str[0];
		i = 1;
	}
	
	while (i < len)
	{
		listy->length++;
		node->next = malloc(sizeof(ListyNode));
		node = node->next;
		node->data = str[i];
		i++;
	}
	
	node->next = NULL;
	
	return listy;
}

// This function prepends str to the end of the target ListyString
ListyString *listyPrepend(ListyString *listy, char *str)
{
	int len = 0;
	int	i;
	ListyNode *next, *node;
	
	if (listy == NULL)
		if (str == NULL)
			return NULL;
		else
			return createListyString(str);
	
	if (str != NULL)
		len = strlen(str);
	
	if (len == 0)
		return listy;
	
	listy->length++;
	next = listy->head;
	listy->head = malloc(sizeof(ListyNode));
	node = listy->head;
	node->data = str[0];
	
	// Add each character in str to the beginning of listy
	for (i = 1; i < len; i++)
	{
		listy->length++;
		node->next = malloc(sizeof(ListyNode));
		node = node->next;
		node->data = str[i];
	}
	
	node->next = next;
	
	return listy;
}

// This function replaces all characters 'key' in listy with str
void replaceChar(ListyString *listy, char key, char *str)
{
	ListyNode *node, *next, *freemarker;
	int len = 0;
	int i;
	
	if (listy == NULL || listy->length == 0)
		return;
	
	node = listy->head;
	
	if (str != NULL)
		len = strlen(str);
	
	// if the length of str is 0, remove all instances of 'key' from listy
	if (len == 0)
	{
		while (node != NULL && node->data == key)
		{
			if (listy->head->next != NULL)
				listy->head = listy->head->next;
			else
				listy->head = NULL;
			listy->length--;
			free(node);
			node = listy->head;
		}
		
		while (node != NULL && node->next != NULL)
		{
			if (node->next->data == key)
			{
				listy->length--;
				freemarker = node->next;
				node->next = node->next->next;
				free(freemarker);
			}
			else
			{
				node = node->next;
			}
		}
		
		return;
	}
	
	// if the length of 'str' is not zero, replace all instances of key with str
	while (node != NULL)
	{
		if (node->data == key)
		{
			next = node->next;
			
			for (int i = 0; i < len - 1; i++)
			{
				listy->length++;
				node->data = str[i];
				node->next = malloc(sizeof(ListyNode));
				node = node->next;
			}
			node->data = str[len-1];
			node->next = next;
		}
		
		node = node->next;
	}
}

// This function replaces all characters in listy that are contained in badChars with '*'
void listyCensor(ListyString *listy, char *badChars)
{
	int chars[256];
	int i;
	int len = 0;
	ListyNode *node;
	
	if (listy == NULL || listy->length == 0)
		return;
	
	if (badChars != NULL)
		len = strlen(badChars);
	
	if (len == 0)
		return;
	
	// Create an array with an index for each ascii character
	for (i = 0; i < 256; i++)
	{
		chars[i] = 0;
	}
	
	// For each character in badChars, set the corresponding index in chars to 1
	for (i = 0; i < len; i++)
		chars[badChars[i]] = 1;
	
	node = listy->head;
	len = listy->length;
	
	for (i = 0; i < len; i++)
	{
		// if chars[data] == 1, the character in node is contained in badChars, so censor it
		if (chars[node->data] == 1)
			node->data = '*';
		node = node->next;
	}
}

// This function reverses the order of the nodes within listy, without deallocating any nodes.
void reverseListyString(ListyString *listy)
{
	int i;
	int len;
	ListyNode **listypointers ;
	ListyNode *node;
	
	if (listy == NULL || listy->length == 0)
		return;
	
	listypointers = malloc(sizeof(ListyNode *) * len);
	node = listy->head;
	len = listy->length;
	
	for (i = 0; i < len; i++)
	{
		listypointers[i] = node;
		node = node->next;
	}
	
	for (i = 1; i < len; i++)
	{
		listypointers[i]->next = listypointers[i-1];
	}
	
	listy->head = listypointers[len - 1];
	listypointers[0]->next = NULL;
}

// This function weaves the characters in str into listy, alternating characters
ListyString *stringWeave(ListyString *listy, char *str)
{
	int len, i;
	int running = 1;
	ListyNode *node, *next;
	
	if (str == NULL)
		return listy;
	
	len = strlen(str);
	
	if (len == 0)
	{
		if (listy == NULL)
			return createListyString("");
		return listy;
	}
	
	if (listy == NULL)
		return createListyString(str);
	
	if (listy->length == 0)
	{
		return listyCat(listy, str);
	}
	
	node = listy->head;
	
	for (i = 0; i < len; i++)
	{
		next = node->next;
		node->next = malloc(sizeof(ListyNode));
		listy->length++;
		node = node->next;
		node->data = str[i];
		node->next = next;
		if (node->next != NULL)
			node = node->next;
	}
	
	return listy;
}

// This function weaves the characters in listy2 into listy, alternating characters
ListyString *listyWeave(ListyString *listy1, ListyString *listy2)
{
	ListyNode *node, *node2, *next;
	int i, len;
	
	if (listy2 == NULL || listy2->length == 0)
		return listy1;
	
	if (listy1 == NULL)
		return cloneListyString(listy2);
	
	node2 = listy2->head;	
	len = listy2->length;
	node = listy1->head;
	
	// if listy1 is empty, append the contents of listy2 to the end of it
	if (listy1->length == 0)
	{
		listy1->head = malloc(sizeof(ListyNode));
		node = listy1->head;
		node->data = node2->data;
		listy1->length++;
		for (i = 1; i < len; i++)
		{
			node2 = node2->next;
			node->next = malloc(sizeof(ListyNode));
			node = node->next;
			node->data = node2->data;
			listy1->length++;
		}
		node->next = NULL;
		
		return listy1;
	}
	
	// if listy1 isn't empty, weave the contents together with listy2
	for (i = 0; i < len; i++)
	{
		next = node->next;
		node->next = malloc(sizeof(ListyNode));
		listy1->length++;
		node = node->next;
		node->data = node2->data;
		node2 = node2->next;
		node->next = next;
		if (node->next != NULL)
			node = node->next;
	}
	
	return listy1;
}	

// This function returns 0 if the contents of the two input ListyStrings are the same, and 1 if not
int listyCmp(ListyString *listy1, ListyString *listy2)
{
	ListyNode *node1, *node2;
	int i;
	
	if (listy1 == listy2)
		return 0;
	if (listy1 == NULL || listy2 == NULL)
		return 1;
	if (listy1->length != listy2->length)
		return 1;
	
	node1 = listy1->head;
	node2 = listy2->head;
	for (i = 0; i < listy1->length; i++)
	{
		if (node1->data != node2->data)
			return 1;
		node1 = node1->next;
		node2 = node2->next;
	}
	
	return 0;
}

// This function returns the total amount of character 'key' contained within listy
int charCount(ListyString *listy, char key)
{
	int i;
	int count = 0;
	ListyNode *node;
	
	if (listy == NULL)
		return -1;
	
	node = listy->head;
	for (i = 0; i < listy->length; i++)
	{
		if (node->data == key)
			count++;
		node = node->next;
	}
	
	return count;
}

// This function returns the length of listy
int listyLength(ListyString *listy)
{
	if (listy == NULL)
		return -1;
	return listy->length;
}

// This function prints the string contained within listy
void printListyString(ListyString *listy) 
{
	if (listy == NULL || listy->length == 0)
	{
		printf("(empty string)\n");
		return;
	}
	ListyNode *node = listy->head;
	
	while (node != NULL)
	{
		printf("%c", node->data);
		node = node->next;
	}
	printf("\n");
}

// This function returns my difficulty rating for the assignment
double difficultyRating(void)
{
	return 3;
}

// This function returns my estimated hours spent on this assignment
double hoursSpent(void)
{
	return 9;
}