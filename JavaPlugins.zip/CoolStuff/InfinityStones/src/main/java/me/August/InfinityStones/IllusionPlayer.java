package me.August.InfinityStones;

import org.bukkit.Location;

public class IllusionPlayer {
	
	IllusionPlayer()
	{
		
	}
	
	public void spawn(Location loc)
	{
		
	}
	
	public void kill()
	{
		
	}
}
