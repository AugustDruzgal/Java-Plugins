package me.August.Wands;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class Spell {
	
	int cooldown = 0;
	int maxcooldown = 100;
	int slot;
	ItemStack spellicon;
	ItemStack cooldownicon;
	ItemStack currentdisplay;
	Plugin plugin;
	Player player;
	
	Spell(Player p, Plugin pl) {
		
		player = p;
		plugin = pl;
		slot = player.getInventory().firstEmpty();
		new BukkitRunnable() {
			
			@Override
			public void run() {
				
				if (cooldown > 0) {
					cooldown--;
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void attemptCast() {
		
		if (cooldown == 0) {
			cooldown = maxcooldown;
			spellEffect();
		}
		
	}
	   
	public void setMaxCooldown(int max) {
		maxcooldown = max;
	}
	
	public void setCooldown(int c) {
		if (c > cooldown) {
			cooldown = c;
		}
	}
	
	public void setIcons(Material item, int spellid, Material item2, int cooldownid) {
		
		spellicon = new ItemStack(item, 1);
		cooldownicon = new ItemStack(item2, 1);
		ItemMeta spellmeta = spellicon.getItemMeta();
		spellmeta.setCustomModelData(spellid);
		spellicon.setItemMeta(spellmeta);
		ItemMeta cooldownmeta = cooldownicon.getItemMeta();
		cooldownmeta.setCustomModelData(cooldownid);
		cooldownicon.setItemMeta(cooldownmeta);
		
	}
	
	public void updateDisplay(int currentcooldown) {
		if (currentcooldown == 0) {
			currentdisplay = spellicon.clone();
			currentdisplay.setAmount(1);
		} else {
			currentdisplay = cooldownicon.clone();
			currentdisplay.setAmount(Math.round((currentcooldown + 20)/20));
		}
	}
	
	public ItemStack getIcon() {
		
		return currentdisplay;
		
	}
	
	public void displayIcon() {
		if (Main.wandManagers.get(player).isActive()) {
			if (player.getInventory().containsAtLeast(cooldownicon, 1)) {
				player.getInventory().setItem(player.getInventory().first(cooldownicon.getType()), currentdisplay);
				slot = player.getInventory().first(spellicon.getType());
			} else if (player.getInventory().containsAtLeast(spellicon, 1)) {
				player.getInventory().setItem(player.getInventory().first(spellicon.getType()), currentdisplay);
				slot = player.getInventory().first(spellicon.getType());
			} else {
				player.sendMessage("u suck");
			}
		}
		
	}
	
	public boolean isOnCooldown() {
		
		if (cooldown > 0) {
			
			return true;
			
		} else {
			
			return false;
			
		}
		
	}
	
	public void spellEffect() {
		
		// @override this and replace it with the spell's game effects
		
	}

}
