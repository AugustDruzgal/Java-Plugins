package me.August.CustomItems;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class PlayerData {
	
	private Inventory playerInv;
	private Inventory itemInv;
	private ArrayList<ItemStack[]> hotbars = new ArrayList<>();
	private int numHotbars = 1;
	private int currentHotbar = 0;
	private static HashMap<Player, Boolean> activeState = new HashMap<>();
	Player player;
	CustomItem parent;
	
	public PlayerData(Player player, CustomItem parent, int numHotbars)
	{
		this.player = player;
		this.parent = parent;
		playerInv = Bukkit.createInventory(player, InventoryType.PLAYER);
		itemInv = Bukkit.createInventory(player, InventoryType.PLAYER);
		if (!activeState.containsKey(player)) 
			activeState.put(player, false);
		setNumHotbars(numHotbars);
	}
	
	public void fillInventory(ArrayList<ItemStack> items)
	{
		ItemStack[] hitems;
		if (items.size() > 27 + (9 * numHotbars))
			return;
		for (int i = 0; i < numHotbars; i++)
		{
			hotbars.set(i, null);
			hitems = new ItemStack[9];
			for (int j = 0; j < 8 && j+(i*8) != items.size(); j++)
			{
				hitems[j] = items.get(j+(i*8));
			}
			hotbars.set(i, hitems.clone());
		}
		for (int i = 0; i < 8; i++)
		{
			itemInv.setItem(i, hotbars.get(currentHotbar)[i]);
		}
		for (int i = 8 * numHotbars; i < items.size(); i++)
		{	
			itemInv.setItem(i - 8*(numHotbars - 1) + 1, items.get(i));
		}
	}
	
	public void toggle()
	{
		activeState.put(player, !activeState.get(player));
		if (activeState.get(player))
		{
			playerInv.setContents(player.getInventory().getContents());
			player.getInventory().setContents(itemInv.getContents());
			player.getInventory().setItem(8, parent.getItemStack());
			player.getInventory().setHeldItemSlot(8);
		}
		else
		{
			itemInv.setContents(player.getInventory().getContents());
			player.getInventory().setContents(playerInv.getContents());
		}
		player.sendMessage("Active state: " + activeState);
	}
	
	public void swapHotbars()
	{
		if (numHotbars <= 1)
			return;
		hotbars.set(currentHotbar, getCurrentHotbar());
		currentHotbar = (currentHotbar + 1) % numHotbars;
		setCurrentHotbar(hotbars.get(currentHotbar));
	}
	
	public void setNumHotbars(int numHotbars)
	{
		this.numHotbars = numHotbars;
		for (int i = hotbars.size(); i < numHotbars; i++)
		{
			hotbars.add(new ItemStack[9]);
		}
	}
	
	public static boolean isActive(Player player)
	{
		return activeState.get(player);
	}
	
	private void setCurrentHotbar(ItemStack[] hotbar)
	{
		if (hotbar.length < 9) return;
		for (int i = 0; i < 9; i++)
		{
			player.getInventory().setItem(i, hotbar[i]);
			hotbar[i] = player.getInventory().getItem(i);
		}
	}
	
	private ItemStack[] getCurrentHotbar()
	{
		ItemStack[] hotbar = new ItemStack[9];
		for (int i = 0; i < 9; i++)
		{
			hotbar[i] = player.getInventory().getItem(i);
		}
		return hotbar;
	}

}
