package me.August.InfinityStones;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;

import net.kyori.adventure.text.format.NamedTextColor;

public class Main extends JavaPlugin {
	
	static EventListener listener;
	
	@Override
	public void onEnable()
	{
		listener = new EventListener(this);
		Bukkit.getPluginManager().registerEvents(listener, this);
		initScoreboard();
		PowerStone.initPowerStone(this);
		TimeStone.initTimeStone(this);
		RealityStone.initRealityStone(this);
		MindStone.initMindStone(this);
		Gauntlet.initGauntlet();
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	private void initScoreboard()
	{
		Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
		if (scoreboard.getTeam("players") == null)
			scoreboard.registerNewTeam("players");
		scoreboard.getTeam("players").color(NamedTextColor.GOLD);
		scoreboard.getTeam("players").setAllowFriendlyFire(true);
		if (scoreboard.getTeam("monsters") == null)
			scoreboard.registerNewTeam("monsters");
		scoreboard.getTeam("monsters").color(NamedTextColor.RED);
		scoreboard.getTeam("monsters").setAllowFriendlyFire(true);
		if (scoreboard.getTeam("animals") == null)
			scoreboard.registerNewTeam("animals");
		scoreboard.getTeam("animals").color(NamedTextColor.GREEN);
		scoreboard.getTeam("animals").setAllowFriendlyFire(true);
		if (scoreboard.getTeam("bosses") == null)
			scoreboard.registerNewTeam("bosses");
		scoreboard.getTeam("bosses").color(NamedTextColor.LIGHT_PURPLE);
		scoreboard.getTeam("bosses").setAllowFriendlyFire(true);
		if (scoreboard.getTeam("nonliving") == null)
			scoreboard.registerNewTeam("nonliving");
		scoreboard.getTeam("nonliving").color(NamedTextColor.BLUE);
		scoreboard.getTeam("nonliving").setAllowFriendlyFire(true);
		if (scoreboard.getTeam("generic") == null)
			scoreboard.registerNewTeam("generic");
		scoreboard.getTeam("generic").color(NamedTextColor.YELLOW);
		scoreboard.getTeam("generic").setAllowFriendlyFire(true);
	}

}
