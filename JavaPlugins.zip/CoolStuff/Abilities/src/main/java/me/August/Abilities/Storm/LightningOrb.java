package me.August.Abilities.Storm;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import me.August.Abilities.Util.Utils;

public class LightningOrb extends Skill implements Utils {

	public LightningOrb(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		launchOrb(level);
	}
	
	private boolean isTouchingEntity(Location loc)
	{
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getBoundingBox().expand(0.5).contains(loc.toVector()))
			{
				return true;
			}
		}
		return false;
	}
	
	private void launchOrb(int level)
	{
		Item orb;
		orb = player.getWorld().dropItem(
				player.getLocation().clone().add(new Vector(0, 1, 0)), new ItemStack(Material.DIAMOND_BLOCK));
		orb.setCanPlayerPickup(false);
		orb.setCanMobPickup(false);
		orb.setVelocity(player.getLocation().getDirection().clone().add(
				new Vector(0, 0.15, 0)).multiply(1 + 0.1 * level));
		orb.getWorld().playSound(player.getLocation(), Sound.BLOCK_DISPENSER_FAIL, 0.5F, 1.5F);
		startCooldown(240, true);
		new BukkitRunnable()
		{
			int timer = 0;
			@Override
			public void run()
			{
				orb.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, orb.getLocation(), 1, 0, 0, 0, 0.06, null, true);
				if (isTouchingEntity(orb.getLocation()))
					timer = 100;
				timer++;
				if (timer > 35)
				{
					cancel();
					strike(orb.getLocation(), level);
					orb.remove();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private void strike(Location loc, int level)
	{
		loc.getWorld().strikeLightningEffect(loc);
		loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 20, 0, 0, 0, 0.225, null, true);
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (loc.distance(entity.getLocation()) <= 5)
			{
				entity.damage(5 + level, player);
				Utils.shock(entity, 10 + 3 * level);
			}
		}
	}
}
