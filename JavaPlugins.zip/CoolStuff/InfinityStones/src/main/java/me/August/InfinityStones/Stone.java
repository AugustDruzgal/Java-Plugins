package me.August.InfinityStones;

import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class Stone {
	
	Player player = null;
	Plugin plugin;
	ItemStack item;
	String name;
	Color color;
	float time = 0;
	
	Stone(Plugin pl)
	{
		plugin = pl;
		item = createItem();
	}
	
	public void passive()
	{
		if (player != null && isHolding())
		{
			p();
		}
	}
	
	// Override this
	public void p()
	{
		
	}
	
	public void active()
	{
		if (player != null && isHolding())
		{
			a();
		}
	}
	
	// Override this tooO
	public void a()
	{
		
	}
	
	public void particle()
	{
		time = time + 3F;
		if (player != null)
		{
			Vector offset = new Vector(0, 0, 0);
			offset.setX(Math.sin(time/40) * 0.9);
			offset.setY(1 + Math.cos(time/100));
			offset.setZ(Math.cos(time/40) * 0.9);
			DustOptions dust = new DustOptions(color, 0.8F);
			player.getWorld().spawnParticle(Particle.REDSTONE, player.getLocation().clone().add(offset), 1, 0, 0, 0, 0, dust, true);
		}
	}
	
	// Override this as well
	public ItemStack createItem()
	{
		return null;
	}
	
	public Player getOwner()
	{
		return player;
	}
	
	public void setOwner(Player p)
	{
		player = p;
	}
	
	public ItemStack getItem()
	{
		return item.clone();
	}
	
	public boolean isItem(ItemStack input_item)
	{
		if (item.isSimilar(input_item))
			return true;
		return false;
	}
	
	public boolean isHolding()
	{
		if (player.getInventory().getItemInMainHand().isSimilar(item))
			return true;
		if (player.getInventory().getItemInOffHand().isSimilar(item))
			return true;
		return false;
	}
	
	public String getName()
	{
		return name;
	}
	
	public boolean isHoldingInMain()
	{
		if (player.getInventory().getItemInMainHand().isSimilar(item))
			return true;
		return false;
	}
	
	public boolean isHoldingInOff()
	{
		if (player.getInventory().getItemInOffHand().isSimilar(item))
			return true;
		return false;
	}
}
