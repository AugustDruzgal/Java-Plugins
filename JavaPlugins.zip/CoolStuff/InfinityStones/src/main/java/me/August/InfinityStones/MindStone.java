package me.August.InfinityStones;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Guardian;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.WrappedWatchableObject;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class MindStone extends Stone {
	
	private ProtocolManager protocolManager;
	int passiveActive = 0;

	MindStone(Plugin pl) {
		super(pl);
		name = "Mind Stone";
		color = Color.fromRGB(255, 100, 0);
		time = 160;
		protocolManager = ProtocolLibrary.getProtocolManager();
		protocolManager.addPacketListener(getPacketListener());
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				passiveActive--;
				if (passiveActive < 0 && passiveActive > -10)
					refreshAll();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	@Override
	public void p()
	{
		if (passiveActive < 0)
			refreshAll();
		passiveActive = 2;
	}
	
	@Override
	public void a()
	{
		Guardian guardian = (Guardian) player.getWorld().spawnEntity(rayForward(player), EntityType.GUARDIAN);
		new BukkitRunnable()
		{
			int time = 0;
			
			@Override
			public void run()
			{
				if (time == 0)
				{
					guardian.setInvulnerable(true);
					guardian.setInvisible(true);
					guardian.setSilent(true);
					guardian.setGravity(false);
				}
				guardian.setTarget(player);
				guardian.setLaser(true);
				sendEntityMove(guardian, rayForward(player));
				time++;
				if (time > 100)
				{
					guardian.remove();
					cancel();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	@Override
	public ItemStack createItem()
	{
		ItemStack new_item = new ItemStack(Material.AMETHYST_SHARD);
		
		ItemMeta meta = new_item.getItemMeta();
		TextComponent name = Component.text("mind stone").color(TextColor.color(255, 100, 0));
		meta.displayName(name);
		meta.setCustomModelData(6);
		new_item.setItemMeta(meta);
		
		return new_item;
	}
	
	private PacketAdapter getPacketListener()
	{
		return new PacketAdapter(plugin, PacketType.Play.Server.ENTITY_METADATA)
		{
			@Override
			public void onPacketSending(PacketEvent e)
			{
				if (passiveActive < 0)
					return;
				PacketContainer packet = e.getPacket().deepClone();
				if (e.getPacketType() == PacketType.Play.Server.ENTITY_METADATA) 
				{
					if (entityFromID(packet.getIntegers().read(0)) instanceof Guardian guardian && guardian.isInvisible())
					{
						List<WrappedWatchableObject> contents = packet.getWatchableCollectionModifier().read(0);
						WrappedWatchableObject object = contents.stream().filter(obj -> obj.getIndex() == 17).findFirst().orElse(null);
						object.setValue(player.getEntityId());
						e.setPacket(packet);
						return;
					}
					if (e.getPlayer() == player)
					{
						List<WrappedWatchableObject> contents = packet.getWatchableCollectionModifier().read(0);
						WrappedWatchableObject object = contents.stream().filter(obj -> obj.getIndex() == 0).findFirst().orElse(null);
						if (object != null && object.getValue() instanceof Byte)
						{
							byte b = (Byte) object.getValue();
							b |= 0b01000000;
							object.setValue(b);
						}
						e.setPacket(packet);
					}
				}
			}
		};
	}
	
	private void sendEntityMove(Entity e, Location loc)
	{
		PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.ENTITY_TELEPORT);
		packet.getIntegers().write(0, e.getEntityId());
		packet.getDoubles().write(0, loc.getX());
		packet.getDoubles().write(1, loc.getY());
		packet.getDoubles().write(2, loc.getZ());
		for (Player player:loc.getWorld().getPlayers())
			try {
				protocolManager.sendServerPacket(player, packet);
			} catch (InvocationTargetException e1) {
				Bukkit.getLogger().info("oopsie doopsie!");
			}
	}
	
	private Location rayForward(Player p)
	{
		int count = 0;
		Location loc = p.getLocation().clone().add(new Vector(0, 1, 0));
		Vector dir = loc.getDirection().clone().multiply(0.25);
		while (count < 100)
		{
			count++;
			loc.add(dir);
		}
		return loc;
	}
	
	private void refreshAll()
	{
		boolean visible;
		if (player == null)
			return;
		for (Entity entity:player.getWorld().getEntities())
		{
			visible = entity.isGlowing();
			entity.setGlowing(true);
			entity.setGlowing(false);
			entity.setGlowing(visible);
		}
	}
	
	private Entity entityFromID(int id)
	{
		for (World world:Bukkit.getWorlds())
			for (Entity entity:world.getEntities())
				if (entity.getEntityId() == id)
					return entity;
		return null;
	}
}
