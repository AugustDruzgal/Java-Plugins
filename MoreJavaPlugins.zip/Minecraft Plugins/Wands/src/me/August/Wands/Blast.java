package me.August.Wands;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Blast extends Spell {

	Blast(Player p, Plugin pl) {
		super(p, pl);
		setIcons(Material.GUNPOWDER, 1, Material.GUNPOWDER, 2);
		setMaxCooldown(60);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
		
	}
	
	@Override
	public void spellEffect() {
		
		new BukkitRunnable() {
			
			int power = 1;
			
			Location loc = player.getLocation().clone().add(new Vector(0, 1.25, 0));
			Vector dir = loc.getDirection().clone().normalize().multiply(0.025);
			Vector offset = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(1);
			DustOptions dust = new DustOptions(Color.WHITE, 1);
			int timer = 0;
			
			
			@Override
			public void run() {
				
				for (int i = 0 ; i < 100 ; i++) {
					
					offset.rotateAroundNonUnitAxis(dir, Math.PI/5);
					offset.normalize().multiply(0.25);
					
					loc.add(dir);
					if (i%5 == 0) {

						loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.01, dust, true);
						loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().subtract(offset), 1, 0, 0, 0, 0.01, dust, true);
						
					}
					if (hit(loc, power)) {
					
						i = 123;
						timer = 100;
					
					}
					
				}
				
				if (timer%6 == 2) {
					power = power + 1;
					loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 25, 0, 0, 0, 0.3, null, true);
					loc.getWorld().playSound(loc, Sound.ITEM_CROSSBOW_SHOOT, 1, 3);
					loc.getWorld().playSound(player.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1, 3);
					loc.getWorld().playSound(loc, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1, 3);
					loc.getWorld().playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1, 3);
				}
				
				timer++;
				if (timer > 30) cancel();
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public boolean hit(Location loc, int power) {
		
		boolean hitsuccessful = false;
		Vector dir = loc.clone().getDirection().multiply(0.01);
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities()) {
			
			if (entity != player && entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector())) {
				
				hitsuccessful = true;
				
				dir.normalize().multiply(0.5);
				
			}
			
		}
		
		if (!loc.getBlock().isPassable()) {
			
			hitsuccessful = true;
			
		}
		
		if (hitsuccessful) {
			
			loc.subtract(dir);
			
			loc.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, loc, power * 5, 1.5, 1.5, 1.5, 1, null, true);
			loc.getWorld().playSound(player.getLocation(), Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 2, 1.5F);
			loc.getWorld().playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST_FAR, 2, 1.4F);
			explode(loc, power/1.25);
			
		}
		
		return hitsuccessful;
		
	}
	
	public void explode(Location l, double size) {
		
		Location loc = l;
		Location currentloc;
		
		for (double x = -size; x < size; x++) {
			
			for (double y = -size; y < size; y++) {
			
				for (double z = -size; z < size; z++) {
					
					currentloc = loc.clone().getBlock().getLocation().add(new Vector(x, y, z));
					
					if (loc.distance(currentloc) < size) {
						
						if (currentloc.getBlock().getType().getBlastResistance() <= 6) {
							
							TemporaryBlockManager.setBlock(currentloc, Material.AIR, 60 + 20 * (size - loc.distance(currentloc)), plugin);
							
						}
						
					}
					
				}
				
			}
			
		}
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities()) {
			
			double distance = entity.getBoundingBox().getCenter().distance(loc.toVector());
			Vector launchvel = loc.clone().subtract(entity.getLocation()).toVector().setY(0).normalize().setY(-0.3).multiply(-0.7 * ((size + 1)- distance));
			
			if (distance < (size + 1)) {
				entity.damage(((size+1) - distance) * 1.6);
				entity.setVelocity(launchvel);
			}
			
		}
		
	}
	
}
