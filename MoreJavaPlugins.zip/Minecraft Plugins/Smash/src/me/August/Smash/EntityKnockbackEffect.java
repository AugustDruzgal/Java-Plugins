package me.August.Smash;

import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class EntityKnockbackEffect {
	EntityKnockbackEffect(Entity e, Vector dir, Plugin p, Float per) {
		if(per > 150) {
			
			new BukkitRunnable() {
				
				int timer = 0;
				
				public void run() {
					e.setVelocity(dir.normalize().add(new Vector(0,0.6,0)).normalize().multiply(6));
				}
			
			}.runTaskTimer(p, 0, 1);
		
	}
}
