// August Druzgal
// COP 3502C, Spring 2022
// Using Notepad++ and Linux bash shell on Windows 10

#include <stdio.h>

int main(void)
{
	printf("Hello, world!\n");
	return 0;
}
