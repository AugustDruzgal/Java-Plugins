package me.August.Abilities.Util;

import java.util.HashMap;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class Skill {
	
	protected Player player;
	protected Plugin plugin;
	String type;
	public HashMap<Material, Boolean> acceptable;
	protected int cooldown = 0;
	protected int maxCooldown = 100;
	
	protected Skill(Player p, Plugin pl)
	{
		player = p;
		plugin = pl;
	}
	
	public void activate(int level)
	{
		if (cooldown == 0)
		{
			effect(level);
		}
	}
	
	// @Override this
	public void effect(int level)
	{
		
	}
	
	public void startCooldown(int ticks, boolean show)
	{
		cooldown = ticks;
		new BukkitRunnable()
		{
			int max = ticks;
			@Override
			public void run()
			{
				cooldown--;
				if (cooldown == 0)
				{
					cancel();
				}
				else
				{
					if (show && acceptable.containsKey(player.getInventory().getItemInMainHand().getType()))
					{
						displayCooldownBar(cooldown, max);
					}
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public void setAcceptable(HashMap<Material, Boolean> a)
	{
		acceptable = a;
	}
	
	public void setMaxCooldown(int max)
	{
		maxCooldown = max;
		startCooldown(max, true);
	}
	
	public void displayCooldownBar(long ticks, long max)
	{
		long counter = ticks;
		TextComponent component = Component.text("Cooldown : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - (max / 40);
			if (counter <= 0)
				component = component.append(Component.text("|").color(TextColor.color(20, 255, 50)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		component = component.append(Component.text(" - ").color(TextColor.color(255, 255, 255)));
		component = component.append(Component.text(ticks/20 + "." + ((ticks/2)%10)).color(TextColor.color(255, 255, 255)));
		component = component.append(Component.text("s").color(TextColor.color(255, 255, 255)));
		player.sendActionBar(component);
	}
	
	public static HashMap<Material, Boolean> getSwords()
	{
		HashMap<Material, Boolean> s = new HashMap<>();
		
		s.put(Material.WOODEN_SWORD, true);
		s.put(Material.STONE_SWORD, true);
		s.put(Material.GOLDEN_SWORD, true);
		s.put(Material.IRON_SWORD, true);
		s.put(Material.DIAMOND_SWORD, true);
		s.put(Material.NETHERITE_SWORD, true);
		
		return s;
	}
	
	public static HashMap<Material, Boolean> getAxes()
	{
		HashMap<Material, Boolean> a = new HashMap<>();
		
		a.put(Material.WOODEN_AXE, true);
		a.put(Material.STONE_AXE, true);
		a.put(Material.GOLDEN_AXE, true);
		a.put(Material.IRON_AXE, true);
		a.put(Material.DIAMOND_AXE, true);
		a.put(Material.NETHERITE_AXE, true);
		
		return a;
	}
}
