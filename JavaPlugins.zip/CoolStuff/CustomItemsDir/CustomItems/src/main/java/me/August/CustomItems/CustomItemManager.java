package me.August.CustomItems;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class CustomItemManager {
	
	static ArrayList<CustomItem> customItems = new ArrayList<>();
	static ArrayList<AbilityItem> abilityItems = new ArrayList<>();
	static HashMap<String, CustomItem> customItemLog = new HashMap<>();
	
	public static void addCustomItem(CustomItem item, String name)
	{
		customItems.add(item);
		customItemLog.put(name, item);
	}
	
	public static void addAbilityItem(AbilityItem item)
	{
		abilityItems.add(item);
	}
	
	public static CustomItem getCustomItem(ItemStack item)
	{
		for (CustomItem customItem:customItems)
		{
			if (item.isSimilar(customItem.getItemStack()))
				return customItem;
		}
		return null;
	}
	
	public static CustomItem getCustomItem(String name)
	{
		return customItemLog.get(name);
	}
	
	public static boolean isCustomItem(ItemStack item)
	{
		for (CustomItem customItem:customItems)
		{
			if (item.isSimilar(customItem.getItemStack()))
				return true;
		}
		return false;
	}
	
	public static void updateAbilityItems()
	{
		for (AbilityItem item:abilityItems)
		{
			item.update();
		}
	}
	
	public static void updateDisplayItems()
	{
		ItemStack invItem;
		for (Player player:Bukkit.getOnlinePlayers())
		{
			if (!PlayerData.isActive(player))
				continue;
			for (AbilityItem item:abilityItems)
			{
				for (int i = 0; i < 36; i++)
				{
					invItem = player.getInventory().getItem(i);
					if (invItem == null)
						continue;
					if (item.compare(invItem))
					{
						player.getInventory().setItem(i, item.getCooldownItemStack(player));
						i = 100;
					}
				}		
			}
		}
	}
	
	public static void onRightClick(ItemStack item, Player player)
	{
		for (CustomItem customItem:customItems)
		{
			if (item.isSimilar(customItem.getItemStack()))
			{
				customItem.onRightClick(player);
				return;
			}
		}
	}
	
	public static void onSelectItem(ItemStack item, Player player)
	{
		for (AbilityItem abilityItem:abilityItems)
		{
			if (abilityItem.compare(item))
			{
				abilityItem.activate(player);
				return;
			}
			else
			{
				player.sendMessage("not similar");
			}
		}
	}
	
	public static void initPlayers()
	{
		for (Player player:Bukkit.getOnlinePlayers())
		{
			for (CustomItem item:customItems)
			{
				item.initPlayer(player);
			}
			for (AbilityItem item:abilityItems)
			{
				item.init(player);
			}
		}
	}
	
	public static void initPlayer(Player player)
	{
		for (CustomItem item:customItems)
		{
			item.initPlayer(player);
			player.getInventory().addItem(item.getItemStack());
		}
		for (AbilityItem item:abilityItems)
		{
			item.init(player);
		}
	}
}
