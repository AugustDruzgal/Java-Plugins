package me.August.MechArmor;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class AttackManager {
	
	int size;
	
	Player player;
	Plugin plugin;
	
	AttackManager(Player p, Plugin pl) {
		
		player = p;
		plugin = pl;
		size = 0;
		
		new BukkitRunnable() {
			
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				
				if(player.isSneaking() && Main.managers.get(player).getInv() == 1 && !player.isOnGround()) {
					
					size = size + 1;
					
				} else if (player.isSneaking() && Main.managers.get(player).getInv() == 1 && player.isOnGround() && size > 20) {
					
					Location loc = player.getLocation();
					
					for(LivingEntity entity : player.getWorld().getLivingEntities()) {
						
						if(loc.distance(entity.getLocation()) < 3 && entity != player) {
							
							entity.damage((size/10) * (3 - loc.distance(entity.getLocation())));
							Vector dir = entity.getLocation().clone().subtract(loc).toVector().normalize().multiply((size/5) * (3 - loc.distance(entity.getLocation())));
							entity.setVelocity(dir.setY(Math.abs(dir.getY())).add(new Vector(0,0.7,0)));
							
						}
						
					}
					
					loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, size * 10, 3, 3, 3, Material.DIRT.createBlockData());
					loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_FALL, 1, 1);
					loc.getWorld().playSound(loc, Sound.BLOCK_GILDED_BLACKSTONE_BREAK, 1, 1);
					loc.getWorld().playSound(loc, Sound.BLOCK_ROOTED_DIRT_BREAK, 1, 1);
					
					player.setVelocity(player.getVelocity().add(new Vector(0,0.5,0)));
					
					size = 0;
					
				} else if(size <= 20) {
					
					size = 0;
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void attack(int which) {
		
		switch (which) {
		
		case 0:
			
			new BukkitRunnable() {
				
				int timer = 0;
				
				@Override
				public void run() {
					
					new FlameThrower(player, plugin);
					timer++;
					
					player.playSound(player.getLocation(), Sound.BLOCK_CANDLE_EXTINGUISH, 1, 1);
					
					if (timer > 4) {
						
						cancel();
						
					}
					
				}
				
			}.runTaskTimer(plugin, 0, 1);
			
		
		}
		
	}
	
}
