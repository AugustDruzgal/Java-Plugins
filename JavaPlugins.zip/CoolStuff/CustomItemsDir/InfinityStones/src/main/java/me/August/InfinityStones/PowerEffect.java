package me.August.InfinityStones;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public abstract class PowerEffect {
	
	abstract boolean effect(Player player, Location loc, LivingEntity target);

}
