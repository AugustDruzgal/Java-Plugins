package me.August.Abilities.Wind;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class SwordThrow extends Skill {

	BukkitTask charge = null;
	ItemStack item;
	int slot;
	int time = 0;
	float power = 0;
	
	public SwordThrow(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	public void effect()
	{
		if (power < 100)
			player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5F, (float) (0.5 + (power/100)));
		if (charge == null)
		{
			time = 5;
			charge = new BukkitRunnable()
			{
				@Override
				public void run()
				{
					time--;
					if (power >= 100)
						power = 100;
					else
						power = power + 6;
					displayChargeBar(power);
					if (!acceptable.containsKey(player.getInventory().getItemInMainHand().getType()))
					{
						power = 0;
						charge = null;
						startCooldown(140, true);
						cancel();
					}
					if (time == 0)
					{
						throwSword();
						power = 0;
						charge = null;
						startCooldown(140, true);
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
		else
		{
			time = 5;
		}
	}
	
	private void displayChargeBar(float power2)
	{
		double counter = power2;
		TextComponent component = Component.text("Charge : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - 2.5;
			if (counter >= 0)
				component = component.append(Component.text("|").color(TextColor.color(40, 255, 100)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		player.sendActionBar(component);
	}
	
	private void throwSword()
	{
		new BukkitRunnable()
		{
			Location loc = player.getLocation().clone().add(new Vector(0, 1, 0));
			Vector dir = loc.getDirection().clone().normalize().multiply(0.25);
			ArmorStand swordmodel = getStand();
			Vector offset = getOffset(dir);
			int count = 0;
			int temp;
			boolean active = true;
			Material type;
			
			@Override
			public void run()
			{
				if (count == 0)
				{
					updateItem();
					player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SPLASH_POTION_THROW, 0.8F, 0.8F);
					player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc.clone().add(dir.clone().multiply(2.5)), 1, 0, 0, 0, 1, null, true);
				}
				if (active == true)
				{
					for (int i = 0; i < 8; i++)
					{
						loc = loc.add(dir);
						swordmodel.teleport(loc.clone().add(offset));
						if (hitEntity(loc))
						{
							active = false;
							i = 20;
							count = 37;
						}
						else if (!loc.getBlock().isPassable())
						{
							i = 20;
							type = loc.getBlock().getType();
							temp = 20;
							active = false;
							
							while (!loc.getBlock().isPassable() && temp > 0)
							{
								temp--;
								loc = loc.add(dir.clone().normalize().multiply(-0.05));
								count = 20;
							}
							loc = loc.add(dir.clone().normalize().multiply(-0.6));
							swordmodel.teleport(loc.clone().add(offset));
							loc.getWorld().playSound(loc, Sound.BLOCK_WOOD_BREAK, 1F, 1F);
							loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 40, 0.3, 0.3, 0.3, 1, type.createBlockData(), true);
						}
					}
				}

				count++;
				if (count == 44)
				{
					swordmodel.remove();
					if (player.getInventory().getItem(slot) == null)
						player.getInventory().setItem(slot, item);
					else if (!player.getInventory().addItem(item).isEmpty())
						player.getWorld().dropItem(player.getLocation(), item);
					cancel();
				}
				else if (count == 40)
				{
					active = false;
					swordmodel.teleport(player.getLocation().clone().add(offset).add(new Vector(0, 1, 0)));
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private ArmorStand getStand()
	{
		Location loc = player.getLocation().clone();
		Vector dir = loc.getDirection();
		ArmorStand swordmodel = (ArmorStand) player.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
		ItemStack item = player.getInventory().getItemInMainHand().clone();
		ItemMeta meta = item.getItemMeta();
		meta.setCustomModelData(0);
		item.setItemMeta(meta);
		swordmodel.setMarker(true);
		swordmodel.setInvisible(true);
		swordmodel.setArms(true);
		swordmodel.setRightArmPose(armorEulerFromVector(dir));
		swordmodel.setItem(EquipmentSlot.HAND, item);
		swordmodel.setGravity(false);
		return swordmodel;
	}
	
	private Vector getOffset(Vector dir)
	{
		Vector offset = dir.clone().rotateAroundAxis(dir.clone().crossProduct(new Vector(0, 1, 0)), Math.PI * 0.5).normalize().multiply(0.5);
		offset = offset.add(dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.36));
		offset = offset.add(new Vector(0, -1.35, 0));
		return offset;
	}
	
	private EulerAngle armorEulerFromVector(Vector v)
	{
		Vector vector = v.clone().normalize();
		EulerAngle angle = new EulerAngle((vector.getY() + 1.00) * Math.PI * -0.5 + Math.PI/2 - 0.2, 0, 0);
		return angle;
	}
	
	private void updateItem()
	{
		item = player.getInventory().getItemInMainHand().clone();
		slot = player.getInventory().getHeldItemSlot();
		player.getInventory().setItem(slot, new ItemStack(Material.AIR));
	}
	
	private boolean hitEntity(Location loc)
	{
		boolean hit = false;
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities()) 
		{
			if (entity != player && entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector()))
			{
				entity.setNoDamageTicks(0);
				entity.damage(8);
				player.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_STRONG, 0.8F, 1.2F);
				player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc, 1, 0, 0, 0, 1, null, true);
				hit = true;
				break;
			}
		}
		
		return hit;
	}

}
