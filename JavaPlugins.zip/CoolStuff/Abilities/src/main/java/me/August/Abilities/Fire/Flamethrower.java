package me.August.Abilities.Fire;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.Skill;

public class Flamethrower extends Skill {
	
	public Flamethrower(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() >= 15)
		{
			new BukkitRunnable()
			{
				int time = 0;
				@Override
				public void run()
				{
					shootFire();
					manager.removeMana(4);
					manager.setPause(1);
					time++;
					if (time > 4)
						cancel();
				}
			}.runTaskTimer(plugin, 0, 1);
		}
	}
	
	private boolean igniteNearby(Location loc)
	{
		boolean hit = false;
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector()))
			{
				entity.setFireTicks((entity.getFireTicks() > 50)?70:entity.getFireTicks()+15);
				entity.damage(1);
				hit = true;
				entity.getWorld().playSound(entity.getLocation(), Sound.BLOCK_CAMPFIRE_CRACKLE, 0.5F, 1.5F);
			}
		}
		
		return hit;
	}
	
	private void shootFire()
	{
		Item fire;
		fire = player.getWorld().dropItem(
				player.getLocation().clone().add(new Vector(0, 1, 0)), new ItemStack(Material.BLAZE_POWDER));
		fire.setCanPlayerPickup(false);
		fire.setCanMobPickup(false);
		fire.setVelocity(player.getLocation().getDirection().clone().add(
				new Vector(Math.random() - 0.5, Math.random() - 0.35, Math.random() - 0.5).multiply(0.175)).multiply(2.5));
		fire.getWorld().playSound(player.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.5F, 1.5F);
		new BukkitRunnable()
		{
			int timer = 0;
			@Override
			public void run()
			{
				if (igniteNearby(fire.getLocation()))
					timer = 30;
				timer++;
				if (timer > 18)
				{

					fire.getWorld().spawnParticle(Particle.LAVA, fire.getLocation(), 1, 0, 0, 0, 1, null, true);
					cancel();
					fire.remove();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
}
