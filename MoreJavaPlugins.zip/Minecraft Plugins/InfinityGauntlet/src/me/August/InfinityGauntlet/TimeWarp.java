package me.August.InfinityGauntlet;

import org.bukkit.Color;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class TimeWarp {
	Player player;
	
	TimeWarp(Player p, Plugin plugin) {
		
		player = p;
		player.getWorld().setGameRule(GameRule.RANDOM_TICK_SPEED, 5000);
		
		new BukkitRunnable() {
			int timer = 0;
			@Override
			public void run() {
				Vector spelloffset = player.getLocation().getDirection().clone().setY(0).normalize().rotateAroundY(-Math.PI/2).multiply(0.35);
				Vector eyeheight = new Vector(0,1,0);
				Vector forwards = player.getLocation().getDirection().clone().multiply(0.7);
				Location loc = player.getLocation().clone().add(spelloffset).add(eyeheight).add(forwards);
				timer++;
				timeParticle(loc, player.getLocation().getDirection(), 0.7F);
				timeParticle(player.getLocation().clone().add(new Vector(0,0.1,0)), loc.getDirection().clone().setX(0).setZ(0.001).setY(1000).normalize(), 2);
				player.getWorld().setTime(player.getWorld().getTime() + 200);
				if (timer > 40) {
					cancel();
					player.getWorld().setGameRule(GameRule.RANDOM_TICK_SPEED, 3);
				}
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void timeParticle(Location l, Vector dir, float size) {
		Location loc = l.clone();
		Vector offset = dir.clone().setY(0).normalize().multiply(size).rotateAroundY(Math.PI/2);
		float circledensity = 120 * size;
		float squaredensity = size * 26;
		float thickness = 0.2F;
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(size * 1.1);
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(Math.sqrt(Math.pow(size, 2)/2));
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(Math.sqrt(Math.pow(size, 2)/2) - size*0.1);
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(size);
		loc = loc.add(offset);
		offset.rotateAroundNonUnitAxis(dir, 3*Math.PI/4);
		offset.normalize().multiply(Math.sqrt(size*size + size*size)/squaredensity);
		for(int i = 0; i < 4 ; i++) {
			for(int j = 0 ; j < squaredensity ; j++) {
				loc.add(offset);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			}
			offset.rotateAroundNonUnitAxis(dir, Math.PI/2);
		}
		offset = dir.clone().setY(0).normalize().multiply(size).rotateAroundY(Math.PI/2).rotateAroundNonUnitAxis(dir, Math.PI/4);
		loc = l.clone().add(offset);
		offset.rotateAroundNonUnitAxis(dir, 3*Math.PI/4);
		offset.normalize().multiply(Math.sqrt(size*size + size*size)/squaredensity);
		for(int i = 0; i < 4 ; i++) {
			for(int j = 0 ; j < squaredensity ; j++) {
				loc.add(offset);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			}
			offset.rotateAroundNonUnitAxis(dir, Math.PI/2);
		}
	}
}
