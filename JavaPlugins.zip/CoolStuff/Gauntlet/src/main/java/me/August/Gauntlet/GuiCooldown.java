package me.August.Gauntlet;

public class GuiCooldown {
	
	int maxCooldown = 100;
	int cooldown = 0;
	
	public GuiCooldown(int maxCooldown)
	{
		this.maxCooldown = maxCooldown;
	}
	
	public void updateCooldown()
	{
		if (cooldown > 0)
			cooldown--;
	}
	
	public int getCooldown()
	{
		return cooldown;
	}
	
	public void setCooldown(int cooldown)
	{
		this.cooldown = cooldown;
	}
	
	public void startCooldown()
	{
		this.cooldown = this.maxCooldown;
	}
	
	public int getMaxCooldown()
	{
		return this.maxCooldown;
	}
	
	public void setMaxCooldown(int maxCooldown)
	{
		this.maxCooldown = maxCooldown;
	}
	
	public GuiCooldown clone()
	{
		return new GuiCooldown(this.maxCooldown);
	}

}
