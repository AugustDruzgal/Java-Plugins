package me.August.Abilities;

import me.August.Abilities.Util.PassiveSkill;
import me.August.Abilities.Util.Skill;

public class AbilitySet {
	
	private Skill sword;
	private Skill axe;
	private PassiveSkill passive;
	
	AbilitySet(Skill s, Skill a, PassiveSkill p)
	{
		sword = s;
		axe = a;
		passive = p;
	}
	
	public Skill getSword()
	{
		return sword;
	}
	
	public Skill getAxe()
	{
		return axe;
	}
	
	public PassiveSkill getPassive()
	{
		return passive;
	}
	
	public void setSword(Skill skill)
	{
		sword = skill;
	}
	
	public void setAxe(Skill skill)
	{
		axe = skill;
	}
	
	public void setPassive(PassiveSkill skill)
	{
		passive = skill;
	}
}
