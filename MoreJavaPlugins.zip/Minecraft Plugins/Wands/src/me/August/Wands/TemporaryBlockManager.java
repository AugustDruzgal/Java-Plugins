package me.August.Wands;

import java.util.HashMap;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.plugin.Plugin;

public class TemporaryBlockManager {
	
	static HashMap<Location, TemporaryBlock> tempBlocks = new HashMap<Location, TemporaryBlock>();
	
	public static void setBlock(Location l, Material material, double duration, Plugin plugin) {
		
		Location loc = l.getBlock().getLocation();
		
		if (tempBlocks.containsKey(loc)) {
			
			tempBlocks.get(loc).setCancelled();
			tempBlocks.put(loc, new TemporaryBlock(plugin, loc, material, duration, tempBlocks.get(loc).original, tempBlocks.get(loc).originaldata));
			
		} else {
		
			tempBlocks.put(loc, new TemporaryBlock(plugin, loc, material, duration));
		
		}
		
	}

}
