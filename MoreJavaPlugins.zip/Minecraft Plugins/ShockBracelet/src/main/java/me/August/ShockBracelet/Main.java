package me.August.ShockBracelet;

import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener {

	@Override 
	public void onEnable() {
		Bukkit.getLogger().info("yeet");
	}
	
	@Override
	public void onDisable() {
		Bukkit.getLogger().info("yeet");
	}
	
}
