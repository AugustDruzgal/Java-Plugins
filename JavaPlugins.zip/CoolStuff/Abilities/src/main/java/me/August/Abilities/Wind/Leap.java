package me.August.Abilities.Wind;

import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.PassiveSkill;

public class Leap extends PassiveSkill {

	boolean useable = true;
	
	public Leap(Player p, Plugin pl) {
		super(p, pl);
	}
	
	@Override
	public void passive(int level)
	{
		if (active == false)
			return;
		toggle();
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() >= 120 && useable)
		{
			manager.removeMana(100 - 10 * level);
			player.setVelocity(player.getLocation()
					.clone()
					.getDirection()
					.normalize()
					.add(new Vector(0, 0.2, 0))
					.normalize()
					.multiply(0.6 + 0.15 * level));
			useable = false;
			player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 40, 0.3, 0.3, 0.3, 0.2, null, true);
			new BukkitRunnable()
			{
				int time = 0;
				@Override
				public void run()
				{
					time++;
					if (time < 15)
						player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 2, 0, 0, 0, 0.04, null, true);
					if (time > 100 || !player.getLocation().clone().add(new Vector(0, -0.02, 0)).getBlock().isPassable())
					{
						useable = true;
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
	}
}
