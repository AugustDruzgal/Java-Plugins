package me.August.InfinityGauntlet;

import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class SpaceWarp {
	
	Player player;
	Plugin plugin;
	boolean flying;
	boolean allowflight;
	
	SpaceWarp(Player p, Plugin pl) {
		
		player = p;
		plugin = pl;
		flying = player.isFlying();
		allowflight = player.getAllowFlight();
		Location loc = player.getLocation();
		Vector offset = player.getLocation().getDirection().clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(2);
		GameMode gamemode = player.getGameMode();
		particleportal(loc.add(new Vector(0,0.3,0)), offset, 1);
		
		new BukkitRunnable() {
			
			int time2 = 0;
			int time = 0;
			int stopping = 0;
			int yes = 0;
			Location last = player.getLocation();
			boolean go = false;
			
			@Override
			public void run() {
				
				time2++;
				
				if(time2 > 30) {
					if(last.distance(player.getLocation()) < 0.05) {
						if (go == true && player.getLocation().getBlock().isPassable()) {
							stopping++;
							if (stopping > 2) {
								time++;
							}
						}
					} else if (yes == 1) {
						time++;
					} else {
						go = true;
						stopping = 0;
					}
				}
				
				Location loc = player.getLocation();
				Vector offset = player.getLocation().getDirection().clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(2);
				last = player.getLocation();
				
				if(time == 5) {
					yes = 1;
					loc = player.getLocation();
					offset = player.getLocation().getDirection().clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(2);
					particleportal(loc.clone().add(new Vector(0,0.3,0)), offset, 0);
					player.setVelocity(new Vector(0,0,0));
				} else if (time > 5) {
					if(time < 25) {
						
						player.setVelocity(new Vector(0,0,0));
						
					} else if (time == 25) {
						
						player.setGameMode(gamemode);
						new BukkitRunnable() {
							
							int timer = 0;
							
							@Override
							public void run() {
								
								player.setVelocity(new Vector(0,0,0));
								
								timer++;
								if(timer > 10) {
									cancel();
								}
								
							}
							
						}.runTaskTimer(plugin, 0, 1);
						cancel();
						
					}
				}
				
				if(time2 < 50) {
					
					player.setVelocity(new Vector(0,0,0));
					time = 0;
					
				}
				
				if (time2 == 50) {
					
					player.setGameMode(GameMode.SPECTATOR);
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void particleportal(Location l, Vector off, int type) {
		
		l.getWorld().spawnParticle(Particle.REDSTONE, l, 300, 1, 1, 1, 0.5, new DustOptions(Color.AQUA, 0.5F), true);
		
		if(type == 0) {
			new BukkitRunnable() {
				Vector offset = off;
				Vector modoff;
				Location loc = l.add(l.getDirection().clone().setY(0).normalize().multiply(1.8));
				Vector dir = player.getLocation().getDirection().clone().setY(0).normalize();
				int timer = 0;
				double dist;
				double size;
				@Override
				public void run() {
					size = 20 * Math.cos((40-timer) * (Math.PI/60) - (Math.PI/6));
					offset = offset.normalize().multiply(0.15*size);
					loc = loc.add(dir.clone().multiply(-0.06));
					for(int i = 0 ; i < size*10 ; i++) {
						offset.rotateAroundAxis(dir, Math.PI/(5*size));
						player.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0.02, 0.02, 0.02, 0.4, new DustOptions(Color.GRAY, 1.5F), true);
						dist = size * 0.15 * Math.random();
						modoff = offset.clone().normalize().multiply(dist);
						player.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(modoff), 1, 0, 0, 0, 0.4, new DustOptions(Color.BLUE, 1F), true);
					}
					player.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE, loc.clone(), 20, 0, 0, 0, 2, null, true);
					timer++;
					if(timer > 60) {
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		} else {
			new BukkitRunnable() {
				Vector offset = off;
				Vector modoff;
				Location loc = l.add(l.getDirection().clone().setY(0).normalize().multiply(-1.8));
				Vector dir = player.getLocation().getDirection().clone().setY(0).normalize();
				int timer = 0;
				double dist;
				double size;
				@Override
				public void run() {
					size = 20 * Math.cos((40-timer) * (Math.PI/60) - (Math.PI/6));
					offset = offset.normalize().multiply(0.15*size);
					loc = loc.add(dir.clone().multiply(0.06));
					for(int i = 0 ; i < size*10 ; i++) {
						offset.rotateAroundAxis(dir, Math.PI/(5*size));
						player.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0.02, 0.02, 0.02, 0.4, new DustOptions(Color.GRAY, 1.5F), true);
						dist = size * 0.15 * Math.random();
						modoff = offset.clone().normalize().multiply(dist);
						player.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(modoff), 1, 0, 0, 0, 0.4, new DustOptions(Color.BLUE, 1F), true);
					}
					player.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE, loc.clone(), 20, 0, 0, 0, 2, null, true);
					timer++;
					if(timer > 60) {
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
		
	}

}

