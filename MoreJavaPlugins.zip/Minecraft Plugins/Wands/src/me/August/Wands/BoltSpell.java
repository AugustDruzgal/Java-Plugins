package me.August.Wands;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class BoltSpell extends Spell {

	BoltSpell(Player p, Plugin pl) {
		super(p, pl);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void spellEffect() {
		Location loc = player.getLocation().clone().add(new Vector(0,1.25,0));
		Vector vel = loc.getDirection().clone().normalize().multiply(0.1);
		
		new BukkitRunnable() {
			
			int timer = 0;
			
			@Override
			public void run() {
				
				if (timer == 0) castEffect(loc);
				
				for (int i = 0 ; i < 100 ; i++) {
					
					loc.add(vel);
					spellParticle(loc);
					spellParticle(loc, timer * 100 + i);
					if (hitEntity(loc)) {
						
						i = 1000;
						timer = 100;
						
					} else if (!loc.getBlock().isPassable()) {
						
						hitGroundEffect(loc);
						i = 1000;
						timer = 100;
						
					}
					
					
				}
				
				timer++;
				
				if (timer > 20) {
					
					cancel();
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public boolean hitEntity(Location loc) {
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities()) {
			
			if (entity != player && entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector())) {
				
				hitEffect(entity, loc);
				
				return true;
				
			}
			
		}
		
		return false;
		
	}
	
	public void castEffect(Location loc) {
		
		// @Override this to create the cast effect
		
	}
	
	public void spellParticle(Location loc) {
		
		// @Override this to create the spell particle
		
	}
	
	public void spellParticle(Location loc, int time) {
		
		// @Override this to create the spell particle with a complex animation
		
	}
	
	public void hitEffect(LivingEntity entity, Location loc) {
		
		// @Override this to create the hit effect
		
		hitGroundEffect(loc);
		
	}
	
	public void hitGroundEffect(Location loc) {
		
		// @Override this to create the hit ground effect
		
	}

}
