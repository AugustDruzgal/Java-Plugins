package me.August.Abilities.Wind;

import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;

public class AxeAir extends Skill {

	public AxeAir(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		player.setVelocity(player.getLocation().getDirection().clone().add(new Vector(0, 0.15, 0).multiply(1.25)));
		startCooldown(100, true);
		new BukkitRunnable()
		{
			int timer = 0;
			@Override
			public void run()
			{
				timer++;
				player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 1, 0, 0, 0, 0, null, true);
				player.setFallDistance(0);
				if (timer > 40)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
}
