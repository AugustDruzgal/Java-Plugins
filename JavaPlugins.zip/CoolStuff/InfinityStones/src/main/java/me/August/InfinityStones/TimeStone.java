package me.August.InfinityStones;

import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class TimeStone extends Stone {
	
	int grow = 0;
	Random random;

	TimeStone(Plugin pl) {
		super(pl);
		name = "Time Stone";
		color = Color.fromRGB(100, 255, 100);
		time = 120;
		random = new Random();
	}
	
	@Override
	public void p()
	{
		Location loc;
		Ageable data;
		DustOptions dust = new DustOptions(color, 1);
		grow++;
		if (grow%5 == 0)
		{
			loc = getRandomNearbyAgeable(player.getLocation());
			if (loc != null)
			{
				data = (Ageable) loc.getBlock().getBlockData();
				data.setAge(data.getAge() + 1);
				loc.getBlock().setBlockData(data);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 20, 0.5, 0.5, 0.5, 0, dust, true);
			}
		}
	}
	
	@Override
	public void a()
	{
		
	}
	
	@Override
	public ItemStack createItem()
	{
		ItemStack new_item = new ItemStack(Material.AMETHYST_SHARD);
		
		ItemMeta meta = new_item.getItemMeta();
		TextComponent name = Component.text("time stone").color(TextColor.color(100, 255, 100));
		meta.displayName(name);
		meta.setCustomModelData(5);
		new_item.setItemMeta(meta);
		
		return new_item;
	}
	
	public Location getRandomNearbyAgeable(Location baseloc)
	{
		BlockData data;
		ArrayList<Location> ageable = new ArrayList<Location>();
		Location loc;
		for (int x = -3; x <= 3; x++)
			for (int y = -2; y <= 2; y++)
				for (int z = -3; z <= 3; z++)
				{
					loc = baseloc.clone().add(new Vector(x, y, z));
					data = loc.getBlock().getBlockData();
					if (data instanceof Ageable)
						if (((Ageable) data).getAge() < ((Ageable) data).getMaximumAge())
							ageable.add(loc);
				}
		if (ageable.size() > 1)
			return ageable.get(random.nextInt(ageable.size() - 1));
		if (ageable.size() == 1)
			return ageable.get(0);
		return null;
	}

}
