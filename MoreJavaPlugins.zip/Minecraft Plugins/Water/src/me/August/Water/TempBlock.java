package me.August.Water;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class TempBlock {
	
	BlockData original;
	BukkitTask task;
	
	TempBlock(Material m, Location loc, int ticks, Plugin p, Boolean replace, BlockData org) {
		if(replace) {
			original = org;
		} else {
			original = loc.getBlock().getBlockData();
			loc.getWorld().setBlockData(loc, m.createBlockData());
		}
		task = new BukkitRunnable() {
			public void run() {
				loc.getBlock().setBlockData(original);
				Main.tempblocks.remove(loc);
			}
		}.runTaskLater(p, ticks);
	}
	
	public BlockData getOriginal() {
		return original;
	}
	
	public void endSchedule() {
		task.cancel();
	}
}
