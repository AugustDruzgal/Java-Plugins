package me.August.Abilities;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class ManaManager {
	
	Player player;
	Plugin plugin;
	long mana = 0;
	long displaymana;
	long max = 400;
	long rate = 1;
	float experience = 0;
	int level = 0;
	int bank = 0;
	int pause = 0;
	boolean display = false;
	
	public ManaManager(Player player)
	{
		this.player = player;
		plugin = Main.getPlugin();
	}
	
	public void displayMana()
	{
		if (display)
		{
			player.setExp((float) (((double) mana/max) * 0.9999F));
		}
	}
	
	public void setDisplayMana(boolean dis)
	{
		if (display == dis)
			return;
		else
		{
			display = dis;
			if (display = true)
			{
				bank = 0;
				experience = player.getExp();
				level = player.getLevel();
			}
			else
			{
				player.setLevel(level);
				player.setExp(experience);
				player.giveExp(bank);
				bank = 0;
			}
		}
	}
	
	public void bankExperience(int amount)
	{
		bank += amount;
	}
	
	public void setPause(int ticks)
	{
		if (pause < ticks)
			pause = ticks;
	}
	
	public long getMana()
	{
		return mana;
	}
	
	public void setMana(long amount)
	{
		mana = amount;
	}
	
	public void removeMana(long amount)
	{
		mana-=amount;
		if (mana < 0)
			mana = 0;
	}
	
	public void recoverMana()
	{
		if (pause > 0)
		{
			pause--;
			return;
		}
		if (mana < max)
		{
			mana += rate;
			if (mana > max)
				mana = max;
		}
	}
}
