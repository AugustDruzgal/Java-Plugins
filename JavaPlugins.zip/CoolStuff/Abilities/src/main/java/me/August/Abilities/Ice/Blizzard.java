package me.August.Abilities.Ice;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.PassiveSkill;
import me.August.Abilities.Util.Utils;
import me.August.TemporaryBlocks.TemporaryBlockManager;

public class Blizzard extends PassiveSkill implements Utils {

	public Blizzard(Player p, Plugin pl) {
		super(p, pl);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() <= 2)
		{
			toggle();
			return;
		}
		manager.removeMana((long) 0.5);
		manager.setPause(1);
		snow(level);
		player.getWorld().spawnParticle(Particle.SNOWFLAKE, player.getLocation(), 4, 4, 2, 4, 0.01, null, true);
		player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2, 0));
		player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 2, 0));
	}
	
	private void snow(int level)
	{
		Location loc = player.getLocation().clone();
		Location temp;
		for (Block block:Utils.getNearbySurfaceBlocks(loc, 3.5 + 0.5 * level))
		{
			temp = block.getLocation().add(new Vector(0, 1, 0));
			TemporaryBlockManager.createTemporaryBlock(temp, Material.SNOW, 60, plugin);
		}
	}

}
