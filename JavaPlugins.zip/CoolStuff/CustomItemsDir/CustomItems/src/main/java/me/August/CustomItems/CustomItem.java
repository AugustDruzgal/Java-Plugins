package me.August.CustomItems;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class CustomItem {
	
	private ItemStack item;
	private int numHotbars = 1;
	
	private HashMap<Player, PlayerData> playerData = new HashMap<>();
	private ArrayList<ItemStack> abilityItems = new ArrayList<>();
	
	public CustomItem(ItemStack item, String name)
	{
		this.item = item;
		CustomItemManager.addCustomItem(this, name);
	}
	
	public void setAbilityItems(ArrayList<ItemStack> abilityItems)
	{
		this.abilityItems = abilityItems;
	}
	
	public void setNumHotbars(int numHotbars)
	{
		this.numHotbars = numHotbars;
	}
	
	public void initPlayer(Player player)
	{
		playerData.put(player, new PlayerData(player, this, numHotbars));
		playerData.get(player).fillInventory(abilityItems);
	}
	
	public void onRightClick(Player player)
	{
		playerData.get(player).toggle();
	}
	
	public void onDrop(Player player)
	{
		playerData.get(player).swapHotbars();
	}
	
	public ItemStack getItemStack()
	{
		return item;
	}
}
