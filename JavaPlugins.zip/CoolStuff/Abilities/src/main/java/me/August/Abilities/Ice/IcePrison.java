package me.August.Abilities.Ice;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import me.August.TemporaryBlocks.TemporaryBlockManager;

public class IcePrison extends Skill {
	
	Vector[] offsets;

	public IcePrison(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
		offsets = getOffsets();
	}
	
	@Override
	public void effect(int level)
	{
		launchIce();
	}
	
	private void launchIce()
	{
		Item ice;
		ice = player.getWorld().dropItem(
				player.getLocation().clone().add(new Vector(0, 1, 0)), new ItemStack(Material.ICE));
		ice.setCanPlayerPickup(false);
		ice.setCanMobPickup(false);
		ice.setVelocity(player.getLocation().getDirection().clone().add(
				new Vector(0, 0.15, 0)).multiply(1.5));
		ice.getWorld().playSound(player.getLocation(), Sound.BLOCK_GLASS_HIT, 0.5F, 1.5F);
		startCooldown(160, true);
		new BukkitRunnable()
		{
			int timer = 0;
			@Override
			public void run()
			{
				ice.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, ice.getLocation(), 2, 0, 0, 0, 0.06, null, true);
				if (isTouchingEntity(ice.getLocation()) || ice.isOnGround())
				{
					freeze(ice.getLocation());
					timer = 100;
				}
				timer++;
				if (timer > 60)
				{
					cancel();
					ice.remove();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private boolean isTouchingEntity(Location loc)
	{
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getBoundingBox().expand(0.5).contains(loc.toVector()))
			{
				return true;
			}
		}
		return false;
	}
	
	private void freeze(Location loc)
	{
		Location location = loc.clone().toBlockLocation();
		Location l;
		double duration;
		location.getWorld().playSound(location, Sound.BLOCK_GLASS_BREAK, 1F, 1F);
		for (Vector vector:offsets)
		{
			l = location.clone().add(vector);
			if (l.getBlock().isPassable())
			{
				duration = 100 - vector.getY() * 5 + Math.abs(vector.getX()) * 5 + Math.abs(vector.getZ()) * 5 + Math.round(Math.random() * 5);
				TemporaryBlockManager.createTemporaryBlock(l, Material.ICE, (int) duration, plugin);
				l.getWorld().spawnParticle(Particle.BLOCK_CRACK, l, 10, 0.7, 0.7, 0.7, 1, Material.ICE.createBlockData(), true);
			}
		}
	}
	
	private Vector[] getOffsets()
	{
		Vector[] offs = {
				v(3, -2, 0),
				v(3, -1, -1),
				v(3, -1, 0),
				v(3, -1, 1),
				v(3, 0, -2),
				v(3, 0, -1),
				v(3, 0, 0),
				v(3, 0, 1),
				v(3, 0, 2),
				v(3, 1, -1),
				v(3, 1, 0),
				v(3, 1, 1),
				v(3, 2, 0),
				v(-3, -2, 0),
				v(-3, -1, -1),
				v(-3, -1, 0),
				v(-3, -1, 1),
				v(-3, 0, -2),
				v(-3, 0, -1),
				v(-3, 0, 0),
				v(-3, 0, 1),
				v(-3, 0, 2),
				v(-3, 1, -1),
				v(-3, 1, 0),
				v(-3, 1, 1),
				v(-3, 2, 0),
				v(0, -2, 3),
				v(-1, -1, 3),
				v(0, -1, 3),
				v(1, -1, 3),
				v(-2, 0, 3),
				v(-1, 0, 3),
				v(0, 0, 3),
				v(1, 0, 3),
				v(2, 0, 3),
				v(-1, 1, 3),
				v(0, 1, 3),
				v(1, 1, 3),
				v(0, 2, 3),
				v(0, -2, -3),
				v(-1, -1, -3),
				v(0, -1, -3),
				v(1, -1, -3),
				v(-2, 0, -3),
				v(-1, 0, -3),
				v(0, 0, -3),
				v(1, 0, -3),
				v(2, 0, -3),
				v(-1, 1, -3),
				v(0, 1, -3),
				v(1, 1, -3),
				v(0, 2, -3),
				v(0, 3, -2),
				v(-1, 3, -1),
				v(0, 3, -1),
				v(1, 3, -1),
				v(-2, 3, 0),
				v(-1, 3, 0),
				// v(0, 3, 0),
				v(1, 3, 0),
				v(2, 3, 0),
				v(-1, 3, 1),
				v(0, 3, 1),
				v(1, 3, 1),
				v(0, 3, 2),
				v(0, -3, -2),
				v(-1, -3, -1),
				v(0, -3, -1),
				v(1, -3, -1),
				v(-2, -3, 0),
				v(-1, -3, 0),
				v(0, -3, 0),
				v(1, -3, 0),
				v(2, -3, 0),
				v(-1, -3, 1),
				v(0, -3, 1),
				v(1, -3, 1),
				v(0, -3, 2),
				v(2, 2, 2),
				v(2, 2, 1),
				v(2, 1, 2),
				v(1, 2, 2),
				v(-2, 2, 2),
				v(-2, 2, 1),
				v(-2, 1, 2),
				v(-1, 2, 2),
				v(2, -2, 2),
				v(2, -2, 1),
				v(2, -1, 2),
				v(1, -2, 2),
				v(-2, -2, 2),
				v(-2, -2, 1),
				v(-2, -1, 2),
				v(-1, -2, 2),
				v(2, 2, -2),
				v(2, 2, -1),
				v(2, 1, -2),
				v(1, 2, -2),
				v(-2, 2, -2),
				v(-2, 2, -1),
				v(-2, 1, -2),
				v(-1, 2, -2),
				v(2, -2, -2),
				v(2, -2, -1),
				v(2, -1, -2),
				v(1, -2, -2),
				v(-2, -2, -2),
				v(-2, -2, -1),
				v(-2, -1, -2),
				v(-1, -2, -2),
				v(1, 2, 3),
				v(1, -2, 3),
				v(1, 2, -3),
				v(1, -2, -3),
				v(-1, 2, 3),
				v(-1, -2, 3),
				v(-1, 2, -3),
				v(-1, -2, -3),
				v(1, 3, 2),
				v(1, 3, -2),
				v(1, -3, 2),
				v(1, -3, -2),
				v(-1, 3, 2),
				v(-1, 3, -2),
				v(-1, -3, 2),
				v(-1, -3, -2),
				v(2, 1, 3),
				v(2, 1, -3),
				v(2, -1, 3),
				v(2, -1, -3),
				v(-2, 1, 3),
				v(-2, 1, -3),
				v(-2, -1, 3),
				v(-2, -1, -3),
				v(2, 3, 1),
				v(2, 3, -1),
				v(2, -3, 1),
				v(2, -3, -1),
				v(-2, 3, 1),
				v(-2, 3, -1),
				v(-2, -3, 1),
				v(-2, -3, -1),
				v(3, 2, 1),
				v(3, 2, -1),
				v(3, -2, 1),
				v(3, -2, -1),
				v(-3, 2, 1),
				v(-3, 2, -1),
				v(-3, -2, 1),
				v(-3, -2, -1),
				v(3, 1, 2),
				v(3, 1, -2),
				v(3, -1, 2),
				v(3, -1, -2),
				v(-3, 1, 2),
				v(-3, 1, -2),
				v(-3, -1, 2),
				v(-3, -1, -2)
		};
		
		return offs;
	}
	
	private Vector v(int x, int y, int z)
	{
		return new Vector(x, y, z);
	}
}
