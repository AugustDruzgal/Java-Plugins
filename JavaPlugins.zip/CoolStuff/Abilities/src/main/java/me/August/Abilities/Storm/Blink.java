package me.August.Abilities.Storm;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.PassiveSkill;
import me.August.Abilities.Util.Utils;

public class Blink extends PassiveSkill implements Utils {

	public Blink(Player p, Plugin pl) {
		super(p, pl);
	}
	
	@Override
	public void passive(int level)
	{
		if (!active)
			return;
		toggle();
		int range = 5 + level;
		Location loc = player.getLocation().clone().add(new Vector(0, player.getEyeHeight(), 0));
		Location temp;
		Block block;
		Vector dir = loc.getDirection().clone().normalize().multiply(0.1);
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() >= 75)
		{
			manager.removeMana(75);

			block = player.getTargetBlock(range);
			if (block != null && !block.isPassable() && isEnoughSpace(block))
			{
				temp = block.getLocation().toCenterLocation().add(new Vector(0, 0.6, 0)).setDirection(loc.getDirection());
				particle(player.getLocation().clone().add(new Vector(0, 1, 0)), temp.clone().add(new Vector(0, 1, 0)));
				player.teleport(temp);
			}
			else
			{
				for (int i = 0; i < range * 10; i++)
				{
					if (!loc.getBlock().isPassable())
					{
						loc = loc.subtract(dir.clone().normalize().multiply(0.6));
						i = 1000;
					}
					else
					{
						loc.add(dir);
					}
				}
				if (!loc.getBlock().isPassable())
					loc = loc.subtract(dir.clone().normalize().multiply(0.6));
				loc = loc.add(new Vector(0, -1, 0));
				while (!loc.getBlock().isPassable())
					loc = loc.add(new Vector(0, 0.02, 0));
				particle(player.getLocation(), loc);
				player.teleport(loc);
			}
			player.getWorld().playSound(player.getLocation(), Sound.BLOCK_CAMPFIRE_CRACKLE, 1, 2F);
			player.getWorld().playSound(player.getLocation(), Sound.ENTITY_TURTLE_EGG_CRACK, 1, 2F);
		}
	}
	
	private boolean isEnoughSpace(Block block)
	{
		Location loc = block.getLocation();
		for (int i = 0; i < 2; i++)
		{
			loc = loc.add(new Vector(0, 1, 0));
			if (!loc.getBlock().isPassable())
				return false;
		}
		return true;
	}
	
	private void particle(Location start, Location target)
	{
		Utils.arcBetween(start, target, Color.YELLOW);
		Utils.arcBetween(start, target, Color.AQUA);
	}
}
