package me.August.Abilities;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Firework;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import com.destroystokyo.paper.event.player.PlayerPickupExperienceEvent;

import me.August.SwordBlocking.SwordBlockEvent;

public class Main extends JavaPlugin implements Listener {

	static Plugin plugin;
	static HashMap<Player, Manager> managers = new HashMap<>();
	static ArrayList<Material> swords = new ArrayList<>();
	static ArrayList<Material> axes = new ArrayList<>();
	static ArrayList<Material> weapons = new ArrayList<>();
	
	@Override
	public void onEnable()
	{
		plugin = this;
		Bukkit.getPluginManager().registerEvents(this, this);
		ClickManager.initActions();
		this.getCommand("skills").setExecutor(new SkillCommand());
		swords = getSwords();
		axes = getAxes();
		weapons = getWeapons();
		for (Player player:Bukkit.getOnlinePlayers())
			initPlayer(player);
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				for (Player player:Bukkit.getOnlinePlayers())
				{
					managers.get(player).getManaManager().recoverMana();
					managers.get(player).getManaManager().displayMana();
					managers.get(player).getSkillManager().runPassive();
				}
			}
		}.runTaskTimer(this, 0, 1);
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e)
	{
		initPlayer(e.getPlayer());
	}
	
	@EventHandler
	public void onClose(InventoryCloseEvent e)
	{
		managers.get(e.getPlayer()).getInventoryManager().setClosed();
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent e)
	{
		Player player;
		if (e.getWhoClicked() instanceof Player)
			player = (Player) e.getWhoClicked();
		else
			return;
		if (managers.get(player).getInventoryManager().getCurrent() != "none")
		{
			e.setCancelled(true);
			ClickManager.doClick(player, e.getSlot(), this);
		}
	}
	
	@EventHandler
	public void onRightClick(PlayerInteractEvent e)
	{
		Player player = e.getPlayer();
		ItemStack item = e.getItem();
		if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK)
		{
			if (item.getType() == Material.GOLDEN_AXE)
			{
				managers.get(player).getSkillManager().ActivateAbility("axe");
				e.setCancelled(true);
				return;
			}
		}
	}
	
	@EventHandler
	public void onSelectItem(PlayerItemHeldEvent e)
	{
		Player player = e.getPlayer();
		Material item = player.getInventory().getItem(e.getNewSlot()).getType();
		if (weapons.contains(item))
		{
			managers.get(player).getManaManager().setDisplayMana(true);
		}
		else
		{
			managers.get(player).getManaManager().setDisplayMana(false);
		}
	}
	
	@EventHandler
	public void onSwordBlock(SwordBlockEvent e)
	{
		managers.get(e.getPlayer()).getSkillManager().ActivateAbility("sword");
	}
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent e)
	{
		Material type;
		if (managers.get(e.getPlayer()).getInventoryManager().getCurrent() != "none")
		{
			e.setCancelled(true);
		}
		type = e.getItemDrop().getItemStack().getType();
		if (weapons.contains(type))
		{
			managers.get(e.getPlayer()).getSkillManager().togglePassive();
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onExplode(EntityDamageByEntityEvent e)
	{
		Entity entity = e.getDamager();
		if (entity instanceof Firework && entity.getScoreboardTags().contains("nodamage"))
			e.setCancelled(true);
	}
	
	@EventHandler
	public void onExp(PlayerPickupExperienceEvent e)
	{
		Player player = e.getPlayer();
		if (weapons.contains(player.getInventory().getItemInMainHand().getType()))
		{
			managers.get(player).getManaManager().bankExperience(e.getExperienceOrb().getExperience());
			e.getExperienceOrb().remove();
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onSnowball(ProjectileHitEvent e)
	{
		Projectile projectile = e.getEntity();
		Entity entity = e.getHitEntity();
		if (projectile instanceof Snowball)
		{
			if (entity != null && entity instanceof LivingEntity)
			{
				projectile.getWorld().playSound(projectile.getLocation(), Sound.BLOCK_POWDER_SNOW_BREAK, 0.5F, 1F);
				projectile.getWorld().spawnParticle(Particle.SNOWBALL, projectile.getLocation(), 3, 0, 0, 0, 0, null, true);
				entity.setVelocity(projectile.getVelocity().clone().setY(0).normalize().setY(0.25).multiply(0.35));
				e.setCancelled(true);
				projectile.remove();
			}
			else
			{
				projectile.getWorld().playSound(projectile.getLocation(), Sound.BLOCK_POWDER_SNOW_STEP, 0.5F, 1F);
			}
		}
	}
	
	@EventHandler
	public void onFireball(EntityExplodeEvent e)
	{
		Fireball fireball;
		Player player;
		if (e.getEntityType() != EntityType.FIREBALL)
			return;
		fireball = (Fireball) e.getEntity();
		if (fireball.getScoreboardTags().contains("spellfireball"))
		{
			e.setCancelled(true);
			player = (Player) fireball.getShooter();
			createFireballExplosion(fireball.getLocation(), player);
			fireball.remove();
		}
	}
	
	public static Manager getManager(Player player)
	{
		return managers.get(player);
	}
	
	public static Plugin getPlugin()
	{
		return plugin;
	}
	
	public static ArrayList<Material> getSwords()
	{
		ArrayList<Material> swords = new ArrayList<>();
		swords.add(Material.WOODEN_SWORD);
		swords.add(Material.STONE_SWORD);
		swords.add(Material.IRON_SWORD);
		swords.add(Material.GOLDEN_SWORD);
		swords.add(Material.DIAMOND_SWORD);
		swords.add(Material.NETHERITE_SWORD);
		return swords;
	}
	
	public static ArrayList<Material> getAxes()
	{
		ArrayList<Material> axes = new ArrayList<>();
		axes.add(Material.WOODEN_AXE);
		axes.add(Material.STONE_AXE);
		axes.add(Material.IRON_AXE);
		axes.add(Material.GOLDEN_AXE);
		axes.add(Material.DIAMOND_AXE);
		axes.add(Material.NETHERITE_AXE);
		return axes;
	}
	
	public static ArrayList<Material> getWeapons()
	{
		ArrayList<Material> weapons = new ArrayList<>();
		weapons.add(Material.WOODEN_AXE);
		weapons.add(Material.STONE_AXE);
		weapons.add(Material.IRON_AXE);
		weapons.add(Material.GOLDEN_AXE);
		weapons.add(Material.DIAMOND_AXE);
		weapons.add(Material.NETHERITE_AXE);
		weapons.add(Material.WOODEN_SWORD);
		weapons.add(Material.STONE_SWORD);
		weapons.add(Material.IRON_SWORD);
		weapons.add(Material.GOLDEN_SWORD);
		weapons.add(Material.DIAMOND_SWORD);
		weapons.add(Material.NETHERITE_SWORD);
		return weapons;
	}
	
	private void createFireballExplosion(Location loc, Player player)
	{
		double size = 5;
		double distance;
		loc.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, loc, 5, 1, 1, 1, 1, null, true);
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			distance = entity.getLocation().distance(loc);
			if (entity.getLocation().distance(loc) < size)
			{
				entity.setVelocity(entity.getLocation().
						clone().
						subtract(loc)
						.toVector()
						.normalize()
						.setY(0.4)
						.normalize()
						.multiply((size - distance) / size + 1));
				if (entity != player)
				{
					entity.setFireTicks(entity.getFireTicks() + 60);
					entity.damage(3);
				}
				else
				{
					entity.setNoDamageTicks(5);
				}
			}
		}
	}

	private void initPlayer(Player player)
	{
		if (!managers.containsKey(player))
		{
			managers.put(player, new Manager(player));
			managers.get(player).getInventoryManager().openInventory("main");
		}
	}
}
