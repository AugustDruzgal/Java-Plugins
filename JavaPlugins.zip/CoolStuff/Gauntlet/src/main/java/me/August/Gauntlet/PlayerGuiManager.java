package me.August.Gauntlet;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PlayerGuiManager {
	
	static HashMap<Player, PlayerGui> playerGuis;
	
	public static PlayerGui getPlayerGui(Player player)
	{
		return playerGuis.get(player);
	}
	
	public static void addPlayerGui(Player player)
	{
		playerGuis.put(player, new PlayerGui(player));
	}
	
	public static void initPlayerGuis()
	{
		HashMap<Player, PlayerGui> playerGuiMap = new HashMap<>();
		
		for (Player player:Bukkit.getOnlinePlayers())
			playerGuiMap.put(player, new PlayerGui(player));
		
		playerGuis = playerGuiMap;
	}
	
	public static void updateGuis()
	{
		for (Player player:Bukkit.getOnlinePlayers())
		{
			playerGuis.get(player).refresh();
		}
	}
}
