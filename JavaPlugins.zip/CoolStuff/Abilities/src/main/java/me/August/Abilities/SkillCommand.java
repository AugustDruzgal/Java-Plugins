package me.August.Abilities;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SkillCommand implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) 
	{
		if (!(sender instanceof Player))
		{
			return true;
		}
		
		Main.getManager((Player) sender).getInventoryManager().openInventory(Main.getManager((Player) sender).getSkillManager().getCurrent());
		
		return true;
	}
	
}
