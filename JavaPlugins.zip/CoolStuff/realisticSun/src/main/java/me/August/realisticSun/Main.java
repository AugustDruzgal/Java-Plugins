package me.August.realisticSun;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	int active = 0;
	
	@Override
	public void onEnable()
	{
		Bukkit.getPluginManager().registerEvents(this, this);
		active = 1;
		new BukkitRunnable()
		{
			float see;
			List<Player> players = new ArrayList<Player>();
			@Override
			public void run()
			{
				if (active == 0)
					cancel();
				for (World world:Bukkit.getWorlds())
				{
					if (!world.isFixedTime())
					{
						players = world.getPlayers();
						for (Player player:players)
						{
							see = canSeeSun(player);
							if (see < 0.15)
							{
								if (player.hasPotionEffect(PotionEffectType.BLINDNESS))
									break;
								player.damage(4.5);
								player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 400, 10));
							}
							else if (see < 0.25)
								player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 2, 10));
							else if (see < 0.35)
								player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 1, 10));
						}
					}
				}
			}
		}.runTaskTimer(this, 0, 1);
	}
	
	@Override
	public void onDisable()
	{
		active = 0;
	}
	
	private float canSeeSun(LivingEntity e)
	{
		int amount = 0;
		Location loc;
		Vector dir, sun;
		float angle;
		long time = (e.getWorld().getTime() + 775)%24000 - 775;
		
		if (time > 12775 || time < -775 || e.getWorld().hasStorm())
			return 2;
		
		sun = new Vector(0, 0, 0);
		sun.setX(Math.cos(time/(12000/Math.PI)));
		sun.setY(Math.sin(time/(12000/Math.PI))+0.25 * (1 - Math.abs(time/12000)));
		dir = e.getLocation().getDirection().clone();
		
		angle = sun.angle(dir);
		
		if (angle > 0.3)
			return 2;
		
		loc = e.getLocation().clone().add(new Vector(0, e.getEyeHeight(), 0));
		dir.multiply(0.25);
		while (loc.getY() <= 320 && amount < 800)
		{
			amount++;
			if(!loc.getBlock().isPassable())
				return 2;
			loc.add(dir);
		}
		return angle;
	}
}
