package me.August.CustomItems;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class Main extends JavaPlugin {
	
	static BukkitTask tickUpdater;
	
	@Override
	public void onEnable()
	{
		Bukkit.getPluginManager().registerEvents(new EventListener(), this);
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				CustomItemManager.initPlayers();
				tickUpdater = getTickUpdater();
			}
		}.runTaskLater(this, 2);
	}
	
	@Override
	public void onDisable()
	{
		tickUpdater.cancel();
	}
	
	private BukkitTask getTickUpdater()
	{
		return new BukkitRunnable()
		{
			@Override
			public void run()
			{
				CustomItemManager.updateAbilityItems();
				CustomItemManager.updateDisplayItems();
			}
		}.runTaskTimer(this, 0, 1);
	}
}
