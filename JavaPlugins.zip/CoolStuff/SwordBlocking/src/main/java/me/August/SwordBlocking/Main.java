package me.August.SwordBlocking;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;

public class Main extends JavaPlugin implements Listener {
	
	HashMap<Material, Boolean> swords = new HashMap<>();
	HashMap<Action, Boolean> actions = new HashMap<>();
	HashMap<Player, Integer> duration = new HashMap<>();
	
	@Override
	public void onEnable()
	{
		ProtocolManager manager = ProtocolLibrary.getProtocolManager();
		
		Bukkit.getPluginManager().registerEvents(this, this);
		
		for (Player player:Bukkit.getOnlinePlayers())
		{
			duration.put(player, 0);
		}
		
		swords.put(Material.WOODEN_SWORD, true);
		swords.put(Material.STONE_SWORD, true);
		swords.put(Material.GOLDEN_SWORD, true);
		swords.put(Material.IRON_SWORD, true);
		swords.put(Material.DIAMOND_SWORD, true);
		swords.put(Material.NETHERITE_SWORD, true);
		actions.put(Action.RIGHT_CLICK_AIR, true);
		actions.put(Action.RIGHT_CLICK_BLOCK, true);
		
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				for (Player player:Bukkit.getOnlinePlayers())
				{
					if (duration.get(player) > 0)
					{
						player.setWalkSpeed(0.1F);
						duration.put(player, duration.get(player) - 1);
					}
					else if (duration.get(player) == 0)
					{
						duration.put(player, -1);
						if (swords.get(player.getInventory().getItemInMainHand().getType()))
						{
							ItemMeta meta = player.getInventory().getItemInMainHand().getItemMeta();
							meta.setCustomModelData(0);
							player.getInventory().getItemInMainHand().setItemMeta(meta);
						}
					}
					else
						player.setWalkSpeed(0.2F);
				}
			}
		}.runTaskTimer(this, 0, 1);
		
		manager.addPacketListener(new PacketAdapter(this, PacketType.Play.Server.ABILITIES)
		{
			@Override
			public void onPacketSending(PacketEvent event) {
				PacketContainer packet = event.getPacket().deepClone();
				packet.getFloat().write(1, 0.1F);
				event.setPacket(packet);
			}
		});
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e)
	{
		duration.put(e.getPlayer(), 0);
	}
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e)
	{
		Player player = e.getPlayer();
		ItemStack item = player.getInventory().getItemInMainHand().clone();
		
		if (actions.containsKey(e.getAction()))
		{
			if (e.getHand() != EquipmentSlot.OFF_HAND && swords.get(item.getType()))
			{
				duration.put(player, 4);
				e.setCancelled(true);
				ItemMeta meta = player.getInventory().getItemInMainHand().getItemMeta();
				meta.setCustomModelData(2);
				player.getInventory().getItemInMainHand().setItemMeta(meta);
				Bukkit.getPluginManager().callEvent(new SwordBlockEvent(player, item));
			}
		}
	}
	
	@EventHandler
	public void onEntityInteract(PlayerInteractEntityEvent e)
	{
		Player player = e.getPlayer();
		ItemStack item = player.getInventory().getItemInMainHand().clone();
		SwordBlockEvent event;
		if (e.getHand() != EquipmentSlot.OFF_HAND && swords.get(item.getType()))
		{
			event = new SwordBlockEvent(player, item);
			Bukkit.getPluginManager().callEvent(event);
			if (!event.isCancelled())
			{
				duration.put(player, 4);
				e.setCancelled(true);
				ItemMeta meta = player.getInventory().getItemInMainHand().getItemMeta();
				meta.setCustomModelData(2);
				player.getInventory().getItemInMainHand().setItemMeta(meta);
			}
		}
	}
	
	@EventHandler
	public void onSelectItem(PlayerItemHeldEvent e)
	{
		ItemStack item = e.getPlayer().getInventory().getItem(e.getPreviousSlot());
		if (swords.get(item.getType()))
		{
			ItemMeta meta = item.getItemMeta();
			meta.setCustomModelData(0);
			item.setItemMeta(meta);
		}
	}
	
	@EventHandler
	public void onDamaged(EntityDamageByEntityEvent e)
	{
		Player player;
		Entity entity;
		DamageBlockedBySwordEvent event;
		if (!(e.getEntity() instanceof Player) || !(e.getDamager() instanceof LivingEntity))
			return;
		entity = e.getDamager();
		player = (Player) e.getEntity();
		if (duration.get((Player) player) < 0)
			return;
		if (player.getLocation().getDirection().angle(entity.getLocation().clone().toVector().
				subtract(player.getLocation().clone().toVector())) < Math.PI/2)
		{
			event = new DamageBlockedBySwordEvent(player, entity, player.getInventory().getItemInMainHand());
			if (!event.isCancelled())
			{
				player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BLOCK, 0.5F, 1F);
				player.playSound(player.getLocation(), Sound.ITEM_SHIELD_BREAK, 0.5F, 1F);
				e.setDamage(e.getDamage() * 0.35);
			}
		}
	}
}
