package me.August.Abilities.Earth;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.Util.PassiveSkill;

public class Earthquake extends PassiveSkill {
	
	int time = 0;

	public Earthquake(Player p, Plugin pl) {
		super(p, pl);
	}
	
	@Override
	public void passive(int level)
	{
		if (Main.getManager(player).getManaManager().getMana() <= 2)
		{
			toggle();
			return;
		}
		Main.getManager(player).getManaManager().removeMana((long) 0.5);
		Main.getManager(player).getManaManager().setPause(1);
		player.getWorld().spawnParticle(Particle.BLOCK_CRACK, player.getLocation(), 30, 3, 0, 3, 1, Material.DIRT.createBlockData(), true);
		time++;
		if (time%6 == 0)
		{
			quake(player.getLocation());
		}
	}
	
	public void quake(Location loc)
	{
		int ticks;
		loc.getWorld().playSound(loc, Sound.BLOCK_GRAVEL_BREAK, 1F, 0.8F);
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getLocation().distance(loc) < 3.5 && isOnGround(loc))
			{
				ticks = entity.getNoDamageTicks();
				entity.setNoDamageTicks(0);
				entity.damage(1);
				entity.setNoDamageTicks(ticks);
				entity.getWorld().spawnParticle(Particle.BLOCK_CRACK, entity.getLocation(), 15, 0.5, 0.5, 0.5, 1, Material.DIRT.createBlockData(), true);
			}
		}
	}
	
	public boolean isOnGround(Location loc)
	{
		if (!loc.clone().add(new Vector(0, -0.2, 0)).getBlock().isPassable())
			return true;
		return false;
	}

}
