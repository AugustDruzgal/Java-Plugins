package me.August.Superpowers;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	private static HashMap<Player, PlayerPower> powers;
	
	@Override
	public void onEnable()
	{
		this.getCommand("bind").setExecutor(new BindCommand());
		Bukkit.getPluginManager().registerEvents(this, this);
		PowerEffects.init(this);
		powers = new HashMap<Player, PlayerPower>();
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e)
	{
		powers.put(e.getPlayer(), new PlayerPower(e.getPlayer()));
		e.getPlayer().getInventory().addItem(CompoundA.getItem("A10"));
		e.getPlayer().getInventory().addItem(CompoundA.getItem("A15"));
		e.getPlayer().getInventory().addItem(CompoundA.getItem("A20"));
		HotkeyManager.createKeyset(e.getPlayer());
		PowerEffects.initplayer(e.getPlayer());
	}
	
	@EventHandler
	public void onLeave(PlayerQuitEvent e)
	{
		powers.get(e.getPlayer()).resetSpeed();
		powers.remove(e.getPlayer());
	}
	
	@EventHandler
	public void onEntityDamagedByEntity(EntityDamageByEntityEvent e)
	{
		Entity target = e.getEntity();
		Entity damager = e.getDamager();
		double damage = e.getDamage();
		int power;
		
		if (damager instanceof Player && target instanceof LivingEntity)
		{
			PowerEffects.doPunch((Player) damager, (LivingEntity) target);
			power = powers.get(damager).getPowerLevel("Strength");
			if (power > 0)
			{
				damage = damage * Math.pow(1.1, power);
			}
		}
		
		if (target instanceof Player)
		{
			power = powers.get(target).getPowerLevel("Durability");
			if (power > 0)
			{
				damage = damage * Math.pow(1/1.1, power);
			}
		}
		
		e.setDamage(damage);
	}
	
	@EventHandler
	public void onDamaged(EntityDamageByBlockEvent e)
	{
		Entity target = e.getEntity();
		double damage = e.getDamage();
		int power;
		
		if (target instanceof Player)
		{
			power = powers.get(target).getPowerLevel("Durability");
			if (power > 0)
			{
				damage = damage * Math.pow(1/1.1, power);
			}
		}
		
		e.setDamage(damage);
	}
	
	@EventHandler
	public void onFlight(PlayerToggleFlightEvent e)
	{
		Player player = e.getPlayer();
		if (powers.get(player).hasPower("Flight"))
		{
			e.setCancelled(true);
			powers.get(player).toggleFlight();
		}
	}
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e)
	{
		Player player = e.getPlayer();
		if (e.getHand() == EquipmentSlot.HAND && e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK)
		{
			if (e.getItem().isSimilar(CompoundA.getItem("A10")))
			{
				e.setCancelled(true);
				useA(player, 10);
			}
			else if (e.getItem().isSimilar(CompoundA.getItem("A15")))
			{
				e.setCancelled(true);
				useA(player, 15);
			}
			else if (e.getItem().isSimilar(CompoundA.getItem("A20")))
			{
				e.setCancelled(true);
				useA(player, 20);
			}
		}
	}
	
	@EventHandler
	public void onInteractEntity(PlayerInteractAtEntityEvent e)
	{
		
	}
	
	public static PlayerPower getPlayerPower(Player player)
	{
		return powers.get(player);
	}
	
	private void useA(Player player, int amount)
	{
		player.getWorld().spawnParticle(Particle.REDSTONE, player.getLocation().clone().add(new Vector(0, 1, 0)),
				50, 0.5, 1, 0.5, 0, new DustOptions(Color.AQUA, 1f), true);
		player.getWorld().playSound(player.getLocation(), Sound.BLOCK_GLASS_BREAK, 0.5f, 1f);
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_EVOKER_PREPARE_ATTACK, 1f, 1f);
		player.damage(4);
		player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 10, 10));
		powers.get(player).developPowers(amount);
	}
}
