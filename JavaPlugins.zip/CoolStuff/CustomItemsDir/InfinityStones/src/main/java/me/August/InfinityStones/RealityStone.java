package me.August.InfinityStones;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;

import me.August.CustomItems.AbilityEffect;
import me.August.CustomItems.AbilityItem;
import me.August.CustomItems.CustomItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class RealityStone {
	
	private static ItemStack warpItem;
	private static ItemStack weatherItem;
	private static ItemStack harvestItem;
	private static ItemStack cloakItem;
	private static ItemStack stoneItem;
	private static Plugin plugin;
	private static HashMap<Material, Boolean> harvestable;

	public static void initRealityStone(Plugin plugin)
	{
		RealityStone.plugin = plugin;
		initItems();
		createAbilities();
		createStoneItem();
		harvestable = getHarvestableBlocks();
	}
	
	private static void initItems()
	{
		ItemStack item;
		ItemMeta meta;
		List<Component> lore;
		TextComponent name;
		TextColor nameColor = TextColor.color(255, 50, 50);
		TextColor loreColor = TextColor.color(255, 0, 0);
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Reality Stone").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("A stone containing the").color(loreColor));
		lore.add(Component.text("essence of reality").color(loreColor));
		
		meta.setCustomModelData(4);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		stoneItem = item;
		
		item = new ItemStack(Material.REDSTONE);
		meta = item.getItemMeta();
		
		name = Component.text("Reality Warp").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Twist reality around the").color(loreColor));
		lore.add(Component.text("target area, pushing all").color(loreColor));
		lore.add(Component.text("matter caught inside into").color(loreColor));
		lore.add(Component.text("another dimension").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		warpItem = item;
		
		item = new ItemStack(Material.REDSTONE);
		meta = item.getItemMeta();
		
		name = Component.text("Weather change").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Clear the skies or cause it").color(loreColor));
		lore.add(Component.text("to rain").color(loreColor));
		
		meta.setCustomModelData(4);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		weatherItem = item;
		
		item = new ItemStack(Material.REDSTONE);
		meta = item.getItemMeta();
		
		name = Component.text("Harvest").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Harvest all plant life").color(loreColor));
		lore.add(Component.text("connected to the target").color(loreColor));
		lore.add(Component.text("location").color(loreColor));
		
		meta.setCustomModelData(4);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		harvestItem = item;
		
		item = new ItemStack(Material.REDSTONE);
		meta = item.getItemMeta();
		
		name = Component.text("Cloak").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Blend into the world around").color(loreColor));
		lore.add(Component.text("you, hiding yourself and").color(loreColor));
		lore.add(Component.text("any items on you from view").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		cloakItem = item;
	}
	
	public static void createAbilities()
	{
		AbilityItem item;
		item = new AbilityItem(warpItem, getWarpEffect());
		item.setCooldownCustomModelData(3);
		item.setMaxCooldown(150);
		item = new AbilityItem(weatherItem, getWeatherEffect());
		item.setCooldownCustomModelData(5);
		item.setMaxCooldown(200);
		item = new AbilityItem(harvestItem, getHarvestEffect());
		item.setCooldownCustomModelData(7);
		item.setMaxCooldown(100);
		item = new AbilityItem(cloakItem, getCloakEffect());
		item.setCooldownCustomModelData(9);
		item.setMaxCooldown(100);
	}
	
	public static ArrayList<ItemStack> getAbilityItems()
	{
		ArrayList<ItemStack> items = new ArrayList<>();
		items.add(warpItem);
		items.add(weatherItem);
		items.add(harvestItem);
		items.add(cloakItem);
		return items;
	}
	
	public static void createStoneItem()
	{
		CustomItem powerStone = new CustomItem(stoneItem, "reality");
		powerStone.setNumHotbars(1);
		powerStone.setAbilityItems(getAbilityItems());
	}
	
	private static AbilityEffect getWarpEffect()
	{
		return new AbilityEffect() 
		{
			@Override
			public boolean effect(Player player) {
				
				return Utils.targetLocationAttack(player, 30, getWarpPowerEffect());
			}
		};
	}
	
	private static PowerEffect getWarpPowerEffect()
	{
		return new PowerEffect()
		{
			@Override
			boolean effect(Player player, Location loc, LivingEntity target) {
				
				int duration = 80;
				int size = 6;
				Location loc1 = loc.clone();
				Location temp = loc.clone();
				Location loc2;
				DustOptions dust = new DustOptions(Color.RED, 1);
				
				if (player.getWorld().getName().equals("world") || player.getWorld().getName().equals("world_the_end"))
				{
					loc2 = Utils.toSafeLocation(Utils.toNetherLocation(temp));
					loc2.setWorld(Bukkit.getWorld("world_nether"));
				}
				else
				{
					loc2 = Utils.toSafeLocation(Utils.toOverworldLocation(temp));
					loc2.setWorld(Bukkit.getWorld("world"));
				}
				
				for (World world:Bukkit.getWorlds())
					player.sendMessage(world.getName());
				
				EventListener.protectLocation(loc1, size + 2, 220);
				EventListener.protectLocation(loc2, size + 2, 220);
				Utils.particleSwirl(player, Particle.REDSTONE, plugin, dust);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7F, 1.55F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.7F, 2F);
				loc1.getWorld().playSound(loc1, Sound.ENTITY_EVOKER_PREPARE_ATTACK, 1F, 0.1F);
				loc1.getWorld().playSound(loc2, Sound.ENTITY_EVOKER_PREPARE_ATTACK, 1F, 0.1F);
				Utils.swapLocations(loc1, loc2, size, false, plugin);
				
				new BukkitRunnable()
				{
					int timer = 0;
					@Override
					public void run()
					{
						Utils.particleSphere(Particle.REDSTONE, loc1, size, 50, dust);
						Utils.particleSphere(Particle.REDSTONE, loc2, size, 50, dust);
						timer++;
						if (timer > duration + 10)
							cancel();
					}
				}.runTaskTimer(plugin, 0, 1);
				
				new BukkitRunnable()
				{
					@Override
					public void run()
					{
						Utils.swapLocations(loc1, loc2, size, true, plugin);
						Utils.particleSwirl(player, Particle.REDSTONE, plugin, dust);
						loc1.getWorld().playSound(loc1, Sound.ENTITY_EVOKER_PREPARE_ATTACK, 0.5F, 2F);
						loc1.getWorld().playSound(loc2, Sound.ENTITY_EVOKER_PREPARE_ATTACK, 0.5F, 2F);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7F, 1.55F);
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.7F, 2F);
					}
				}.runTaskLater(plugin, duration);
				
				return true;
			}
		};
	}
	
	private static AbilityEffect getWeatherEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player)
			{
				Utils.particleSwirl(player, Particle.BLOCK_CRACK, plugin, Material.REDSTONE_BLOCK.createBlockData());
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7F, 1.55F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.7F, 2F);
				
				new BukkitRunnable()
				{
					@Override
					public void run()
					{
						Utils.particleSpiral(Particle.BLOCK_CRACK, player.getLocation().clone().add(new Vector(0, 2, 0)), new Vector(0, 1, 0.0001), 12, Material.REDSTONE_BLOCK.createBlockData());
						player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1F, 2F);
						if (player.getWorld().isClearWeather())
						{
							player.getWorld().setStorm(true);
							player.getWorld().setThundering(true);
						}
						else
						{
							player.getWorld().setThundering(false);
							player.getWorld().setStorm(false);
						}
					}
				}.runTaskLater(plugin, 10);
				
				return true;
			}
		};
	}
	
	private static AbilityEffect getHarvestEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player)
			{
				return Utils.targetLocationAttack(player, 20, getHarvestPowerEffect());
			}
		};
	}
	
	private static PowerEffect getHarvestPowerEffect()
	{
		return new PowerEffect()
		{
			@Override
			boolean effect(Player player, Location loc, LivingEntity target) 
			{
				Location blockloc = loc.clone().add(new Vector(0, -1, 0));
				if (!harvestable.containsKey(blockloc.getBlock().getType()))
				{
					player.sendMessage(blockloc.getBlock().getType().toString());
					return false;
				}

				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7F, 1.55F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.7F, 2F);
				
				new BukkitRunnable()
				{
					ArrayList<Location> locs = new ArrayList<>();
					ArrayList<Location> temp = new ArrayList<>();
					DustOptions dust = new DustOptions(Color.RED, 1F);
					int time = 0;
					int count = 0;
					
					@Override
					public void run()
					{
						if (time == 0)
						{
							locs.add(blockloc.clone());
							Utils.particleSwirl(player, Particle.REDSTONE, plugin, dust);
						}
						for (Location l:locs)
						{
							for (Location l2:harvestHelper(l))
								if (!temp.contains(l2))
									temp.add(l2);
						}
						locs.clear();
						count += temp.size();
						locs.addAll(temp);
						temp.clear();

						time++;
						if (time > 50 || count > 1500)
							cancel();
					}
				}.runTaskTimer(plugin, 0, 1);
				
				return true;
			}
		};
	}
	
	private static ArrayList<Location> harvestHelper(Location loc)
	{
		ArrayList<Location> neighbors = new ArrayList<>();
		Location temp;
		
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 4, 0.5, 0.5, 0.5, 0, new DustOptions(Color.RED, 1F), true);
		loc.getBlock().breakNaturally(false);
		loc.getWorld().playSound(loc, Sound.ENTITY_PARROT_FLY, 0.8F, 2F);
		loc.getWorld().playSound(loc, Sound.BLOCK_BAMBOO_BREAK, 0.15F, 2F);
		
		temp = loc.clone().add(new Vector(0, 1, 0));
		if (isHarvestable(temp))
			neighbors.add(temp.clone());
		temp = loc.clone().add(new Vector(0, -1, 0));
		if (isHarvestable(temp))
			neighbors.add(temp.clone());
		temp = loc.clone().add(new Vector(1, 0, 0));
		if (isHarvestable(temp))
			neighbors.add(temp.clone());
		temp = loc.clone().add(new Vector(-1, 0, 0));
		if (isHarvestable(temp))
			neighbors.add(temp.clone());
		temp = loc.clone().add(new Vector(0, 0, 1));
		if (isHarvestable(temp))
			neighbors.add(temp.clone());
		temp = loc.clone().add(new Vector(0, 0, -1));
		if (isHarvestable(temp))
			neighbors.add(temp.clone());
		
		return neighbors;
	}
	
	private static boolean isHarvestable(Location loc)
	{
		if (harvestable.containsKey(loc.getBlock().getType()))
			return true;
		return false;
	}
	
	private static HashMap<Material, Boolean> getHarvestableBlocks()
	{
		HashMap<Material, Boolean> blocks = new HashMap<>();
		
		blocks.put(Material.ACACIA_LOG, true);
		blocks.put(Material.BIRCH_LOG, true);
		blocks.put(Material.DARK_OAK_LOG, true);
		blocks.put(Material.JUNGLE_LOG, true);
		blocks.put(Material.OAK_LOG, true);
		blocks.put(Material.SPRUCE_LOG, true);
		blocks.put(Material.STRIPPED_ACACIA_LOG, true);
		blocks.put(Material.STRIPPED_BIRCH_LOG, true);
		blocks.put(Material.STRIPPED_DARK_OAK_LOG, true);
		blocks.put(Material.STRIPPED_JUNGLE_LOG, true);
		blocks.put(Material.STRIPPED_OAK_LOG, true);
		blocks.put(Material.STRIPPED_SPRUCE_LOG, true);
		
		blocks.put(Material.ACACIA_LEAVES, true);
		blocks.put(Material.AZALEA_LEAVES, true);
		blocks.put(Material.BIRCH_LEAVES, true);
		blocks.put(Material.DARK_OAK_LEAVES, true);
		blocks.put(Material.FLOWERING_AZALEA_LEAVES, true);
		blocks.put(Material.JUNGLE_LEAVES, true);
		blocks.put(Material.OAK_LEAVES, true);
		blocks.put(Material.SPRUCE_LEAVES, true);
		
		blocks.put(Material.CARROTS, true);
		blocks.put(Material.WHEAT, true);
		blocks.put(Material.BEETROOTS, true);
		blocks.put(Material.POTATOES, true);
		blocks.put(Material.PUMPKIN, true);
		blocks.put(Material.MELON, true);
		blocks.put(Material.SUGAR_CANE, true);
		
		blocks.put(Material.BROWN_MUSHROOM_BLOCK, true);
		blocks.put(Material.RED_MUSHROOM_BLOCK, true);
		blocks.put(Material.MUSHROOM_STEM, true);
		
		return blocks;
	}
	
	public static AbilityEffect getCloakEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				
				sendNoArmorPacket(player);
				
				return true;
			}
		};
	}
	
	public static void sendNoArmorPacket(Player player)
	{
		ProtocolManager manager = ProtocolLibrary.getProtocolManager();
		PacketContainer packet = manager.createPacket(PacketType.Play.Server.ENTITY_EQUIPMENT);
		player.sendMessage(PacketType.Play.Server.ENTITY_EQUIPMENT.getClass().toString());
		packet.getSlotStackPairLists();
		byte[] bytes = {0};
		for (int i = 0; i < 6; i++)
			packet.getByteArrays().write(i, bytes);
		
		for (Player p:player.getWorld().getPlayers())
		{
			try {
				manager.sendServerPacket(p, packet);
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		}
	}
}
