package me.August.InfinityStones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.WrappedWatchableObject;
import com.destroystokyo.paper.entity.villager.Reputation;
import com.destroystokyo.paper.entity.villager.ReputationType;

import me.August.CustomItems.AbilityEffect;
import me.August.CustomItems.AbilityItem;
import me.August.CustomItems.CustomItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class MindStone implements Utils {
	
	private static ItemStack stoneItem;
	private static ItemStack laserItem;
	private static ItemStack charmItem;
	private static ItemStack loveItem;
	private static ItemStack revealItem;
	private static ItemStack regenerateItem;
	private static Plugin plugin;
	private static HashMap<Player, Boolean> revealActive = new HashMap<>();
	
	public static void initMindStone(Plugin plugin)
	{
		MindStone.plugin = plugin;
		initPacketAdapter();
		initItems();
		createAbilities();
		createStoneItem();
	}
	
	private static void initItems()
	{
		ItemStack item;
		ItemMeta meta;
		List<Component> lore;
		TextComponent name;
		TextColor nameColor = TextColor.color(255, 200, 100);
		TextColor loreColor = TextColor.color(200, 150, 100);
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Mind Stone").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("A stone containing the").color(loreColor));
		lore.add(Component.text("essence of mind").color(loreColor));
		
		meta.setCustomModelData(6);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		stoneItem = item;
		
		item = new ItemStack(Material.GLOWSTONE_DUST);
		meta = item.getItemMeta();
		
		name = Component.text("Psionic Laser").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Project a powerful laser").color(loreColor));
		lore.add(Component.text("that damages and burns").color(loreColor));
		lore.add(Component.text("anything in its path").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		laserItem = item;
		
		item = new ItemStack(Material.GLOWSTONE_DUST);
		meta = item.getItemMeta();
		
		name = Component.text("Charm").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Compel a target villager").color(loreColor));
		lore.add(Component.text("to have a positive opinion").color(loreColor));
		lore.add(Component.text("of you").color(loreColor));
		
		meta.setCustomModelData(4);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		charmItem = item;
		
		item = new ItemStack(Material.GLOWSTONE_DUST);
		meta = item.getItemMeta();
		
		name = Component.text("Love").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Entice all animals in front").color(loreColor));
		lore.add(Component.text("of you to get sweaty").color(loreColor));
		
		meta.setCustomModelData(6);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		loveItem = item;
		
		item = new ItemStack(Material.GLOWSTONE_DUST);
		meta = item.getItemMeta();
		
		name = Component.text("Reveal").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Empower your mind to see").color(loreColor));
		lore.add(Component.text("everything, everywhere").color(loreColor));
		
		meta.setCustomModelData(8);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		revealItem = item;
		
		item = new ItemStack(Material.GLOWSTONE_DUST);
		meta = item.getItemMeta();
		
		name = Component.text("Regenerate").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Instantly regenerate some").color(loreColor));
		lore.add(Component.text("missing health").color(loreColor));
		
		meta.setCustomModelData(10);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		regenerateItem = item;
	}
	
	public static void createAbilities()
	{
		AbilityItem item;
		item = new AbilityItem(laserItem, getLaserEffect());
		item.setMaxCooldown(150);
		item.setCooldownCustomModelData(3);
		item = new AbilityItem(charmItem, getCharmEffect());
		item.setMaxCooldown(80);
		item.setCooldownCustomModelData(5);
		item = new AbilityItem(loveItem, getLoveEffect());
		item.setMaxCooldown(200);
		item.setCooldownCustomModelData(7);
		item = new AbilityItem(revealItem, getRevealEffect());
		item.setMaxCooldown(180);
		item.setCooldownCustomModelData(9);
		item = new AbilityItem(regenerateItem, getRegenerateEffect());
		item.setMaxCooldown(120);
		item.setCooldownCustomModelData(11);
	}
	
	public static ArrayList<ItemStack> getAbilityItems()
	{
		ArrayList<ItemStack> items = new ArrayList<>();
		items.add(laserItem);
		items.add(charmItem);
		items.add(loveItem);
		items.add(revealItem);
		items.add(regenerateItem);
		return items;
	}
	
	public static void createStoneItem()
	{
		CustomItem powerStone = new CustomItem(stoneItem, "mind");
		powerStone.setNumHotbars(1);
		powerStone.setAbilityItems(getAbilityItems());
	}
	
	// ------------- //
	// Laser Ability //
	// ------------- //
	
	private static AbilityEffect getLaserEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				
				new BukkitRunnable()
				{
					ArrayList<ArmorStand> armorStands = new ArrayList<>();
					int time = 0;
					int count = 20;
					BlockData crack = Material.YELLOW_WOOL.createBlockData();
					DustOptions dust = new DustOptions(Color.YELLOW, 1);
					int i;
					boolean display;
					Vector dir;
					Location loc;
					Location hitLoc;
					@Override
					public void run()
					{
						if (time == 0)
						{
							player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.6F, 2F);
							player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.6F, 2F);
							for (i = 0; i < count; i++)
							{
								armorStands.add(getLaserArmorStand(player));
							}
						}
						else
						{
							display = true;
							loc = player.getLocation().clone().add(new Vector(0, -0.45, 0));
							hitLoc = player.getLocation().clone().add(new Vector(0, 1.2, 0));
							dir = loc.getDirection().clone().multiply(0.12);
							loc.add(dir.clone().normalize().multiply(1.4));
							hitLoc.add(dir.clone().normalize().multiply(0.8));
							player.getWorld().spawnParticle(Particle.REDSTONE, hitLoc, 2, 0.2, 0.2, 0.2, 0, dust, true);
							hitLoc.add(dir.clone().normalize().multiply(0.4));
							
							player.getWorld().playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_FLUTE, 0.5F, 2F);
							
							for (i = 0; i < count; i++)
							{
								armorStands.get(i).getEquipment().setItem(EquipmentSlot.HEAD, display ? getLaserItem() : null);
								armorStands.get(i).teleport(loc);
								armorStands.get(i).setHeadPose(new EulerAngle(-Math.asin(player.getLocation().getDirection().getY()), 0, 0));
								if (Utils.damageArea(hitLoc, 0.8, 5, player).size() > 0)
									player.getWorld().spawnParticle(Particle.BLOCK_CRACK, hitLoc, 3, 0.2, 0.2, 0.2, 0.1, crack, true);
								for (int j = 0; j < 10; j++)
								{
									loc.add(dir);
									hitLoc.add(dir);
									if (display && !hitLoc.getBlock().isPassable())
									{
										player.getWorld().spawnParticle(Particle.BLOCK_CRACK, hitLoc, 6, 0.3, 0.3, 0.3, 0.1, hitLoc.getBlock().getBlockData(), true);
										display = false;
									}
								}
							}
						}
						time++;
						if (time > 30)
						{
							for (i = 0; i < count; i++)
							{
								armorStands.get(i).remove();
							}
							armorStands.clear();
							cancel();
							return;
						}
					}
				}.runTaskTimer(plugin, 0, 1);
				
				return true;
			}
		};
	}
	
	private static ItemStack getLaserItem()
	{
		ItemStack laserItem = new ItemStack(Material.CHORUS_FRUIT);
		ItemMeta meta = laserItem.getItemMeta();
		meta.setCustomModelData(2);
		laserItem.setItemMeta(meta);
		return laserItem;
	}
	
	private static ArmorStand getLaserArmorStand(Player player)
	{
		ArmorStand stand;
		ItemStack laserItem = getLaserItem();
		Location loc;
		loc = player.getLocation();
		stand = (ArmorStand) player.getWorld().spawnEntity(loc.clone().add(new Vector(0, -0.45, 0)), EntityType.ARMOR_STAND);
		stand.getEquipment().setHelmet(laserItem);
		stand.setInvisible(true);
		stand.setMarker(true);
		stand.setInvulnerable(true);
		stand.setGravity(false);
		stand.setSilent(true);
		stand.getScoreboardTags().add("display");
		
		return stand;
	}
	
	// ------------- //
	// Charm Ability //
	// ------------- //
	
	private static AbilityEffect getCharmEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				
				return Utils.targetEntityTypeFrontAttack(player, EntityType.VILLAGER, 12, getCharmPowerEffect());
			}
		};
	}
	
	private static PowerEffect getCharmPowerEffect()
	{
		return new PowerEffect()
		{
			@Override
			boolean effect(Player player, Location loc, LivingEntity target) {
				
				Reputation reputation;
				Location particleLoc;
				DustOptions dust;
				
				if (!(target instanceof Villager))
					return false;
				
				reputation = new Reputation();
				reputation.setReputation(ReputationType.MAJOR_NEGATIVE, -30);
				reputation.setReputation(ReputationType.MINOR_NEGATIVE, -30);
				reputation.setReputation(ReputationType.TRADING, 30);
				reputation.setReputation(ReputationType.MINOR_POSITIVE, 30);
				reputation.setReputation(ReputationType.MAJOR_POSITIVE, 30);
				
				((Villager) target).setReputation(player.getUniqueId(), reputation);
				
				particleLoc = target.getLocation().add(new Vector(0, 1, 0));
				dust = new DustOptions(Color.YELLOW, 1f);
				Utils.particleSphere(Particle.REDSTONE, particleLoc, 1.2, 100, dust);
				Utils.particleSwirl(target, Particle.VILLAGER_HAPPY, plugin);
				player.getWorld().playSound(player.getLocation(), Sound.ENTITY_VILLAGER_CELEBRATE, 0.8F, 1F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.5F, 1.7F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.5F, 1.7F);
				return true;
			}
		};
	}

	// ------------ //
	// Love Ability //
	// ------------ //
	
	private static AbilityEffect getLoveEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				
				Vector dir;
				Location loc;
				if (Utils.allEntityFrontAttack(player, 12, getLovePowerEffect()) == true)
				{
					loc = player.getLocation().clone().add(new Vector(0, 1, 0));
					dir = loc.getDirection().clone();
					Utils.particleSpiral(Particle.REDSTONE, loc, dir, 3, new DustOptions(Color.YELLOW, 1));
					player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WOLF_SHAKE, 0.6F, 2F);
					player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.5F, 2F);
					player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.5F, 2F);
					
					return true;
				}
				return false;
			}
		};
	}
	
	private static PowerEffect getLovePowerEffect()
	{
		return new PowerEffect()
		{
			@Override
			boolean effect(Player player, Location loc, LivingEntity target) {
				
				Location particleLoc;
				DustOptions dust;
				
				if (!(target instanceof Animals))
					return false;
				
				if (((Animals) target).isAdult())
				{
					((Animals) target).setBreed(true);
					((Animals) target).setLoveModeTicks(600);
				}
				
				particleLoc = target.getLocation().add(new Vector(0, 1, 0));
				dust = new DustOptions(Color.YELLOW, 1f);
				Utils.particleSphere(Particle.REDSTONE, particleLoc, 1.4, 100, dust);
				player.getWorld().spawnParticle(Particle.HEART, particleLoc, 5, 1, 1, 1, 0.1, null, true);
				return true;
			}
		};
	}
	
	// -------------- //
	// Reveal Ability //
	// -------------- //
	
	private static AbilityEffect getRevealEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				
				revealActive.put(player, true);
				updateDisplays(player);
				Utils.particleSphere(Particle.REDSTONE, player.getLocation().clone().add(new Vector(0, 1, 0)), 2.5, 200, new DustOptions(Color.YELLOW, 1));
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_END_PORTAL_FRAME_FILL, 0.5F, 0.5F);
				player.getWorld().playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.7F, 2F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.5F, 1.7F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.5F, 1.7F);
				new BukkitRunnable()
				{
					@Override
					public void run()
					{
						revealActive.put(player, false);
						updateDisplays(player);
						Utils.particleSwirl(player, Particle.REDSTONE, plugin, new DustOptions(Color.YELLOW, 1));
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_END_PORTAL_FRAME_FILL, 0.3F, 0.5F);
						player.getWorld().playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.4F, 2F);
					}
				}.runTaskLater(plugin, 100);
				
				return true;
			}
		};
	}
	
	private static AbilityEffect getRegenerateEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				
				DustOptions dust = new DustOptions(Color.YELLOW, 1);
				
				Utils.particleSwirl(player, Particle.REDSTONE, plugin, dust);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_GROWING_PLANT_CROP, 0.5F, 2F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_CHORUS_FLOWER_GROW, 0.5F, 2F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.5F, 1.7F);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.5F, 1.7F);
				
				new BukkitRunnable()
				{
					@Override
					public void run()
					{
						player.setHealth(player.getHealth() + 6 < 20 ? player.getHealth() + 6 : 20);
						player.getWorld().spawnParticle(Particle.HEART, player.getLocation().clone().add(new Vector(0, 1, 0)), 5, 0.3, 0.5, 0.3, 0, null, true);
					}
				}.runTaskLater(plugin, 10);
				
				return true;
			}
		};
	}
	
	private static void updateDisplays(Player player)
	{
		boolean glowing;
		for (Entity entity:player.getWorld().getEntities())
		{
			glowing = entity.isGlowing();
			entity.setGlowing(true);
			entity.setGlowing(false);
			entity.setGlowing(glowing);
		}
	}
	
	private static void initPacketAdapter()
	{
		ProtocolManager manager = ProtocolLibrary.getProtocolManager();
		manager.addPacketListener(new PacketAdapter(plugin, PacketType.Play.Server.ENTITY_METADATA) {

			@Override
			public void onPacketSending(PacketEvent event) {
				
				PacketContainer packet = event.getPacket();
				Player player = event.getPlayer();
				List<WrappedWatchableObject> contents;
				WrappedWatchableObject object;
				Entity entity;
				
				if (!revealActive.containsKey(player) || !revealActive.get(player))
					return;
				
				entity = entityFromID(packet.getIntegers().read(0), player.getWorld());
				
				if (entity != null && entity.getScoreboardTags().contains("display"))
					return;
					
				contents = packet.getWatchableCollectionModifier().read(0);
				object = contents.stream().filter(obj -> obj.getIndex() == 0).findFirst().orElse(null);
				if (object != null && object.getValue() instanceof Byte)
				{
					byte b = (Byte) object.getValue();
					b |= 0b01000000;
					object.setValue(b);
				}
				event.setPacket(packet);
			}
			
		});
	}
	
	private static Entity entityFromID(int ID, World world)
	{
		for (Entity entity:world.getEntities())
		{
			if (entity.getEntityId() == ID)
				return entity;
		}
		
		return null;
	}
}
