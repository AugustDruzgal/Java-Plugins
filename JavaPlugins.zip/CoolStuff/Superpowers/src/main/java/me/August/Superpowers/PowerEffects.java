package me.August.Superpowers;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.EntityEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

public class PowerEffects {
	
	private static Plugin plugin;
	private static HashMap<String, Integer> powermap;
	private static HashMap<Player, Integer> punchtime;
	private static HashMap<Player, Integer> flighttime;
	
	public static void init(Plugin p)
	{
		plugin = p;
		powermap = getPowerMap();
		punchtime = new HashMap<>();
		flighttime = new HashMap<>();
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				for(Player player:Bukkit.getOnlinePlayers())
				{
					if (punchtime.get(player) > 0)
					{
						punchtime.put(player, punchtime.get(player) - 1);
					}
					if (flighttime.get(player) > 0)
					{
						flighttime.put(player, flighttime.get(player) - 1);
						player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 1, 0, 0, 0, 0, null, true);
						player.setFallDistance(0);
						player.setGliding(true);
						if (flighttime.get(player) == 0 || isOnGround(player))
						{
							player.setGliding(false);
							flighttime.put(player, 0);
						}
					}
					if (player.isSneaking())
					{
						HotkeyManager.usePower(player, player.getInventory().getHeldItemSlot());
					}
					if (Main.getPlayerPower(player).getFlight())
					{
						player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 3, 0));
					}
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public static void initplayer(Player player)
	{
		punchtime.put(player, 0);
		flighttime.put(player, 0);
	}
	
	public static void activatePower(Player player, String power, int level)
	{
		if (!powermap.containsKey(power))
		{
			return;
		}
		switch (powermap.get(power))
		{
		case 0:
			laser(player);
			break;
		case 1:
			punch(player);
			break;
		case 2:
			fly(player);
			break;
		}
	}
	
	public static void doPunch(Player player, LivingEntity target)
	{
		double strength;
		if (punchtime.get(player) > 0)
		{
			player.getWorld().spawnParticle(Particle.BLOCK_CRACK, player.getLocation(), 35, 1, 1, 1, 1, Material.DIRT.createBlockData(), true);
			strength = Main.getPlayerPower(player).getPowerLevel("Punch");
			punchtime.put(player, 0);
			target.setVelocity(player.getLocation().getDirection().clone().setY(0).normalize().setY(0.25).normalize().multiply(2 + strength/2));
		}
	}
	
	private static HashMap<String, Integer> getPowerMap()
	{
		HashMap<String, Integer> pm = new HashMap<>();
		pm.put("Laser", 0);
		pm.put("Punch", 1);
		pm.put("Flight", 2);
		return pm;
	}
	
	private static void laser(Player player)
	{
		shootLaser(player, Main.getPlayerPower(player).getPowerLevel("Laser"));
	}
	
	private static void punch(Player player)
	{
		if (punchtime.get(player) == 0)
		{
			player.sendMessage(Component.text("Power punch prepared").color(TextColor.color(100, 200, 255)));
			player.getWorld().spawnParticle(Particle.BLOCK_CRACK, player.getLocation(), 35, 1, 1, 1, 1, Material.DIRT.createBlockData(), true);
		}
		punchtime.put(player, 40);
	}
	
	private static void fly(Player player)
	{
		int power = Main.getPlayerPower(player).getPowerLevel("Flight");
		if (flighttime.get(player) == 0)
		{
			player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 40, 0, 0, 0, 0.3, null, true);
		}
		player.setGliding(true);
		player.setVelocity(player.getLocation().getDirection().clone().normalize().multiply(1 + power * 0.1));
		flighttime.put(player, 5);
	}
	
	private static void shootLaser(Player player, int power)
	{
		DustOptions dust = new DustOptions(Color.RED, 0.4f);
		Location loc = player.getLocation().clone().add(new Vector(0, player.getEyeHeight(), 0));
		Vector dir = loc.getDirection().clone().normalize().multiply(0.1);
		Vector offset = dir.clone().setY(0).normalize().multiply(0.2).rotateAroundY(Math.PI/2);
		for (int i = 0; i < 500; i++)
		{
			loc.add(dir);
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0, dust, true);
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().subtract(offset), 1, 0, 0, 0, 0, dust, true);
			if (i%5 == 0)
			{
				if (!loc.getBlock().isPassable() || laserHit(loc, player, power))
				{
					i = 100000;
				}
			}
		}
	}
	
	private static boolean laserHit(Location loc, Player player, double power)
	{
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getBoundingBox().clone().expand(0.4).contains(loc.toVector()))
			{
				damage(entity, 3 * Math.pow(1.1, power), player);
				if (entity instanceof EnderDragon && entity.getNoDamageTicks() == 0)
				{
					if (entity.getHealth() < 3 * Math.pow(1.1, power))
						((EnderDragon) entity).
					entity.setHealth(entity.getHealth() - 3 * Math.pow(1.1, power));
					entity.playEffect(EntityEffect.HURT);
					entity.setNoDamageTicks(10);
					entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_ENDER_DRAGON_HURT, 100, 1);
				}
				entity.setVelocity(player.getLocation().getDirection().clone().setY(0).normalize().setY(0.02).normalize().multiply(0.3 + power * 0.05));
				entity.setFireTicks(10);
				return true;
			}
		}
		return false;
	}
	
	private static void damage(LivingEntity target, double amount, LivingEntity source)
	{
		double damage = amount;
		int power;
		if (target instanceof Player)
		{
			power = Main.getPlayerPower((Player) target).getPowerLevel("Durability");
			if (power > 0)
			{
				damage = damage * Math.pow(1/1.1, power);
			}
		}
		
		target.damage(damage);
	}
	
	private static boolean isOnGround(LivingEntity entity)
	{
		if (!entity.getLocation().clone().add(new Vector(0, -0.01, 0)).getBlock().isPassable())
			return true;
		return false;
	}
}
