package me.August.Wands;

import java.util.ArrayList;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class FiendFirePiece {
	
	Plugin plugin;
	Player player;
	Location loc;
	Vector vel;
	
	FiendFirePiece(Player p, Plugin pl, Location l) {
		
		player = p;
		plugin = pl;
		loc = l;
		vel = loc.clone().getDirection().multiply(0.3);
		
	}
	
	public boolean move() {
		
		loc.add(vel);
		loc.getWorld().spawnParticle(Particle.FLAME, loc, 2, 0.1, 0.1, 0.1, 0.012, null, true);
		
		if (!loc.getBlock().isPassable()) {
			
			return false;
			
		}
		
		return true;
	}
	
	public ArrayList<LivingEntity> hit() {
		
		ArrayList<LivingEntity> hitentities = new ArrayList<LivingEntity>();
		
		for (LivingEntity entity:player.getWorld().getLivingEntities()) {
			
			if (entity.getBoundingBox().clone().expand(0.4).contains(loc.clone().toVector())) {
				
				hitentities.add(entity);
				
			}
			
		}
		
		return hitentities;
		
	}

}
