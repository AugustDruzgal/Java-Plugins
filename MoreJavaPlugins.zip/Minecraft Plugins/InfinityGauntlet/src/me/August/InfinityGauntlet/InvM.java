package me.August.InfinityGauntlet;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class InvM {
	
	Player player;
	boolean active = false;
	int stone = 0;
	int lastslot;
	Inventory inv;
	Inventory power;
	Inventory time;
	Inventory space;
	
	InvM(Player p) {
		
		player = p;
		inv = Bukkit.createInventory(player, InventoryType.PLAYER);
		power = Bukkit.createInventory(player, InventoryType.PLAYER);
		time = Bukkit.createInventory(player, InventoryType.PLAYER);
		space = Bukkit.createInventory(player, InventoryType.PLAYER);
		power.addItem(Abilities.powerblast());
		power.addItem(Abilities.powerwave());
		power.setItem(8, Main.gauntlet());
		time.addItem(Abilities.timeblast());
		time.addItem(Abilities.timewarp());
		time.setItem(8, Main.gauntlet());
		space.addItem(Abilities.spacestrike());
		space.addItem(Abilities.spacewarp());
		space.setItem(8, Main.gauntlet());
		stone = 0;
	}
	
	public void next() {
		
		stone = (stone+1)%3;
		
		switch (stone) {
		case 0:
			player.getInventory().setContents(power.getContents());
			break;
		case 1:
			player.getInventory().setContents(time.getContents());
			break;
		case 2:
			player.getInventory().setContents(space.getContents());
			break;
		default:
			stone = 0;
			player.getInventory().setContents(power.getContents());
		}
		
	}
	
	public void activate() {
		
		active = true;
		inv.setContents(player.getInventory().getContents());
		
		switch (stone) {
		case 0:
			player.getInventory().setContents(power.getContents());
			lastslot = player.getInventory().getHeldItemSlot();
			player.getInventory().setHeldItemSlot(8);
			break;
		case 1:
			player.getInventory().setContents(time.getContents());
			lastslot = player.getInventory().getHeldItemSlot();
			player.getInventory().setHeldItemSlot(8);
			break;
		case 2:
			player.getInventory().setContents(space.getContents());
			lastslot = player.getInventory().getHeldItemSlot();
			player.getInventory().setHeldItemSlot(8);
			break;
		}
		
	}
	
	public void deactivate() {
		
		active = false;
		player.getInventory().setContents(inv.getContents());
		player.getInventory().setHeldItemSlot(lastslot);
		
	}
	
	public boolean isActive() {
		
		return active;
		
	}

}
