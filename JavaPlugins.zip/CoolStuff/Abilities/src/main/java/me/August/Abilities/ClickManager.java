package me.August.Abilities;

import java.util.HashMap;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import me.August.Abilities.Earth.AxeEarth;
import me.August.Abilities.Fire.FireBall;
import me.August.Abilities.Fire.Flamethrower;
import me.August.Abilities.Fire.Pulse;
import me.August.Abilities.Fire.Thrust;
import me.August.Abilities.Ice.IcePrison;
import me.August.Abilities.Ice.SwordSnow;
import me.August.Abilities.Storm.LightningBolt;
import me.August.Abilities.Storm.LightningOrb;
import me.August.Abilities.Storm.StaticLaser;
import me.August.Abilities.Storm.Strike;
import me.August.Abilities.Storm.ThunderWarp;
import me.August.Abilities.Wind.SwordThrow;
import me.August.Abilities.Wind.Tornado;
import me.August.Abilities.Wind.WindSlam;
import me.August.Abilities.Wind.WindSlash;

public class ClickManager {
	
	static HashMap<String, ClickAction[]> actions;
	
	public static void initActions()
	{
		actions = new HashMap<String, ClickAction[]>();
		actions.put("main", mainActions());
		actions.put("air", airActions());
		actions.put("storm", stormActions());
		actions.put("fire", fireActions());
		actions.put("earth", earthActions());
		actions.put("ice", iceActions());
	}
	
	public static void doClick(Player player, int slot, Plugin plugin)
	{
		String current = Main.getManager(player).getInventoryManager().getCurrent();
		if (current != "none")
		{
			actions.get(current)[slot].action(player, plugin);
			player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.7F, 1F);
		}
	}
	
	private static ClickAction[] mainActions()
	{
		ClickAction[] actions = new ClickAction[36];
		actions[10] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("air");
				Main.getManager(player).getSkillManager().setClass("air");
			}
		};
		actions[11] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("storm");
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[12] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("fire");
				Main.getManager(player).getSkillManager().setClass("fire");
			}
		};
		actions[14] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("earth");
				Main.getManager(player).getSkillManager().setClass("earth");
			}
		};
		actions[15] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("ice");
				Main.getManager(player).getSkillManager().setClass("ice");
			}
		};
		actions[19] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().setClass("air");
			}
		};
		actions[20] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[21] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().setClass("fire");
			}
		};
		actions[23] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().setClass("earth");
			}
		};
		actions[24] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().setClass("ice");
			}
		};
		return actions;
	}
	
	private static ClickAction[] airActions()
	{
		ClickAction[] actions = new ClickAction[54];
		
		actions[12] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("air").setSword(new SwordThrow(player, plugin));
				Main.getManager(player).getSkillManager().setClass("air");
			}
		};
		actions[13] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("air").setSword(new WindSlam(player, plugin));
				Main.getManager(player).getSkillManager().setClass("air");
			}
		};
		actions[21] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("air").setAxe(new WindSlash(player, plugin));
				Main.getManager(player).getSkillManager().setClass("air");
			}
		};
		actions[22] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("air").setAxe(new Tornado(player, plugin));
				Main.getManager(player).getSkillManager().setClass("air");
			}
		};
		actions[45] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("main");
			}
		};
		
		return actions;
	}
	
	private static ClickAction[] stormActions()
	{
		ClickAction[] actions = new ClickAction[54];

		actions[12] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("storm").setSword(new StaticLaser(player, plugin));
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[13] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("storm").setSword(new LightningBolt(player, plugin));
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[14] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("storm").setSword(new ThunderWarp(player, plugin));
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[15] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("storm").setSword(new StaticLaser(player, plugin));
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[21] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("storm").setAxe(new LightningOrb(player, plugin));
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[22] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("storm").setAxe(new Strike(player, plugin));
				Main.getManager(player).getSkillManager().setClass("storm");
			}
		};
		actions[45] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("main");
			}
		};
		
		return actions;
	}
	
	private static ClickAction[] fireActions()
	{
		ClickAction[] actions = new ClickAction[54];

		actions[12] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("fire").setSword(new Flamethrower(player, plugin));
				Main.getManager(player).getSkillManager().setClass("fire");
			}
		};
		actions[13] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("fire").setSword(new Thrust(player, plugin));
				Main.getManager(player).getSkillManager().setClass("fire");
			}
		};
		actions[21] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("fire").setAxe(new FireBall(player, plugin));
				Main.getManager(player).getSkillManager().setClass("fire");
			}
		};
		actions[22] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("fire").setAxe(new Pulse(player, plugin));
				Main.getManager(player).getSkillManager().setClass("fire");
			}
		};
		actions[45] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("main");
			}
		};
		
		return actions;
	}
	
	private static ClickAction[] earthActions()
	{
		ClickAction[] actions = new ClickAction[54];

		actions[21] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("earth").setAxe(new AxeEarth(player, plugin));
				Main.getManager(player).getSkillManager().setClass("earth");
			}
		};
		actions[45] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("main");
			}
		};
		
		return actions;
	}
	
	private static ClickAction[] iceActions()
	{
		ClickAction[] actions = new ClickAction[54];
		actions[12] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("ice").setSword(new SwordSnow(player, plugin));
				Main.getManager(player).getSkillManager().setClass("ice");
			}
		};
		actions[21] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getSkillManager().getSet("ice").setSword(new IcePrison(player, plugin));
				Main.getManager(player).getSkillManager().setClass("ice");
			}
		};
		actions[45] = new ClickAction() {
			public void action(Player player, Plugin plugin)
			{
				Main.getManager(player).getInventoryManager().openInventory("main");
			}
		};
		
		return actions;
	}
}