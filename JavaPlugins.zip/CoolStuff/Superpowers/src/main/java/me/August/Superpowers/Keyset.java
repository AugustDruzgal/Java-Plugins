package me.August.Superpowers;

import org.bukkit.entity.Player;

public class Keyset {
	
	private String[] binds;
	
	public Keyset(Player player)
	{
		binds = new String[9];
		for (int i = 0; i < 9; i++)
		{
			binds[i] = "none";
		}
	}
	
	public String getBind(int slot)
	{
		return binds[slot];
	}
	
	public void setBind(int slot, String power)
	{
		binds[slot] = power;
	}
}
