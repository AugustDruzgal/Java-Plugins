package me.August.InfinityStones;

import java.lang.reflect.InvocationTargetException;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class RealityStone extends Stone {

	ProtocolManager protocolManager;
	
	RealityStone(Plugin pl) {
		super(pl);
		name = "Reality Stone";
		color = Color.fromRGB(255, 20, 10);
		time = 80;
		protocolManager = ProtocolLibrary.getProtocolManager();
	}
	
	@Override
	public void p()
	{
		
	}
	
	@Override
	public void a()
	{
		new BukkitRunnable()
		{
			int time = 0;
			@Override
			public void run()
			{
				time++;
				sendAnimationPacket(player, 2);
				sendAnimationPacket(player, 1);
				sendTimePacket(player, 18000);
				if (time > 20)
				{
					cancel();
					sendTimePacket(player, player.getWorld().getTime());
				}
			}
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	@Override
	public ItemStack createItem()
	{
		ItemStack new_item = new ItemStack(Material.AMETHYST_SHARD);
		
		ItemMeta meta = new_item.getItemMeta();
		TextComponent name = Component.text("reality stone").color(TextColor.color(255, 20, 10));
		meta.displayName(name);
		meta.setCustomModelData(4);
		new_item.setItemMeta(meta);
		
		return new_item;
	}
	
	private void sendAnimationPacket(Player p, int animation)
	{
		PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.ANIMATION);
		packet.getIntegers().write(0, p.getEntityId());
		packet.getIntegers().write(1, animation);
		try {
			protocolManager.sendServerPacket(p, packet);
		} catch (InvocationTargetException e1) {
			Bukkit.getLogger().info("oopsie doopsie!");
		}
	}
	
	private void sendTimePacket(Player p, long time)
	{
		PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.UPDATE_TIME);
		packet.getLongs().write(1, time);
		try {
			protocolManager.sendServerPacket(p, packet);
		} catch (InvocationTargetException e1) {
			Bukkit.getLogger().info("oopsie doopsie!");
		}
	}

}
