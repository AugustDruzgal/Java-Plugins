package me.August.Gauntlet;

import org.bukkit.entity.Player;

public abstract class GuiAction {
	
	abstract void action(Player player);
	
	public GuiAction clone()
	{
		return this;
	}

}
