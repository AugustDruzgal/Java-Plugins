package me.August.Abilities.Fire;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;

public class FireBall extends Skill {

	public FireBall(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		Location loc = player.getLocation().
				clone().
				add(new Vector(0, 1, 0));
		spawnFireball(loc);
		startCooldown(140, true);
	}
	
	private void spawnFireball(Location loc)
	{
		Fireball fireball = (Fireball) player.getWorld().spawnEntity(loc, EntityType.FIREBALL);
		fireball.addScoreboardTag("spellfireball");
		fireball.setDirection(loc.getDirection().clone().multiply(1.35));
		fireball.setVelocity(loc.getDirection().clone().multiply(1.35));
		fireball.setShooter(player);
		fireball.setIsIncendiary(false);
		fireball.setYield(0);
		loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(loc.getDirection()), 25, 0, 0, 0, 0.35, null, true);
		new BukkitRunnable()
		{
			int time = 0;
			@Override
			public void run()
			{
				time++;
				if (time > 70)
				{
					cancel();
					if (!fireball.isDead())
						fireball.remove();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}

}
