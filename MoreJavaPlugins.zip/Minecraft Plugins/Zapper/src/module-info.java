module Zapper {
	requires spigot;
}