package me.August.CustomItems;

import org.bukkit.entity.Player;

public abstract class AbilityEffect {
	
	public abstract boolean effect(Player player);

}
