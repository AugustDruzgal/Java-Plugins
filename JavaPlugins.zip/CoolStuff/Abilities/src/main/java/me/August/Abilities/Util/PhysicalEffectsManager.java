package me.August.Abilities.Util;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import me.August.Abilities.Main;

public class PhysicalEffectsManager {
	
	private HashMap<String, Effect> takeDamageEffects = getTakeDamageEffects();
	private HashMap<String, Effect> dealDamageEffects = getDealDamageEffects();
	private HashMap<Player, Integer> counters = getCounters();
	private HashMap<Player, String> current = getCurrentSkills();
	private static int time = 0;
	
	public void ActivateDealDamageEffects(Player source, LivingEntity target, int level)
	{
		Effect effect = takeDamageEffects.get(current.get(target));
	}
	
	public static void updateTime()
	{
		time = (time++)%1000;
		for (Player player:Bukkit.getOnlinePlayers())
		{
			
		}
	}
	
	private static HashMap<String, Effect> getTakeDamageEffects()
	{
		HashMap<String, Effect> e = new HashMap<>();
		e.put("ShockingStrikes", new Effect() {
			public void run(Player source, LivingEntity target, int level)
			{
				Utils.shock(target, 20 * level);
			}
		});
		return e;
	}
	
	private static HashMap<String, Effect> getDealDamageEffects()
	{
		HashMap<String, Effect> e = new HashMap<>();
		e.put("ShockingStrikes", new Effect() {
			public void run(Player source, LivingEntity target, int level)
			{
				Utils.shock(target, 20 * level);
			}
		});
		e.put("FreezingBlade", null);
		return e;
	}
	
	private static String getPlayerPassiveSkill(Player player)
	{
		return Main.getManager(player).getSkillManager().getStatusSkill();
	}
	
	private static HashMap<Player, Integer> getCounters()
	{
		HashMap<Player, Integer> c = new HashMap<>();
		for (Player player:Bukkit.getOnlinePlayers())
		{
			c.put(player, 0);
		}
		return c;
	}
	
	private static HashMap<Player, String> getCurrentSkills()
	{
		HashMap<Player, String> c = new HashMap<>();
		for (Player player:Bukkit.getOnlinePlayers())
		{
			c.put(player, getPlayerPassiveSkill(player));
		}
		return c;
	}

}

abstract class Effect
{
	abstract void run(Player source, LivingEntity target, int level);
}
