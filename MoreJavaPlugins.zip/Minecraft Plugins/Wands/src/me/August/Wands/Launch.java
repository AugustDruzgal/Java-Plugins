package me.August.Wands;

public class Launch {
	
	

}
