package me.August.InfinityStones;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import me.August.CustomItems.CustomItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class Gauntlet {
	
	private static ItemStack gauntletItem;
	
	public static void initGauntlet()
	{
		initItem();
		createGauntletItem();
	}
	
	public static void createGauntletItem()
	{
		CustomItem powerStone = new CustomItem(gauntletItem, "gauntlet");
		ArrayList<ItemStack> abilityItems = new ArrayList<>();
		// abilityItems.addAll(PowerStone.getAbilityItems());
		abilityItems.addAll(TimeStone.getAbilityItems());
		abilityItems.addAll(RealityStone.getAbilityItems());
		abilityItems.addAll(MindStone.getAbilityItems());
		powerStone.setNumHotbars(2);
		powerStone.setAbilityItems(abilityItems);
	}
	
	public static void initItem()
	{
		ItemStack item;
		ItemMeta meta;
		List<Component> lore;
		TextComponent name;
		TextColor nameColor = TextColor.color(255, 200, 100);
		TextColor loreColor = TextColor.color(100, 200, 255);
		
		item = new ItemStack(Material.GOLD_INGOT);
		meta = item.getItemMeta();
		
		name = Component.text("Infinity Gauntlet").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("This gauntlet is built to control").color(loreColor));
		lore.add(Component.text("the powers of multiple infinity").color(loreColor));
		lore.add(Component.text("stones at once, provided that the").color(loreColor));
		lore.add(Component.text("user has the strength of will to").color(loreColor));
		lore.add(Component.text("obtain them.").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		gauntletItem = item;
	}

}
