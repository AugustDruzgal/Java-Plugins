package me.August.Abilities.Util;

import java.util.ArrayList;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;

public interface Utils {
	
	public static ArrayList<Block> getNearbyBlocks(Location loc, float radius)
	{
		ArrayList<Block> blocks = new ArrayList<>();
		Location temp;
		int num = Math.round(radius) + 1;
		for (int x = -num; x <= num; x++)
		{
			for (int y = -num; y <= num; y++)
			{
				for (int z = -num; z <= num; z++)
				{
					temp = loc.clone().add(new Vector(x, y, z));
					if (loc.distance(temp) <= radius)
					{
						blocks.add(temp.getBlock());
					}
				}
			}
		}
		return blocks;
	}
	
	public static ArrayList<Block> getNearbySurfaceBlocks(Location loc, double d)
	{
		ArrayList<Block> blocks = new ArrayList<>();
		Location temp;
		Block block;
		int num = (int) (Math.round(d) + 1);
		for (int x = -num; x <= num; x++)
		{
			for (int z = -num; z <= num; z++)
			{
				temp = loc.clone().add(new Vector(x, 0, z));
				block = getBlockOnSurface(temp);
				if (block.getLocation().distance(loc) <= d)
					blocks.add(block);
			}
		}
		return blocks;
	}
	
	public static Block getBlockOnSurface(Location location)
	{
		Block block = location.getBlock();
		Location loc = location.clone();
		int i = 0;
		
		if (block.isPassable())
		{
			while (block.isPassable())
			{
				if (++i > 310)
					return null;
				loc = loc.add(new Vector(0, -1, 0));
				block = loc.getBlock();
			}
		}
		else
		{
			while (!block.isPassable())
			{
				if (++i > 310)
					return null;
				loc = loc.add(new Vector(0, 1, 0));
				block = loc.getBlock();
			}
			loc = loc.subtract(new Vector(0, 1, 0));
			block = loc.getBlock();
		}
		
		return block;
	}

	public static void arcBetween(Location loc, Location loc2, Color color) {
		
		DustOptions dust = new DustOptions(color, 1F);
		Vector direction = loc.clone().subtract(loc2).toVector().multiply(-1);
		Location location = loc.clone();
		double amount = Math.ceil(direction.length() / 4);
		double distance = (direction.length() / amount) / 24;
		direction = direction.normalize().multiply(distance);
		
		for (int i = 0; i < amount; i++)
		{
			location = arcBetweenHelper(location, direction, distance, color);
		}
		
		loc.getWorld().spawnParticle(Particle.REDSTONE, location, 1, 0, 0, 0, 0, dust, true);
	}
	
	private static Location arcBetweenHelper(Location loc, Vector dir, double distance, Color color)
	{
		DustOptions dust = new DustOptions(color, 1F);
		Location location = loc.clone();
		Location temp;
		Vector offset = new Vector(0, distance/1.3, 0).rotateAroundAxis(dir, Math.random() * Math.PI * 2);
		int multiplier;
		for (int i = 0; i < 24; i++)
		{
			if (i > 18)
				multiplier = i - 24;
			else if (i > 6)
				multiplier = 12 - i;
			else
				multiplier = i;
			temp = location.clone().add(offset.clone().multiply(multiplier));
			loc.getWorld().spawnParticle(Particle.REDSTONE, temp, 1, 0, 0, 0, 0, dust, true);
			location.add(dir);
		}
		return location;
	}
	
	public static void damage(LivingEntity entity, double amount, LivingEntity source)
	{
		int ticks = entity.getNoDamageTicks();
		entity.setNoDamageTicks(0);
		entity.damage(amount, source);
		entity.setNoDamageTicks(ticks);
	}
	
	public static void damage(LivingEntity entity, double amount)
	{
		int ticks = entity.getNoDamageTicks();
		entity.setNoDamageTicks(0);
		entity.damage(amount);
		entity.setNoDamageTicks(ticks);
	}
	
	public static void shock(LivingEntity entity, int ticks)
	{
		new BukkitRunnable()
		{
			int nodamageticks;
			int timer = 1;
			@Override
			public void run()
			{
				nodamageticks = entity.getNoDamageTicks();
				entity.setNoDamageTicks(0);
				entity.damage(0.000001);
				entity.setNoDamageTicks(nodamageticks);
				if (++timer>ticks)
					cancel();
			}
		}.runTaskTimer(Main.getPlugin(), 0, 1);
	}
}
