module MechArmor {
	requires spigot;
}