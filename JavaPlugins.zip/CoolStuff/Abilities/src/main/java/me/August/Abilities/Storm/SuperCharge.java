package me.August.Abilities.Storm;

import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.Util.PassiveSkill;

public class SuperCharge extends PassiveSkill {
	
	int duration = 0;
	BukkitTask reduce;

	public SuperCharge(Player p, Plugin pl) {
		super(p, pl);
	}
	
	@Override
	public void effect(int level)
	{
		duration = 2;
		Main.getManager(player).getManaManager().setPause(2);
		player.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, player.getLocation().clone().add(new Vector(0, 0.5, 0)), 1, 0.5, 0, 0.5, 0.03, null, true);
		if (reduce == null)
		{
			Main.getManager(player).getSkillManager().setBonusLevel(level);
			reduce = new BukkitRunnable()
			{
				@Override
				public void run()
				{
					duration--;
					if (duration == 0)
					{
						Main.getManager(player).getSkillManager().setBonusLevel(0);
						cancel();
						reduce = null;
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
	}

}
