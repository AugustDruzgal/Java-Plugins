package me.August.Wands;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class TemporaryBlock {
	
	Plugin plugin;
	Location loc;
	Material original;
	BlockData originaldata;
	BukkitTask task;
	
	TemporaryBlock(Plugin plugin, Location l, Material type, double duration) {
		
		loc = l.getBlock().getLocation();
		original = loc.getBlock().getType();
		originaldata = loc.getBlock().getBlockData();
		
		loc.getBlock().setType(type);
		
		task = new BukkitRunnable() {
			
			@Override
			public void run() {
				
				loc.getBlock().setType(original);
				loc.getBlock().setBlockData(originaldata);
				
				TemporaryBlockManager.tempBlocks.remove(loc);
				
				cancel();
				
			}
			
		}.runTaskLater(plugin, (long) duration);
		
	}
	
	TemporaryBlock(Plugin plugin, Location l, Material type, double duration, Material o, BlockData odata) {
		
		loc = l.getBlock().getLocation();
		original = o;
		originaldata = odata;
		
		loc.getBlock().setType(type);
		
		task = new BukkitRunnable() {
			
			@Override
			public void run() {
				
				loc.getBlock().setType(original);
				loc.getBlock().setBlockData(originaldata);
				
				TemporaryBlockManager.tempBlocks.remove(loc);
				
				cancel();
				
			}
			
		}.runTaskLater(plugin, (long) duration);
		
	}
	
	public void setCancelled() {
		
		task.cancel();
		
	}

}
