package me.August.Abilities.Fire;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.PassiveSkill;

public class Immolate extends PassiveSkill {

	public Immolate(Player p, Plugin pl) {
		super(p, pl);
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() <= 2)
		{
			toggle();
			return;
		}
		manager.removeMana((long) 0.5);
		manager.setPause(1);
		dropFire();
		player.getWorld().spawnParticle(Particle.FLAME, player.getLocation(), 2, 0.7, 0, 0.7, 0.05, null, true);
		player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 2, 0));
		player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 2, 0));
	}
	
	private boolean igniteNearby(Location loc)
	{
		boolean hit = false;
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector()))
			{
				entity.setFireTicks((entity.getFireTicks() > 50)?60:entity.getFireTicks()+10);
				hit = true;
				entity.getWorld().playSound(entity.getLocation(), Sound.BLOCK_CAMPFIRE_CRACKLE, 0.5F, 1.5F);
			}
		}
		
		return hit;
	}
	
	private void dropFire()
	{
		Item fire;
		fire = player.getWorld().dropItem(player.getLocation(), new ItemStack(Material.BLAZE_POWDER));
		fire.setCanPlayerPickup(false);
		fire.setCanMobPickup(false);
		fire.setVelocity(fire.getVelocity().clone().normalize().setY(0).multiply(0.7).setY(0.15));
		fire.getWorld().playSound(player.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.5F, 1.5F);
		new BukkitRunnable()
		{
			int timer = 0;
			@Override
			public void run()
			{
				if (igniteNearby(fire.getLocation()))
					timer = 50;
				timer++;
				if (timer > 40)
				{
					cancel();
					fire.remove();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}

}
