package me.August.Gauntlet;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

public class GuiItem {
	
	Material itemType = Material.GRAY_DYE;
	String itemName = "GUI item";
	TextColor itemNameColor = TextColor.color(100, 200, 255);
	int customModelData = 0;
	GuiSet[] guiSets = {};
	
	// Creates an ItemStack representation of this item
	public ItemStack getAsItemStack()
	{
		ItemStack itemStack = new ItemStack(this.itemType, 1);
		ItemMeta itemStackMeta = itemStack.getItemMeta();
		itemStackMeta.setCustomModelData(this.customModelData);
		itemStackMeta.displayName(Component.text(this.itemName).color(itemNameColor));
		itemStack.setItemMeta(itemStackMeta);
		return itemStack;
	}
	
	public void setCustomModelData(int customModelData)
	{
		this.customModelData = customModelData;
	}
	
	public int getCustomModelData()
	{
		return this.customModelData;
	}
	
	public void setItemType(Material itemType)
	{
		this.itemType = itemType;
	}
	
	public Material getItemType()
	{
		return this.itemType;
	}
	
	public void setItemName(String itemName)
	{
		this.itemName = itemName;
	}
	
	public String getItemName()
	{
		return this.itemName;
	}
	
	public void setItemNameColor(TextColor itemNameColor)
	{
		this.itemNameColor = itemNameColor;
	}
	
	public void setItemNameColor(int r, int g, int b)
	{
		this.itemNameColor = TextColor.color(r, g, b);
	}
	
	public TextColor getItemNameColor()
	{
		return this.itemNameColor;
	}
	
	public void setGuiSets(GuiSet[] guiSets)
	{
		this.guiSets = guiSets;
	}
	
	public GuiSet[] getGuiSets()
	{
		return this.guiSets;
	}
	
	public GuiSet getGuiSet(int n)
	{
		return this.guiSets[n];
	}
	
	public int getGuiSetAmount()
	{
		return this.guiSets.length;
	}
	
	public void updateCooldowns()
	{
		for (GuiSet set:guiSets)
		{
			set.updateCooldown();
		}
	}
	
	public GuiItem clone()
	{
		GuiItem copy = new GuiItem();
		GuiSet[] copysets = new GuiSet[this.guiSets.length];
		for (int i = 0; i < guiSets.length; i++)
		{
			copysets[i] = guiSets[i].clone();
		}
		copy.setItemType(this.itemType);
		copy.setCustomModelData(this.customModelData);
		copy.setItemName(this.itemName);
		copy.setItemNameColor(this.itemNameColor);
		copy.setGuiSets(copysets);
		return copy;
	}

}
