package me.August.Abilities.Storm;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.ParticleProjectile;
import me.August.Abilities.Util.Skill;
import me.August.Abilities.Util.Utils;

public class LightningBolt extends Skill implements Utils {

	public LightningBolt(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() < 75 - 3 * level)
		{
			return;
		}
		manager.removeMana(75 - 3 * level);
		startCooldown(80 - 5 * level, true);
		Location location = player.getLocation().clone();
		location = location.add(new Vector(0, 1, 0));
		location = location.add(location.getDirection().clone().multiply(0.75));
		
		new ParticleProjectile(location, location.getDirection(), player, plugin) {
			
			@Override
			public void moveParticle(Location loc, int time) {
				if (time == this.getMovesPerTick() - 1)
				{
					loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 2, 0, 0, 0, 0.25, null, true);
					Utils.arcBetween(loc, getLastLocation(), Color.YELLOW);
				}
			}
			
			@Override
			public void impactParticle(Location loc) {
				loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 20, 0, 0, 0, 0.3, null, true);
			}
			
			@Override
			public void hitEffect(LivingEntity entity) {
				Utils.damage(entity, 3 + 0.5 * level, player);
				Utils.shock(entity, 10 + 2 * level);
				entity.setVelocity(this.getDirection().setY(0.3).multiply(0.6));
			}
			
			@Override
			public void castParticle(Location loc) {
				
			}
		}.setCurve(true, 0.05 + 0.005 * level, 50).setSpeed(2).setLifetime(20).setMovesPerTick(50).start();
	}
}
