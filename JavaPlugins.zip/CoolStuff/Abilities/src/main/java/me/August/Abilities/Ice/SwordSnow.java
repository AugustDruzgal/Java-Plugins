package me.August.Abilities.Ice;

import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.Skill;

public class SwordSnow extends Skill {

	public SwordSnow(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		Snowball snowball;
		if (manager.getMana() >= 10)
		{
			startCooldown(3, false);
			player.getWorld().playSound(player.getLocation(), Sound.BLOCK_POWDER_SNOW_STEP, 0.5F, 1F);
			manager.removeMana((long) 2.5);
			manager.setPause(1);
			for (int i = 0; i < 7; i++)
			{
				snowball = (Snowball) player.getWorld().spawnEntity(player.getLocation().clone().add(
						new Vector(0, 1, 0)), EntityType.SNOWBALL);
				snowball.setShooter(player);
				snowball.setVelocity(player.getLocation().getDirection().clone().add(
						new Vector(Math.random() - 0.5, Math.random() - 0.35, Math.random() - 0.5).multiply(0.3)).multiply(2));
			}
		}
	}
}
