package me.August.Wands;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Lightningbolt extends Spell {

	Lightningbolt(Player p, Plugin pl) {
		super(p, pl);
		setIcons(Material.GLOWSTONE_DUST, 1, Material.GLOWSTONE_DUST, 2);
		setMaxCooldown(100);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
		
	}
	
	@Override
	public void spellEffect() {
		
		new BukkitRunnable() {
			
			float timer = 0;
			Vector offset = player.getLocation().getDirection().clone().setY(0).normalize();
			Vector weightedoffset;
			Location particleloc;
			DustOptions dust;
		
			@Override
			public void run() {
				
				if (timer == 0) {
					
					timer++;
					
					dust = new DustOptions(Color.YELLOW, 1);
					
					Main.wandManagers.get(player).setCooldowns(12);
				
				} else if (timer < 12) {
					
					timer++;
					
					for (float i = 0 ; i < 5 ; i++) {
						
						offset.rotateAroundY(Math.PI/10);
						weightedoffset = offset.clone().multiply(0.65 * Math.sin((timer/15 + i/75) * Math.PI)).setY(timer/7.5 + i/37.5);
						particleloc = player.getLocation().clone().add(weightedoffset);
					
						player.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, particleloc, 1, 0, 0, 0, 0, null, true);
					}
					
				} else if (timer == 12) {
		
					player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2F, 2F);
					
					new BukkitRunnable() {
						
						int timer = 0;
						Location loc = player.getLocation().clone().add(new Vector(0,1.3,0));
						Vector vel = loc.getDirection().clone().multiply(0.1);
						Vector sideoffset = loc.clone().getDirection().setY(0).rotateAroundY(Math.PI/2).normalize();
						
						@Override
						public void run() {
							
							for (int i = 0 ; i < 10 ; i++) {
								for (int j = 0 ; j < 25 ; j++) {
									loc.add(vel);
									loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(sideoffset.clone().multiply(1.4 * (Math.abs(j-14) * 0.05 - 0.4))), 1, 0, 0, 0, 0, dust, true);
									if (j == 0) loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 1, 0, 0, 0, 0.08, null, true);
									if (hit(loc)) {
										cancel();
										i = 11;
										j = 30;
									}
									if (!loc.getBlock().isPassable()) {
										loc.subtract(vel);
										loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 25, 0, 0, 0, 0.2, null, true);
										loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1F, 1.7F);
										cancel();
										i = 11;
										j = 30;
									}
								}
							}
							
							timer++;
							if (timer > 5) cancel();
							
						}
						
					}.runTaskTimer(plugin, 0, 1);
					
					cancel();
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public boolean hit(Location loc) {
		
		for (LivingEntity entity:player.getWorld().getLivingEntities()) {
			
			if (entity.getBoundingBox().clone().expand(0.3).contains(loc.toVector()) && entity != player) {
				
				entity.damage(3);
				entity.setVelocity(loc.getDirection().clone().setY(0).normalize().setY(0.3));

				loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 15, 0, 0, 0, 0.2, null, true);
				loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1, 1.5F);
				player.playSound(loc, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1, 1.5F);
				
				new BukkitRunnable() {
					
					int timer = 0;
					
					@Override
					public void run() {
						
						entity.setNoDamageTicks(0);
						entity.damage(0.05);
						entity.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, entity.getBoundingBox().getCenter().toLocation(entity.getWorld()), 1, 0, 0, 0, 0.07, null, true);
						
						timer++;
						
						if (timer >= 60) {
							
							cancel();
							
						}
						
					}
					
				}.runTaskTimer(plugin, 0, 1);
				
				return true;
				
			}
			
		}
		
		return false;
		
	}

}
