package me.August.InfinityGauntlet;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class SpaceStrike {
	
	Player player;
	Plugin plugin;
	
	SpaceStrike(Player p, Plugin pl) {
		player = p;
		plugin = pl;
		double rotation;
		Location loc = player.getLocation().clone();
		Vector dir = loc.getDirection().clone().setY(0).normalize();
		Location impact;
		Vector vel;
		for(int i = 0 ; i < 30 ; i++) {
			rotation = 2*(Math.random()-0.5) * (Math.PI/4);
			impact = loc.clone().add(dir.clone().rotateAroundY(rotation).multiply(6 + i*1.5));
			vel = dir.clone().setY(-1.5).normalize().multiply(0.3);
			meteor(impact, vel);
		}
	}
	
	public void meteor(Location l, Vector d) {
		
		Vector dir = d;
		Location loc = l.add(dir.clone().normalize().multiply(-130 + -400 * Math.random()));
		
		DustOptions dust = new DustOptions(Color.BLUE, 1);
		
		new BukkitRunnable() {
			
			int timer = 0;
			
			@Override
			public void run() {
				timer++;
				for(int i = 0 ; i < 10 ; i++) {
					
					loc.add(dir);
					loc.getWorld().spawnParticle(Particle.FLAME, loc, 1, 0.1, 0.1, 0.1, 0.05, null, true);
					loc.getWorld().spawnParticle(Particle.LAVA, loc, 1, 0.1, 0.1, 0.1, 0.05, null, true);
					loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 3, 0.3, 0.3, 0.3, 0, dust, true);
					
					if(!loc.getBlock().isPassable()) {
						loc.getWorld().createExplosion(loc, 5, true);
						loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 200, 5, 5, 5, 0, dust, true);
						cancel();
					}
				}
				if(timer > 300) {
					cancel();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}

}
