package me.August.Abilities;

import java.util.HashMap;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class Manager {

	Player player;
	Plugin plugin;
	static HashMap<Player, SkillManager> skillmanagers = new HashMap<>();
	static HashMap<Player, ManaManager> manamanagers = new HashMap<>();
	static HashMap<Player, InventoryManager> inventorymanagers = new HashMap<>();
	
	public Manager(Player player)
	{
		this.player = player;
		skillmanagers.put(player, new SkillManager(player));
		manamanagers.put(player, new ManaManager(player));
		inventorymanagers.put(player, new InventoryManager(player));
	}
	
	public SkillManager getSkillManager()
	{
		return skillmanagers.get(player);
	}
	
	public ManaManager getManaManager()
	{
		return manamanagers.get(player);
	}
	
	public InventoryManager getInventoryManager()
	{
		return inventorymanagers.get(player);
	}
}
