package me.August.MechArmor;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class InventoryManager {
	
	Inventory baseInventory, mechInventory;
	Player player;
	int selected = 0;
	
	InventoryManager(Player p) {
		
		player = p;
		baseInventory = Bukkit.createInventory(player, InventoryType.PLAYER);
		mechInventory = Bukkit.createInventory(player, InventoryType.PLAYER);
		mechInventory.addItem(new ItemStack(Material.BARRIER, 69));
		initializeMechInv(mechInventory);
		
	}
	
	public int getInv() {
		
		return selected;
		
	}
	
	public void swap() {
	
		
		if(selected == 0) {
			
			selected = 1;
			baseInventory.setContents(player.getInventory().getContents().clone());
			player.getInventory().setContents(mechInventory.getContents());
			player.playSound(player.getLocation(), Sound.ENTITY_IRON_GOLEM_REPAIR, 1, 1);
			player.getInventory().setHeldItemSlot(8);
			
		} else {
			
			selected = 0;
			mechInventory.setContents(player.getInventory().getContents().clone());
			player.getInventory().setContents(baseInventory.getContents());
			player.playSound(player.getLocation(), Sound.BLOCK_REDSTONE_TORCH_BURNOUT, 1, 1);
			
		}
		
	}
	
	public HashMap<Integer, ItemStack> addToMain(ItemStack item) {
		
		if(baseInventory.firstEmpty() == -1 || baseInventory.firstEmpty() >= 36) {
			
			return null;
			
		} else {
			
			player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1, 1);
			return baseInventory.addItem(item);
			
		}
		
	}
	
	private void initializeMechInv(Inventory inv) {
		
		inv.clear();
		inv.setItem(8, Main.controller());
		inv.setItem(0, Main.attack(0));
		inv.setItem(36, new ItemStack(Material.IRON_BOOTS, 1));
		inv.setItem(37, new ItemStack(Material.IRON_LEGGINGS, 1));
		inv.setItem(38, new ItemStack(Material.IRON_CHESTPLATE, 1));
		inv.setItem(39, new ItemStack(Material.IRON_HELMET, 1));
		
	}

}
