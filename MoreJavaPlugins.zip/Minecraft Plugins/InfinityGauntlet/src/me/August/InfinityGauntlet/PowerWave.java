package me.August.InfinityGauntlet;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class PowerWave {
	
	Player player;
	Plugin plugin;
	
	PowerWave(Player p, Plugin pl) {
		
		player = p;
		plugin = pl;
		Location loc = player.getLocation();
		Vector dir = loc.getDirection();
		loc.add(dir.setY(0).normalize().multiply(1.7));
		for(int i = -5; i < 6; i++) {
			fragment(dir.clone().rotateAroundY(i * Math.PI/50));
		}
		
	}
	
	public void fragment(Vector d) {

		Vector dir = d;
		dir.setY(0).normalize().multiply(0.6);
		
		new BukkitRunnable() {
			int timer = 0;
			Location loc = player.getLocation();
			@Override
			public void run() {
				
				for(int i = 0 ; i < 2 ; i++) {
					
					loc.add(dir);
					loc.setY(highestblock(loc));
					loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 15, 1, 0.3, 1, 1, Material.PURPLE_WOOL.createBlockData(), true);
					loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 10, 1, 0.2, 1, 1, loc.clone().add(new Vector(0,-1,0)).getBlock().getBlockData(), true);
					loc.getWorld().playSound(loc, Sound.BLOCK_STONE_BREAK, 0.3F, 0.6F);
					hit(loc, dir);
				
				}
				timer++;
				if(timer > 40) {
					cancel();
				}
			}
		}.runTaskTimer(plugin,0,1);
		
	}
	
	public double highestblock(Location l) {
		Location loc = l.getBlock().getLocation();
		if(loc.getBlock().isPassable()) {
			int k = 0;
			while(k == 0) {
				loc.add(new Vector(0,-1,0));
				if(!loc.getBlock().isPassable()) {
					k = 1;
					loc.add(new Vector(0,0.75,0));
				}
				if(loc.getY() < 0) {
					k = 1;
				}
			}
		} else {
			int k = 0; 
			while(k == 0) {
				loc.add(new Vector(0,1,0));
				if(loc.getBlock().isPassable()) {
					k = 1;
					loc.add(new Vector(0,-0.25,0));
				}
			}
		}
		return loc.getY();
	}
	
	public void hit(Location l, Vector dir) {
		Location loc = l.clone().add(new Vector(0,0.5,0));
		for(LivingEntity entity:player.getWorld().getLivingEntities()) {
			if(loc.distance(entity.getLocation())<2 && entity != player) {
				entity.damage(3);
				entity.setVelocity(dir.clone().normalize().add(new Vector(0,0.2,0)).multiply(2.5));
			}
		}
	}
}
