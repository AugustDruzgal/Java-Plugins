package me.August.SwordBlocking;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;

public final class SwordBlockEvent extends Event implements Cancellable {

    private static final HandlerList handlers = new HandlerList();
    private Player player;
    private ItemStack sword;
    private boolean cancelled = false;
	
    SwordBlockEvent(Player p, ItemStack item)
    {
    	player = p;
    	sword = item;
    }
    
    public Player getPlayer()
    {
    	return player;
    }
    
    public ItemStack getSwordItem()
    {
    	return sword;
    }
    
	public HandlerList getHandlers()
	{
		return handlers;
	}
	
	public static HandlerList getHandlerList() {
        return handlers;
    }

	@Override
	public boolean isCancelled() {
		return cancelled;
	}

	@Override
	public void setCancelled(boolean cancel) {
		cancelled = cancel;
	}
}
