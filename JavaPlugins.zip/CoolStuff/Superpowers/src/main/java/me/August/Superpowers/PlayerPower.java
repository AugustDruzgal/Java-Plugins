package me.August.Superpowers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import org.bukkit.entity.Player;

public class PlayerPower {
	
	static HashMap<String, Double> probabilities = getProbabilities();
	private Random random;
	private Player player;
	private HashMap<String, Integer> powers;
	private int level = 0;
	private boolean flying = false;
	
	public PlayerPower(Player player)
	{
		this.player = player;
		random = new Random();
		random.setSeed(System.currentTimeMillis());
		powers = getDefaultPowers();
		updateSpeed();
	}
	
	public void reset()
	{
		this.level = 0;
		this.powers = getDefaultPowers();
	}
	
	public void developPowers(int amount)
	{
		if (level >= amount)
			return;
		for (int i = 0; i < amount/5 + 2 - getPowerCount(); i++)
		{
			if (areNewPowersLeft())
			{
				powers.put(getRandomNewPower(), amount);
			}
		}
		powers.put("Strength", amount);
		powers.put("Durability", amount);
		for (int i = 0; i < getPowerNames().length; i++)
		{
			if (powers.get(getPowerNames()[i]) > 0)
			{
				powers.put(getPowerNames()[i], amount);
			}
		}
		sendPowerInfo();
		updateSpeed();
	}
	
	public void sendPowerInfo()
	{
		String[] allpowers = getPowerNames();
		
		player.sendMessage("Your powers:");
		for (int i = 0; i < allpowers.length; i++)
		{
			if (powers.get(allpowers[i]) > 0)
			{
				player.sendMessage("  -" + allpowers[i] + ": level " + powers.get(allpowers[i]));
			}
		}
	}
	
	public void updateSpeed()
	{
		float speed = 0.2f + 0.02f * powers.get("Speed");
		if (speed > 1)
			speed = 1;
		player.setWalkSpeed(speed);
		player.setAllowFlight(powers.get("Flight") > 0);
	}
	
	public void resetSpeed()
	{
		player.setWalkSpeed(0.2f);
	}
	
	public int getPowerLevel(String target)
	{
		if (powers.containsKey(target))
			return powers.get(target);
		return 0;
	}
	
	public int getLevel()
	{
		return level;
	}
	
	public boolean getFlight()
	{
		return flying;
	}
	
	public void toggleFlight()
	{
		flying = !flying;
	}
	
	public boolean hasPower(String p)
	{
		if (powers.containsKey(p) && powers.get(p) > 0)
		{
			return true;
		}
		return false;
	}
	
	private Boolean areNewPowersLeft()
	{
		String[] names = getPowerNames();
		for (int i = 0; i < powers.size(); i++)
		{
			if (powers.get(names[i]) == 0)
			{
				return true;
			}
		}
		return false;
	}
	
	private static HashMap<String, Double> getProbabilities()
	{
		HashMap<String, Double> p = new HashMap<>();
		p.put("Strength", 0.0);
		p.put("Durability", 0.0);
		p.put("Speed", 0.25);
		p.put("Laser", 0.25);
		p.put("Punch", 0.25);
		p.put("Flight", 0.25);
		
		return p;
	}
	
	private String getRandomNewPower()
	{
		String[] c = getPowerNames();
		ArrayList<String> choices = new ArrayList<>();
		double choice = 0;
		double probability;
		
		for (int i = 0; i < c.length; i++)
		{
			if (powers.get(c[i]) == 0)
			{
				choices.add(c[i]);
			}
		}
		
		if (choices.size() == 0)
			return getRandomOldPower();
		
		for (int i = 0; i < choices.size(); i++)
		{
			choice += probabilities.get(choices.get(i));
		}
		
		choice *= Math.random();
		
		for (int i = 0; i < choices.size(); i++)
		{
			probability = probabilities.get(choices.get(i));
			if (choice <= probability)
			{
				return choices.get(i);
			}
			choice -= probability;
		}
		return "Strength";
	}
	
	private int getPowerCount()
	{
		int count = 0;
		String[] powernames = getPowerNames();
		for (int i = 0; i < powernames.length; i++)
		{
			if (powers.get(powernames[i]) > 0)
			{
				count++;
			}
		}
		return count;
	}
	
	private String getRandomOldPower()
	{
		String[] c = getPowerNames();
		ArrayList<String> choices = new ArrayList<>();
		for (int i = 0; i < powers.size(); i++)
		{
			if (powers.get(c[i]) > 0)
			{
				choices.add(c[i]);
			}
		}
		return choices.get(random.nextInt(choices.size()));
	}
	
	public static String[] getPowerNames()
	{
		String[] p = {"Strength", "Durability", "Speed", "Punch", "Laser", "Flight"};
		return p;
	}
	
	private HashMap<String, Integer> getDefaultPowers()
	{
		HashMap<String, Integer> p = new HashMap<>();
		p.put("Strength", 0);
		p.put("Durability", 0);
		p.put("Speed", 0);
		p.put("Punch", 0);
		p.put("Laser", 0);
		p.put("Flight", 0);
		
		return p;
	}

}
