module MobMitosis {
	requires spigot;
	requires java.net.http;
}