package me.August.Smash;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	HashMap<LivingEntity, Float> percent = new HashMap<LivingEntity, Float>();
	
	@Override 
	public void onEnable() {
		Bukkit.getPluginManager().registerEvents(this, this);
	}
	
	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		percent.put(e.getPlayer(), 0F);
	}
	
	@EventHandler
	public void onDeath(PlayerDeathEvent e) {
		percent.put(e.getEntity(), 0F);
	}
	
	@EventHandler
	public void onSpawn(EntitySpawnEvent e) {
		if(e.getEntity() instanceof LivingEntity) {
			percent.put((LivingEntity) e.getEntity(), 0F);
		}
	}
	
	public void onEntityDeath(EntityDeathEvent e) {
		percent.remove(e.getEntity());
	}
	
	@EventHandler
	public void onHit(EntityDamageByEntityEvent e) {
		if(e.getEntity() instanceof LivingEntity && e.getDamager() instanceof LivingEntity) {
			LivingEntity entity = (LivingEntity) e.getEntity();
			LivingEntity source = (LivingEntity) e.getDamager();
			float damage = (float) e.getDamage();
			Vector dir = source.getLocation().getDirection().clone().normalize();
			e.setCancelled(true);
			if(percent.get(entity)<100) {
				percent.put(entity, damage + percent.get(entity));
				entity.setVelocity(dir.add(new Vector(0,0.2,0)).multiply(percent.get(entity)*0.05));
				entity.damage(0.01);
				entity.setNoDamageTicks(0);
			} else {
				
			}
		}
		
	}

}
