package me.August.Superpowers;

import java.util.HashMap;

import org.bukkit.entity.Player;

public class HotkeyManager {
	
	private static HashMap<Player, Keyset> keys = new HashMap<>();
	
	public static void createKeyset(Player player)
	{
		keys.put(player, new Keyset(player));
	}
	
	public static void usePower(Player player, int slot)
	{
		String power = keys.get(player).getBind(slot);
		if (power == "none")
			return;
		PowerEffects.activatePower(player, power, Main.getPlayerPower(player).getPowerLevel(power));
	}
	
	public static void bind(Player player, String power, int slot)
	{
		keys.get(player).setBind(slot, power);
	}

}
