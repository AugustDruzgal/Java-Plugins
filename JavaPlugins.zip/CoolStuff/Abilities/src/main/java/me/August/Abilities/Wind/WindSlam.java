package me.August.Abilities.Wind;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class WindSlam extends Skill {
	
	BukkitTask charge = null;
	int time = 0;
	float power = 0;

	public WindSlam(Player p, Plugin pl) {
		super(p, pl);
		setMaxCooldown(120);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		if (power < 100)
			player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8F, (float) (0.5 + (power/100)));
		if (charge == null)
		{
			time = 5;
			charge = new BukkitRunnable()
			{
				@Override
				public void run()
				{
					time--;
					if (power >= 100)
						power = 100;
					else
						power = power + 5;
					displayChargeBar(power);
					{
						
					}
					if (time == 0)
					{
						launch();
						power = 0;
						charge = null;
						startCooldown(maxCooldown, true);
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
		else
		{
			time = 5;
		}
	}
	
	private void displayChargeBar(float power2)
	{
		double counter = power2;
		TextComponent component = Component.text("Charge : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - 2.5;
			if (counter >= 0)
				component = component.append(Component.text("|").color(TextColor.color(40, 255, 100)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		player.sendActionBar(component);
	}
	
	private void launch()
	{
		player.setVelocity(player.getLocation().getDirection().clone().add(new Vector(0, 0.1, 0)).normalize().multiply(0.5 + power/70));
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1F, 1.5F);
		player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 40, 0.7, 0.7, 0.7, 0.2, null, true);
		
		new BukkitRunnable()
		{
			int timer = 0;
			@Override
			public void run()
			{
				player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 4, 0, 0, 0, 0.04, null, true);
				if (hit())
					timer = 100;
				timer++;
				if (timer > 10)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private boolean hit()
	{
		boolean hit = false;
		Location loc = player.getLocation().clone();
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			if (entity != player && loc.toVector().distance(entity.getLocation().toVector()) < 2)
			{
				hit = true;
				entity.damage(3);
				entity.setVelocity(player.getVelocity().clone().setY(0).normalize().setY(0.2).multiply(1.5));
				player.setVelocity(player.getVelocity().clone().normalize().multiply(0.5));
			}
		}
		if (hit)
			player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 40, 0.7, 0.7, 0.7, 0.23, null, true);
		return hit;
	}
}
