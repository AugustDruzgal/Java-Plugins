module Shock {
	requires spigot;
	requires comm;
	requires comm-2.0.jar;
}