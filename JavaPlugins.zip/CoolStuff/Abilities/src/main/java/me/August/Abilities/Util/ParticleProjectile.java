package me.August.Abilities.Util;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public abstract class ParticleProjectile {
	
	boolean curving = false;
	double angle = 0;
	double speed = 1;
	double size = 0.3;
	double range = 30;
	int lifetime = 100;
	int moves = 20;
	Location location;
	Location lastlocation;
	Vector direction;
	Plugin plugin;
	Player caster;
	
	public ParticleProjectile(Location l, Vector d, Player c, Plugin p)
	{
		location = l.clone();
		direction = d;
		plugin = p;
		caster = c;
	}
	
	public void start()
	{
		castParticle(location);
		direction = direction.clone().normalize().multiply(speed * 0.05);
		lastlocation = location;
		
		new BukkitRunnable()
		{
			int time = 0;
			
			@Override
			public void run()
			{
				lastlocation = location.clone();
				time++;
				for (int i = 0; i < moves; i++)
				{
					move();
					if (hitObject() || hitEntity())
					{
						location = location.subtract(direction);
						impactParticle(location);
						cancel();
						i = moves;
						moveParticle(location, moves - 1);
					}
					else
						moveParticle(location, i);
				}
				if (time >= lifetime)
					cancel();
			}
			
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public ParticleProjectile setCurve(boolean active, double a, double r)
	{
		curving = active;
		angle = a;
		range = r;
		return this;
	}
	
	public ParticleProjectile setCurve(boolean active, double a)
	{
		curving = active;
		angle = a;
		return this;
	}
	
	public ParticleProjectile setCurve(boolean active)
	{
		curving = active;
		return this;
	}
	
	public ParticleProjectile setLifetime(int ticks)
	{
		lifetime = ticks;
		return this;
	}
	
	public ParticleProjectile setSize(double s)
	{
		size = s;
		return this;
	}
	
	public ParticleProjectile setSpeed(double s)
	{
		speed = s;
		return this;
	}
	
	public ParticleProjectile setMovesPerTick(int m)
	{
		moves = m;
		return this;
	}
	
	public Integer getMovesPerTick()
	{
		return moves;
	}
	
	public Location getLocation()
	{
		return location;
	}
	
	public Location getLastLocation()
	{
		return lastlocation;
	}
	
	public Vector getDirection()
	{
		return direction.clone().normalize();
	}
	
	public abstract void moveParticle(Location loc, int time);
	
	public abstract void impactParticle(Location loc);
	
	public abstract void castParticle(Location loc);
	
	public abstract void hitEffect(LivingEntity entity);
	
	private boolean hitEntity()
	{
		boolean hit = false;
		for(LivingEntity entity:location.getWorld().getLivingEntities())
		{
			if (entity == caster)
				continue;
			if (entity.getBoundingBox().clone().expand(size).contains(location.toVector()))
			{
				hit = true;
				hitEffect(entity);
			}
		}
		return hit;
	}
	
	private void move()
	{
		location = location.add(direction);
		if (curving)
		{
			direction = turnTowardsNearestEntity();
		}
	}
	
	private boolean hitObject()
	{
		if (!location.getBlock().isPassable())
			return true;
		return false;
	}
	
	private Vector turnTowardsNearestEntity()
	{
		Vector dir = direction.clone();
		Vector temp;
		Vector diff;
		Vector cross = null;
		LivingEntity target = null;
		double minangle = 0;
		
		for (LivingEntity entity:location.getWorld().getLivingEntities())
		{
			if (entity == caster)
				continue;
			temp = entity.getBoundingBox().getCenter();
			diff = location.clone().toVector().subtract(temp);
			if (dir.angle(diff) > minangle && diff.length() < range)
			{
				minangle = dir.angle(diff);
				target = entity;
				cross = dir.getCrossProduct(diff).normalize().multiply(-1);
			}
		}
		
		if (target == null || cross == null)
		{
			return dir;
		}
		
		dir = dir.rotateAroundAxis(cross, angle * 0.05);
		
		return dir;
	}
}
