package me.August.Abilities.Storm;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import me.August.Abilities.Util.Utils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class ThunderWarp extends Skill implements Utils {

	BukkitTask charge = null;
	int time = 0;
	
	public ThunderWarp(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		if (charge == null)
		{
			time = 5;
			charge = new BukkitRunnable()
			{
				double total = 0;
				@Override
				public void run() {
					time--;
					if (time == 0)
					{
						cancel();
						charge = null;
						
						teleport(total);
					}
					else
					{
						if (total < 100)
							total = total + 1.25 + 0.25 * level;
						displayChargeBar(total);
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
		else
		{
			time = 5;
		}
	}
	
	private void displayChargeBar(double power2)
	{
		double counter = power2;
		TextComponent component = Component.text("Charge : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - 2.5;
			if (counter >= 0)
				component = component.append(Component.text("|").color(TextColor.color(40, 255, 100)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		player.sendActionBar(component);
	}

	private void teleport(double amount)
	{
		Block target = player.getTargetBlock(120);
		Location loc = player.getLocation().clone();
		Location temp;
		if (amount < 100)
		{
			player.playSound(loc, Sound.BLOCK_FIRE_EXTINGUISH, 1F, 1F);
			startCooldown(30, true);
			return;
		}
		if (target == null)
		{
			target = Utils.getBlockOnSurface(loc.clone().add(loc.clone().getDirection().multiply(120)));
			if (target == null)
			{
				player.playSound(loc, Sound.BLOCK_FIRE_EXTINGUISH, 1F, 1F);
				return;
			}
		}
		else
		{
			target = Utils.getBlockOnSurface(target.getLocation());
		}
		temp = target.getLocation().toCenterLocation().add(new Vector(0, 0.6, 0)).setDirection(loc.getDirection());
		loc.getWorld().strikeLightningEffect(loc);
		loc.getWorld().strikeLightningEffect(temp);
		player.teleport(temp);
		startCooldown(100, true);
	}
}
