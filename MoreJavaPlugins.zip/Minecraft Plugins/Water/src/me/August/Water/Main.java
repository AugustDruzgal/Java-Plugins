package me.August.Water;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;


public class Main extends JavaPlugin implements Listener {
	
	static HashMap<Location, TempBlock> tempblocks = new HashMap<Location, TempBlock>();
	BukkitTask update;
	
	@Override
	public void onEnable() {
		Bukkit.getPluginManager().registerEvents(this, this);
		update = new BukkitRunnable() {
			@Override
			public void run() {
				for(Player player : Bukkit.getOnlinePlayers()) {
					if(player.isSwimming()) {
						fillwater(player);
						player.setVelocity(player.getLocation().getDirection().normalize());
						player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,1,1));
						player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING,1,1));
						player.addPotionEffect(new PotionEffect(PotionEffectType.CONDUIT_POWER,1,1));
					} else {
						player.setWalkSpeed(0.2F);
						player.removePotionEffect(PotionEffectType.NIGHT_VISION);
						player.removePotionEffect(PotionEffectType.WATER_BREATHING);
						player.removePotionEffect(PotionEffectType.CONDUIT_POWER);
						
					}
				}
			}
		}.runTaskTimer(this, 0, 1);
	}
	
	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	public void onFlow(BlockFromToEvent e) {
		if(tempblocks.containsKey(e.getBlock().getLocation())) {
			e.setCancelled(true);
		}
	}
	
	public void fillwater(Player p) {
		Location loc = p.getLocation().getBlock().getLocation();
		Location loc2;
		for(int i = -3 ; i < 4+ ; i++) {
			for(int j = -3 ; j < 4 ; j++) {
				for(int k = -3 ; k < 4 ; k++) {
					loc2 = loc.clone().add(new Vector(i,j,k));
					double dist = loc.clone().toVector().distance(loc2.clone().toVector());
					if(dist < 3 && loc.getBlock().getType() == Material.AIR || loc.getBlock().getType() == Material.CAVE_AIR) {
						
						if(tempblocks.containsKey(loc2)) {
							tempblocks.get(loc2).endSchedule();
							tempblocks.put(loc2, new TempBlock(Material.WATER,loc2,(int) Math.round(100 - (dist*10)),this,true,tempblocks.get(loc2).getOriginal()));
						} else {
							tempblocks.put(loc2, new TempBlock(Material.WATER,loc2,(int) Math.round(100 - (dist*10)),this,false,null));
						}
					}
				}
			}
		}
	}

}
