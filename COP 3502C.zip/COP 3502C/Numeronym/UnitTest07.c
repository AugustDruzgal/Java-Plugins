// Sean Szumlanski
// COP 3502, Spring 2022

// =======================
// Numeronym: UnitTest07.c
// =======================
// Tests the functionality of your printNumeronym() function.
//
// If this test case is crashing with a segfault, it might be because you are
// trying to modify the string. You should not modify the string passed to
// printNumeronym().


#include <stdio.h>
#include "Numeronym.h"

// This acts as the main() function for this test case.
int unit_test(int argc, char **argv)
{
	printNumeronym("send");
	printNumeronym("this");
	printNumeronym("DATa");
	printNumeronym("to");
	printNumeronym("the");
	printNumeronym("iNtErNaTiOnAlIzAtIoN");
	printNumeronym("team");
	printNumeronym("for");
	printNumeronym("pRoCeSsInG");

	return 0;
}
