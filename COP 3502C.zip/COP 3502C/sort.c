#include <stdio.h>
#include <stdlib.h>

// kPositive(int *array, int n, int k);

int main(void)
{
	
	int n = -1;
	return -n;

}


// int kPositive(int *array, int n, int k)
// {
	// if (k < 0)
		// return 1;
	// if (k > n)
		// return 0;
	// if (array[n-k] > 0)
		// return 1;
	// return 0;
// }

// O(1)
// O(1)
