package me.August.InfinityGauntlet;

import java.util.ArrayList;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class TimeBlast {
	Player player;
	Plugin plugin;
	ArrayList<LivingEntity> hitentities = new ArrayList<LivingEntity>();
	
	TimeBlast(Player p, Plugin pl) {
		
		player = p;
		plugin = pl;
		
		new BukkitRunnable() {
			
			int timer = 0;
			Location loc = player.getLocation().clone().add(new Vector(0,1.3,0));;
			Vector dir = loc.getDirection().normalize().multiply(0.5);;
			
			
			@Override
			public void run() {
				
				Location l = loc.clone();
				
				for(int i = 0 ; i < 150 ; i++) {
					
					l.add(dir);
					hit(l);
					if (!l.getBlock().isPassable()) {
						electricparticle(loc, i*0.45F);
						i = 69420;
					} else if (i == 149) {
						electricparticle(loc, i*0.45F);
					}
				}
				timeParticle(loc.clone().add(dir.clone().multiply(3.5)), player.getLocation().getDirection(), 1);
				timer++;
				
				if (timer > 5) {
					cancel();
				}
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void hit(Location loc) {
		for(LivingEntity entity : player.getWorld().getLivingEntities()) {
			if(entity.getLocation().clone().add(new Vector(0,1,0)).distance(loc) < 2 && entity != player && !hitentities.contains(entity)) {
				entity.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, 200, 5));
				hitentities.add(entity);
				new BukkitRunnable() {
					
					int timer = 0;
					
					@Override
					public void run() {
						entity.setVelocity(new Vector(0,0.001,0));
						timeParticle(entity.getLocation().clone().add(new Vector(0, entity.getHeight()/2, 0)), entity.getLocation().getDirection().clone().setX(0).setY(1000).setZ(0.1).normalize(), 1.5F);
						timer++;
						if(timer > 200) {
							cancel();
						}
					}
					
				}.runTaskTimer(plugin, 0, 1);
				
			}
		}
	}
	
	public void electricparticle(Location l, float blocks) {
		Location loc = l.clone();
		Vector dir = loc.getDirection().clone().normalize().multiply(0.25);
		Vector offset1 = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.2).rotateAroundNonUnitAxis(loc.getDirection(), Math.PI * 2 * Math.random());
		Vector offset2 = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.2).rotateAroundNonUnitAxis(loc.getDirection(), Math.PI * 2 * Math.random());
		Location offset1loc = loc.clone().add(offset1);
		Location offset2loc = loc.clone().add(dir).add(offset2);
		Location offset12loc;
		for(int i = 0; i < (4 * blocks) ; i++) {
			offset1 = offset2;
			offset2 = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.5).rotateAroundNonUnitAxis(loc.getDirection(), Math.PI * 2 * Math.random());
			offset1loc = loc.clone().add(offset1);
			offset2loc = loc.clone().add(dir).add(offset2);
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 10, 0.02, 0.02, 0.02, 0.1, new DustOptions(Color.WHITE, 0.35F), true);
			for(int j = 0 ; j < 20 ; j++) {
				offset12loc = offset1loc.clone().add(offset1loc.clone().subtract(offset2loc).multiply(-j*0.05).toVector());
				loc.getWorld().spawnParticle(Particle.REDSTONE, offset12loc, 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, 0.25F), true);
			}
			loc.add(dir);
		}
	}
	
	public void timeParticle(Location l, Vector dir, float size) {
		Location loc = l.clone();
		Vector offset = dir.clone().setY(0).normalize().multiply(size).rotateAroundY(Math.PI/2);
		float circledensity = 120 * size;
		float squaredensity = size * 26;
		float thickness = 0.2F;
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(size * 1.1);
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(Math.sqrt(Math.pow(size, 2)/2));
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(Math.sqrt(Math.pow(size, 2)/2) - size*0.1);
		for(int i = 0 ; i < circledensity ; i++) {
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			offset.rotateAroundNonUnitAxis(dir, 2 * Math.PI/circledensity);
		}
		offset.normalize().multiply(size);
		loc = loc.add(offset);
		offset.rotateAroundNonUnitAxis(dir, 3*Math.PI/4);
		offset.normalize().multiply(Math.sqrt(size*size + size*size)/squaredensity);
		for(int i = 0; i < 4 ; i++) {
			for(int j = 0 ; j < squaredensity ; j++) {
				loc.add(offset);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			}
			offset.rotateAroundNonUnitAxis(dir, Math.PI/2);
		}
		offset = dir.clone().setY(0).normalize().multiply(size).rotateAroundY(Math.PI/2).rotateAroundNonUnitAxis(dir, Math.PI/4);
		loc = l.clone().add(offset);
		offset.rotateAroundNonUnitAxis(dir, 3*Math.PI/4);
		offset.normalize().multiply(Math.sqrt(size*size + size*size)/squaredensity);
		for(int i = 0; i < 4 ; i++) {
			for(int j = 0 ; j < squaredensity ; j++) {
				loc.add(offset);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0.1, new DustOptions(Color.LIME, thickness), true);
			}
			offset.rotateAroundNonUnitAxis(dir, Math.PI/2);
		}
	}
}
