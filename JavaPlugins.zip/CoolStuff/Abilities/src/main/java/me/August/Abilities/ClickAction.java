package me.August.Abilities;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public interface ClickAction {
	
	public void action(Player player, Plugin plugin);

}
