package me.August.Gauntlet;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.inventory.ItemStack;

public class PlayerItemInfo {
	
	HashMap<ItemStack, GuiItem> guiItemMap = new HashMap<>();
	ArrayList<GuiItem> guiItemList = new ArrayList<>();
	
	public void addPlayerItem(GuiItem item, String key)
	{
		guiItemMap.put(item.getAsItemStack(), item);
		guiItemList.add(item);
	}
	
	public GuiItem getGuiItem(ItemStack item)
	{	
		return guiItemMap.get(item);
	}
	
	public void updateCooldowns()
	{
		for (GuiItem item:guiItemList)
		{
			item.updateCooldowns();
		}
	}
}
