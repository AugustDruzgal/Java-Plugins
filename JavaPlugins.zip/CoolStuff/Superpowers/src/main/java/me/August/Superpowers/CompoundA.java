package me.August.Superpowers;

import java.util.HashMap;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

public class CompoundA {
	
	private static HashMap<String, ItemStack> itemlist = getItemList();
	
	public static ItemStack getItem(String key)
	{
		if (itemlist.containsKey(key))
			return itemlist.get(key).clone();
		return null;
	}
	
	private static HashMap<String, ItemStack> getItemList()
	{
		HashMap<String, ItemStack> ilist = new HashMap<>();
		ilist.put("A10", getA10());
		ilist.put("A15", getA15());
		ilist.put("A20", getA20());
		return ilist;
	}
	
	private static ItemStack getA10()
	{
		ItemStack compound = new ItemStack(Material.LIGHT_BLUE_DYE);
		ItemMeta meta = compound.getItemMeta().clone();
		meta.setCustomModelData(2);
		meta.displayName(Component.text("Compound A10").color(TextColor.color(50, 150, 205)));
		compound.setItemMeta(meta);
		return compound;
	}
	
	private static ItemStack getA15()
	{
		ItemStack compound = new ItemStack(Material.LIGHT_BLUE_DYE);
		ItemMeta meta = compound.getItemMeta().clone();
		meta.setCustomModelData(3);
		meta.displayName(Component.text("Compound A15").color(TextColor.color(75, 175, 230)));
		compound.setItemMeta(meta);
		return compound;
	}
	
	private static ItemStack getA20()
	{
		ItemStack compound = new ItemStack(Material.LIGHT_BLUE_DYE);
		ItemMeta meta = compound.getItemMeta().clone();
		meta.setCustomModelData(4);
		meta.displayName(Component.text("Compound A20").color(TextColor.color(100, 200, 255)));
		compound.setItemMeta(meta);
		return compound;
	}
}
