package me.August.Abilities.Earth;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class Rupture extends Skill {

	BukkitTask charge = null;
	int time = 0;
	float power = 0;
	
	public Rupture(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		if (!isOnGround(player.getLocation()))
			return;
		if (power < 100)
			player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8F, (float) (0.5 + (power/100)));
		if (charge == null)
		{
			
			time = 5;
			charge = new BukkitRunnable()
			{
				Location loc = player.getLocation().clone().subtract(new Vector(0, 1, 0));
				Location target = player.getTargetBlock(100).getLocation().clone().add(new Vector(0.5, 0.5, 0.5));
				@Override
				public void run()
				{
					time--;
					if (power >= 100)
						power = 100;
					else
						power = power + 2;
					displayChargeBar(power);
					target = player.getTargetBlock(100).getLocation().clone().add(new Vector(0.5, 0.5, 0.5));
					loc = moveTowards(loc, target);
					crack(loc);
					if (time == 0)
					{
						burst(loc, power);
						power = 0;
						charge = null;
						startCooldown(140, true);
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
		else
		{
			time = 5;
		}
	}
	
	private void displayChargeBar(float power2)
	{
		double counter = power2;
		TextComponent component = Component.text("Charge : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - 2.5;
			if (counter >= 0)
				component = component.append(Component.text("|").color(TextColor.color(40, 255, 100)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		player.sendActionBar(component);
	}
	
	private Location moveTowards(Location current, Location target)
	{
		Vector move = new Vector(0, 0, 0);
		if (target.getX() > current.getX() && current.clone().add(new Vector(1, 0, 0)).getBlock().isSolid())
			move.add(new Vector(1, 0, 0));
		if (target.getX() < current.getX() && current.clone().add(new Vector(-1, 0, 0)).getBlock().isSolid())
			move.add(new Vector(-1, 0, 0));
		if (target.getY() > current.getY() && current.clone().add(new Vector(0, 1, 0)).getBlock().isSolid())
			move.add(new Vector(0, 1, 0));
		if (target.getY() < current.getY() && current.clone().add(new Vector(0, -1, 0)).getBlock().isSolid())
			move.add(new Vector(0, -1, 0));
		if (target.getZ() > current.getZ() && current.clone().add(new Vector(0, 0, 1)).getBlock().isSolid())
			move.add(new Vector(0, 0, 1));
		if (target.getZ() < current.getZ() && current.clone().add(new Vector(0, 0, -1)).getBlock().isSolid())
			move.add(new Vector(0, 0, -1));
		if (move.length() > 0.5)
			move.normalize().multiply(0.5);
		return current.clone().add(move);
	}
	
	private void crack(Location loc)
	{
		loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 50, 0.5, 0.5, 0.5, 1, loc.getBlock().getBlockData(), true);
		loc.getWorld().playSound(loc, Sound.BLOCK_GRAVEL_BREAK, 1F, 1F);
	}
	
	private void burst(Location loc, float power)
	{
		loc.add(new Vector(0, 1, 0));
		player.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 100, 1.7, 0.3, 1.7, 1, Material.DIRT.createBlockData(), true);
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getLocation().distance(loc) < 2)
			{
				entity.damage(power/20 + 3);
				entity.setVelocity(entity.getLocation().clone().subtract(loc).toVector().normalize().setY(0.5).normalize().multiply(power/100));
			}
		}
	}
	
	public boolean isOnGround(Location loc)
	{
		if (!loc.clone().add(new Vector(0, -0.2, 0)).getBlock().isPassable())
			return true;
		return false;
	}
}