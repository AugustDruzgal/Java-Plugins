module Wands {
	requires spigot;
}