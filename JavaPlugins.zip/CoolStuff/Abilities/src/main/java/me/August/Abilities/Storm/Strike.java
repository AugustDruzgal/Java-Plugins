package me.August.Abilities.Storm;

import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Firework;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.Skill;
import me.August.Abilities.Util.Utils;

public class Strike extends Skill implements Utils {

	public Strike(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() < 75)
		{
			return;
		}
		startCooldown(120 - 5 * level, true);
		manager.removeMana(100 - 4 * level);
		bolt();
	}

	private void bolt()
	{
		player.setVelocity(player.getLocation().getDirection().clone().setY(0).normalize().setY(0.4).normalize().multiply(1.5));
		
		new BukkitRunnable()
		{
			Location loc;
			int time = 0;
			@Override
			public void run()
			{
				time++;
				player.setFallDistance(0);
				if (time > 7 && !player.getLocation().clone().add(new Vector(0, -0.01, 0)).getBlock().isPassable())
				{
					loc = player.getLocation().clone();
					loc.getWorld().strikeLightningEffect(loc);
					particle(loc);
					spawnFirework(loc);
					loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 20, 0, 0, 0, 0.225, null, true);
					for (LivingEntity entity:loc.getWorld().getLivingEntities())
					{
						if (entity != player && loc.distance(entity.getLocation()) <= 5)
						{
							entity.damage(5, player);
							entity.setVelocity(entity.getLocation().
									clone().
									subtract(loc)
									.toVector()
									.normalize()
									.setY(0.3)
									.normalize()
									.multiply(1.1));
							Utils.shock(entity, 20);
							player.damage(0.3);
						}
					}
					time = 50;
				}
				if (time > 40)
				{
					cancel();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private void spawnFirework(Location loc)
	{
		Firework firework = (Firework) player.getWorld().spawn(loc, Firework.class);
		FireworkMeta meta = firework.getFireworkMeta();
		meta.addEffect(FireworkEffect.builder().withColor(Color.YELLOW).with(Type.BALL_LARGE).with(Type.STAR).build());
		firework.setFireworkMeta(meta);
		firework.addScoreboardTag("nodamage");
		firework.detonate();
	}
	
	private void particle(Location loc)
	{
		Vector offset = new Vector(0, 0, 4.5);
		for(int i = 0; i < 480; i++)
		{
			offset.rotateAroundY(Math.PI/60);
			offset.add(new Vector(0, 0.02, 0));
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(offset), 1, 0, 0, 0, 0, new DustOptions(Color.AQUA, 1), true);
		}
	}
}
