package me.August.InteractableItems;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener {
	
	ArrayList<Action> actionList;
	static HashMap<EquipmentSlot, HashMap<Action, ArrayList<InteractableItem>>> items;
	
	@Override
	public void onEnable()
	{
		items = initItemMap();
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	@EventHandler
	public void onClick(PlayerInteractEvent e)
	{
		ItemStack item = e.getItem();
		for (InteractableItem interactable:items.get(e.getHand()).get(e.getAction()))
		{
			if (interactable.isAcceptable(item))
			{
				interactable.effect(e.getPlayer());
			}
		}
		
	}
	
	@EventHandler
	public void onEntityClick(PlayerInteractAtEntityEvent e)
	{
		EquipmentSlot hand = e.getHand();
		ItemStack item = e.getPlayer().getInventory().getItemInMainHand();
		
		for (InteractableItem interactable:items.get(hand).get(Action.RIGHT_CLICK_AIR))
		{
			if (interactable.isAcceptable(item))
			{
				interactable.effect(e.getPlayer());
			}
		}
	}
	
	@EventHandler
	public void onDrop()
	{
		
	}
	
	private HashMap<EquipmentSlot, HashMap<Action, ArrayList<InteractableItem>>> initItemMap()
	{
		HashMap<EquipmentSlot, HashMap<Action, ArrayList<InteractableItem>>> map = new HashMap<>();
		map.put(EquipmentSlot.HAND, new HashMap<Action, ArrayList<InteractableItem>>());
		map.put(EquipmentSlot.OFF_HAND, new HashMap<Action, ArrayList<InteractableItem>>());
		map.get(EquipmentSlot.HAND).put(Action.LEFT_CLICK_AIR, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.HAND).put(Action.RIGHT_CLICK_AIR, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.HAND).put(Action.LEFT_CLICK_BLOCK, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.HAND).put(Action.RIGHT_CLICK_BLOCK, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.OFF_HAND).put(Action.LEFT_CLICK_AIR, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.OFF_HAND).put(Action.RIGHT_CLICK_AIR, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.OFF_HAND).put(Action.LEFT_CLICK_BLOCK, new ArrayList<InteractableItem>());
		map.get(EquipmentSlot.OFF_HAND).put(Action.RIGHT_CLICK_BLOCK, new ArrayList<InteractableItem>());
		return map;
	}

}
