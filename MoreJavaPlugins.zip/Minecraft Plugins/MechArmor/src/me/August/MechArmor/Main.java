package me.August.MechArmor;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	static HashMap<Player, InventoryManager> managers = new HashMap<Player, InventoryManager>();
	HashMap<Player, AttackManager> aManagers = new HashMap<Player, AttackManager>();
	
	@Override
	public void onEnable() {
		
		Bukkit.getPluginManager().registerEvents(this, this);
		
		new BukkitRunnable() {
			
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				
				for(Player player : Bukkit.getOnlinePlayers()) {
					
					if(managers.get(player).getInv() == 1) {
						
						if(player.isOnGround()) {
							
							player.setAllowFlight(true);
							
						}
						
					} else {
						
						if(player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
						
							player.setAllowFlight(true);
						
						} else {
							
							player.setAllowFlight(false);
							
						}
						
					}
					
				}
				
			}
			
		}.runTaskTimer(this, 1, 1);
		
	}
	
	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	public void joinEvent(PlayerJoinEvent e) {
		
		Player player = e.getPlayer();
		
		if(!managers.containsKey(player)) {
			
			managers.put(player, new InventoryManager(player));
			aManagers.put(player, new AttackManager(player, this));
			
		}
		
		if(!player.getInventory().contains(controller())) {
			
			player.getInventory().addItem(controller());
			
		}
		
	}
	
	@EventHandler
	public void pickUpItemEvent(EntityPickupItemEvent e) {
		
		if(e.getEntity() instanceof Player) {
			
			Player player = (Player) e.getEntity();
			
			if(managers.get(player).getInv() == 1) {
				
				Item item = e.getItem();
				
				HashMap<Integer, ItemStack> itemstack = managers.get(player).addToMain(item.getItemStack());
				
				if (itemstack != null) {
					
					if (itemstack.get(0) != null) {
						
						item.setItemStack(itemstack.get(0));
						
					} else {
						
						item.remove();
						
					}
					
				}
				
				e.setCancelled(true);
				
			}
			
		}
		
	}
	
	@EventHandler 
	public void dropEvent(PlayerDropItemEvent e) {
		
		Player player = e.getPlayer();
			
		if(managers.get(player).getInv() == 1) {
				
			e.setCancelled(true);
				
		}
		
	}
	
	@EventHandler 
	public void placeEvent(BlockPlaceEvent e) {
		
		Player player = e.getPlayer();
			
		if(managers.get(player).getInv() == 1) {
				
			e.setCancelled(true);
				
		}
		
		if(e.getPlayer().getInventory().getItemInMainHand().isSimilar(controller())) {
			
			e.setCancelled(true);
			
		}
		
	}
	
	@EventHandler
	public void rightClickEvent(PlayerInteractEvent e) {
		
		Player player = e.getPlayer();
		
		if(e.getAction() == Action.RIGHT_CLICK_AIR) {
		
			if(player.getInventory().getItemInMainHand().isSimilar(controller())) {
			
				managers.get(player).swap();
				player.sendMessage(ChatColor.AQUA + "inventory switched");
			
			}
			
			if(player.getInventory().getItemInMainHand().isSimilar(attack(0))) {
				
				aManagers.get(player).attack(0);
				
			}
		
		}
		
	}
	
	@EventHandler
	public void playerFlyEvent(PlayerToggleFlightEvent e) {
		
		Player player = e.getPlayer();
		
		if(managers.get(player).getInv() == 1) {
			
			e.setCancelled(true);
			player.setAllowFlight(false);
			player.setFallDistance(1);
			
			Vector dir = player.getLocation().getDirection().clone().add(new Vector(0,1,0)).normalize().multiply(2);
			player.setVelocity(dir);
			
			player.getWorld().playSound(player.getLocation(), Sound.ENTITY_IRON_GOLEM_STEP, 1, 1);
			player.getWorld().spawnParticle(Particle.BLOCK_CRACK, player.getLocation(), 50, 2, 0, 2, Material.DIRT.createBlockData());
			
		}
		
	}
	
	public static ItemStack controller() {
		
		ItemStack item = new ItemStack(Material.LIGHTNING_ROD, 1);
		ItemMeta itemmeta = item.getItemMeta();
		
		itemmeta.setDisplayName("Mech Armor");
		
		item.setItemMeta(itemmeta);
		
		return item;
		
	}
	
	public static ItemStack attack(int which) {
		
		ItemStack item = new ItemStack(Material.BEDROCK, 1);
		ItemMeta itemmeta = item.getItemMeta();
		
		switch (which) {
		
		case 0:
			
			item.setType(Material.BLAZE_POWDER);
			itemmeta.setDisplayName(ChatColor.GOLD + "Flamethrower");
		
		}
		
		item.setItemMeta(itemmeta);
		
		return item;
		
	}

}
