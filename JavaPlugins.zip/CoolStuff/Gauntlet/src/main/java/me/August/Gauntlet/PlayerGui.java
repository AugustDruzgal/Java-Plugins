package me.August.Gauntlet;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class PlayerGui {
	
	Player player;
	boolean activeState = false;
	GuiSet currentSet = null;
	GuiItem previousGuiItem = null;
	ItemStack[] savedHotbar;
	int currentSetNum = 0;
	
	public PlayerGui(Player player)
	{
		this.player = player;
		savedHotbar = getCurrentHotbar();
	}
	
	public void toggleGuiSet(GuiSet newSet, int num)
	{
		player.sendMessage("Active state: " + activeState);
		if (activeState)
		{
			restore();
			return;
		}
		
		currentSetNum = num;
		activeState = true;
		savedHotbar = getCurrentHotbar();
		setHotbar(newSet.getAsItemStackArray(player));
		player.getInventory().setHeldItemSlot(8);
		player.getInventory().setItem(8, newSet.getParentGuiItem().getAsItemStack());
		currentSet = newSet;
	}
	
	public void switchToGuiSet(GuiSet newSet, int num)
	{
		if (!activeState)
			toggleGuiSet(newSet, num);
		
		currentSetNum = num;
		currentSet = newSet;
		setHotbar(newSet.getAsItemStackArray(player));
		player.getInventory().setHeldItemSlot(8);
		player.getInventory().setItem(8, newSet.getParentGuiItem().getAsItemStack());
	}
	
	public void refresh()
	{
		if (!activeState)
			return;
		setHotbar(currentSet.getAsItemStackArray(player));
		player.getInventory().setHeldItemSlot(8);
		player.getInventory().setItem(8, currentSet.getParentGuiItem().getAsItemStack());
	}
	
	public void restore()
	{
		if (!activeState)
			return;
		
		previousGuiItem = currentSet.getParentGuiItem();
		activeState = false;
		setHotbar(this.savedHotbar);
		currentSet = null;
	}
	
	private void setHotbar(ItemStack[] newHotbar)
	{
		Inventory inventory = this.player.getInventory();
		for (int i = 0; i < 9; i++)
		{
			inventory.setItem(i, newHotbar[i]);
		}
	}
	
	private ItemStack[] getCurrentHotbar()
	{
		ItemStack[] currentHotbar = new ItemStack[9];
		Inventory inventory = player.getInventory();
		for (int i = 0; i < 9; i++)
			currentHotbar[i] = (inventory.getItem(i) != null) ? inventory.getItem(i).clone() : null;
		return currentHotbar;
	}
	
	public boolean getActiveState()
	{
		return this.activeState;
	}
	
	public void setActiveState(boolean activeState)
	{
		this.activeState = activeState;
	}
	
	public GuiItem getPreviousGuiItem()
	{
		return previousGuiItem;
	}
	
	public GuiSet getCurrentSet()
	{
		return currentSet;
	}
	
	public int getCurrentSetNum()
	{
		return currentSetNum;
	}

}
