package me.August.Abilities.Util;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class PassiveSkill {

	protected boolean active = false;
	boolean manual;
	protected Player player;
	protected Plugin plugin;
	int cooldown = 0;
	
	protected PassiveSkill(Player p, Plugin pl) {
		player = p;
		plugin = pl;
	}
	
	public void effect(int level)
	{
		
	}
	
	public void passive(int level)
	{
		if (active)
			effect(level);
	}

	public void toggle()
	{
		active = !active;
	}
	
	public void startCooldown(int ticks, boolean show)
	{
		cooldown = ticks;
		new BukkitRunnable()
		{
			int max = ticks;
			@Override
			public void run()
			{
				cooldown--;
				if (cooldown == 0)
				{
					cancel();
				}
				else
				{
					if (show)
					{
						displayCooldownBar(cooldown, max);
					}
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public void displayCooldownBar(long ticks, long max)
	{
		long counter = ticks;
		TextComponent component = Component.text("Cooldown : ").color(TextColor.color(255, 255, 255));
		for (int i = 0; i < 40; i++)
		{
			counter = counter - (max / 40);
			if (counter <= 0)
				component = component.append(Component.text("|").color(TextColor.color(20, 255, 50)));
			else
				component = component.append(Component.text("|").color(TextColor.color(255, 20, 20)));
		}
		component = component.append(Component.text(" - ").color(TextColor.color(255, 255, 255)));
		component = component.append(Component.text(ticks/20 + "." + ((ticks/2)%10)).color(TextColor.color(255, 255, 255)));
		component = component.append(Component.text("s").color(TextColor.color(255, 255, 255)));
		player.sendActionBar(component);
	}
	
	protected int getCooldown()
	{
		return cooldown;
	}
}
