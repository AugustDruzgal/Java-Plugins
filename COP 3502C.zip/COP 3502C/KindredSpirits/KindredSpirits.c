// August Druzgal
// COP 3502, Spring 2022
#include <stdio.h>
#include <stdlib.h>
#include "KindredSpirits.h"

// Queue structure definitions
typedef struct queue_node
{
	int data;
	struct queue_node *next;
} queue_node;

typedef struct queue
{
	int length;
	queue_node *head;
	queue_node *tail;
} queue;

// Function prototypes for all helper functions
int isReflectionHelper(node *a, node *b);

node *makeReflectionHelper(node *root);

queue *preorder(node *root);

void preorderHelper(node *root, queue *q);

queue *postorder(node *root);

void postorderHelper(node *root, queue *q);

queue *createQueue();

queue *destroyQueue(queue *q);

queue *enqueue(queue *q, int value);

int dequeue(queue *q);

queue_node *createQueueNode(int value);

int queueCompare(queue *a, queue *b);

void printQueue(queue *q);

// This function compares the contents of two binary trees to determine if they are reflections of
// each other
int isReflection(node *a, node *b)
{
	return 1 - isReflectionHelper(a, b);
}
// This function recursively compares each reflective node in two binary trees
int isReflectionHelper(node *a, node *b)
{
	if (a == NULL && b == NULL)
		return 0;
	if (a == NULL || b == NULL)
		return 1;
	if (a->data == b->data)
		return isReflectionHelper(a->right, b->left) + isReflectionHelper(a->left, b->right);
	return 1;
}

// This function creates and returns a reflection of the passed tree
node *makeReflection(node *root)
{
	return makeReflectionHelper(root);
}

// This function recursively creates a new node for each node in the passed binary tree
node *makeReflectionHelper(node *root)
{
	node *new = NULL;
	
	if (root == NULL)
		return new;
	
	new = malloc(sizeof(node));
	new->data = root->data;
	new->left = makeReflectionHelper(root->right);
	new->right = makeReflectionHelper(root->left);
	return new;
}

// This function compares the preorder traversal of a with the postorder traversal of b, and vice
// versa. If either are the same, they are "kindred spirits", and it returns 1, and 0 if not
int kindredSpirits(node *a, node *b)
{
	int compare = 0;
	
	// compare preorder of a with postorder of b
	queue *preorder_queue = preorder(a);
	queue *postorder_queue = postorder(b);
	
	if (queueCompare(preorder_queue, postorder_queue))
		compare = 1;
	
	destroyQueue(preorder_queue);
	destroyQueue(postorder_queue);
	
	// compare preorder of b with postorder of a
	preorder_queue = preorder(b);
	postorder_queue = postorder(a);
	
	if (queueCompare(preorder_queue, postorder_queue))
		compare = 1;
	
	destroyQueue(preorder_queue);
	destroyQueue(postorder_queue);
	
	return compare;
}

// This function creates a queue representing the preorder traversal of a binary tree
queue *preorder(node *root)
{
	if (root == NULL)
		return NULL;
	
	queue *order = createQueue();
	preorderHelper(root, order);
	return order;
}

// This function traverses a tree recursively and enqueues values in preorder
void preorderHelper(node *root, queue *q)
{
	if (root == NULL)
		return;
	
	enqueue(q, root->data);
	preorderHelper(root->left, q);
	preorderHelper(root->right, q);
}

// This function creates a queue representing the postorder traversal of a binary tree
queue *postorder(node *root)
{
	if (root == NULL)
		return NULL;
	queue *order = createQueue();
	postorderHelper(root, order);
	return order;
}

// This function traverses a tree recursively and enqueues values in postorder
void postorderHelper(node *root, queue *q)
{
	if (root == NULL)
		return;
	postorderHelper(root->left, q);
	postorderHelper(root->right, q);
	enqueue(q, root->data);
}

// This function appends a value to the end of a queue
queue *enqueue(queue *q, int value)
{
	if (q->length == 0)
	{
		q->head = createQueueNode(value);
		q->tail = q->head;
		q->length++;
	}
	else
	{
		q->tail->next = createQueueNode(value);
		q->tail = q->tail->next;
		q->length++;
	}
	return q;
}

// This function removes the value at the head of a queue and returns it
int dequeue(queue *q)
{
	int value;
	queue_node *q_node;
	
	if (q == NULL || q->length == 0)
		return -1;
	
	q_node = q->head;
	value = q_node->data;
	q->head = q->head->next;
	free(q_node);
	q->length--;
	
	if (q->length == 0)
		q->tail = NULL;
	return value;
}

// This function creates an empty queue
queue *createQueue()
{
	queue *q = malloc(sizeof(queue));
	q->length = 0;
	q->head = NULL;
	q->tail = NULL;
	return q;
}

// This function deallocates a queue and all allocated queue nodes within it
queue *destroyQueue(queue *q)
{
	if (q == NULL)
		return NULL;
	while (q->length > 0)
		dequeue(q);
	free(q);
	return NULL;
}

// This function creates a queue node and stores the passed value within it
queue_node *createQueueNode(int value)
{
	queue_node *q_node = malloc(sizeof(queue_node));
	q_node->data = value;
	q_node->next = NULL;
	return q_node;
}

// This function compares the contents of two queues and returns 1 if they are the same, 0 if not
int queueCompare(queue *a, queue *b)
{
	queue_node *node_a, *node_b;
	
	if (a == NULL && b == NULL)
		return 1;
	if (a == NULL || b == NULL)
		return 0;
	if (a->length != b->length)
		return 0;
	
	node_a = a->head;
	node_b = b->head;
	
	// loop through each node in both queues and compare each value
	while (node_a != NULL)
	{
		if (node_a->data != node_b->data)
			return 0;
		node_a = node_a->next;
		node_b = node_b->next;
	}
	return 1;
}

// For debugging purposes, this function prints the contents and length of a queue
void printQueue(queue *q)
{
	if (q == NULL)
		return;
	queue_node *q_node = q->head;
	printf("<head> -> ");
	while (q_node != NULL)
	{
		printf("%d -> ", q_node->data);
		q_node = q_node->next;
	}
	printf("tail | length = %d\n", q->length);
}

// This function returns my difficulty rating of this project
double difficultyRating(void)
{
	return 3;
}

// This function returns an estimation of my hours spent on this project
double hoursSpent(void)
{
	return 2;
}