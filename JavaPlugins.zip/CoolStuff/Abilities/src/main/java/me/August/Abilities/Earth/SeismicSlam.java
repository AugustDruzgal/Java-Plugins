package me.August.Abilities.Earth;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;

public class SeismicSlam extends Skill {

	public SeismicSlam(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		Vector vel = new Vector(0, 1.5, 0).add(player.getLocation().getDirection().clone().setY(0).normalize().multiply(0.5));
		player.setVelocity(vel);
		
		new BukkitRunnable()
		{
			int time = 0;
			@Override
			public void run()
			{
				time++;
				player.setFallDistance(0);
				if (time > 10 && isOnGround(player.getLocation()))
				{
					hit(player.getLocation());
					player.getWorld().spawnParticle(Particle.BLOCK_CRACK, player.getLocation().clone().add(new Vector(0, 0.2, 0)), 200, 3, 0, 3, 1, Material.DIRT.createBlockData(), true);
					player.damage(0.1);
					time = 100;
				}
				if (time > 60)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public boolean isOnGround(Location loc)
	{
		if (!loc.clone().add(new Vector(0, -0.2, 0)).getBlock().isPassable())
			return true;
		return false;
	}
	
	public void hit(Location loc)
	{
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getLocation().distance(loc) < 3)
			{
				entity.damage(6);
				entity.setVelocity(entity.getLocation().clone().subtract(loc).toVector().normalize().add(new Vector(0, 0.5, 0).normalize().multiply(0.8)));
			}
		}
	}

}
