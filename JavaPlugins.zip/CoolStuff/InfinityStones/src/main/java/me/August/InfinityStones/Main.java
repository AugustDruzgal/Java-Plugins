package me.August.InfinityStones;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	ArrayList<Stone> stones = new ArrayList<Stone>();
	
	@Override
	public void onEnable()
	{
		Bukkit.getPluginManager().registerEvents(this, this);
		stones.add(new PowerStone(this));
		stones.add(new SpaceStone(this));
		stones.add(new RealityStone(this));
		stones.add(new TimeStone(this));
		stones.add(new MindStone(this));
		stones.add(new SoulStone(this));
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				for (Stone stone:stones)
				{
					stone.passive();
					stone.particle();
				}
			}
		}.runTaskTimer(this, 0, 1);
	}
	
	@Override
	public void onDisable()
	{
		
	}
	
	@EventHandler
	public void onRightClick(PlayerInteractEvent e)
	{
		Player player = e.getPlayer();
		if (e.getAction() == Action.RIGHT_CLICK_AIR)
		{
			if (isHoldingAnyStoneInMain(player))
			{
				for (Stone stone:stones)
				{
					if (player == stone.getOwner() && stone.isHoldingInMain())
					{
						stone.active();
						return;
					}
				}
			}
			else
			{
				for (Stone stone:stones)
				{
					if (player == stone.getOwner() && stone.isHoldingInOff())
					{
						stone.active();
						return;
					}
				}
			}
		}
	}
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent e)
	{
		ItemStack item = e.getItemDrop().getItemStack();
		for (Stone stone:stones)
		{
			if (stone.isItem(item))
			{
				if (stone.getOwner() == e.getPlayer())
					e.getPlayer().sendMessage("You have lost the " + stone.getName() + ".");
				stone.setOwner(null);
			}
		}
	}
	
	@EventHandler
	public void onHit(EntityDamageByEntityEvent e)
	{
		Entity entity = e.getDamager();
		PowerStone stone = (PowerStone) stones.get(0);
		if (entity instanceof LivingEntity && stone.getOwner() == entity && stone.isActive() && stone.isHoldingInMain())
		{
			stone.active = 0;
			entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1F, 2F);
			entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1F, 2F);
			e.getEntity().setVelocity(entity.getLocation().getDirection().clone().setY(0).normalize().multiply(5.5).add(new Vector(0, 1, 0)));
			e.setCancelled(true);
			((LivingEntity) e.getEntity()).damage(e.getDamage());
			new BukkitRunnable()
			{
				int timer = 0;
				DustOptions dust = new DustOptions(Color.PURPLE, 1F);
				@Override
				public void run()
				{
					timer++;
					entity.getWorld().spawnParticle(Particle.REDSTONE, e.getEntity().getLocation().clone().add(new Vector(0, 0.8, 0)), 20, 0.5, 0.5, 0.5, 0, dust, true);
					if (timer > 25)
						cancel();
				}
			}.runTaskTimer(this, 0, 1);
		}
	}
	
	@EventHandler
	public void onPickup(EntityPickupItemEvent e)
	{
		LivingEntity entity = e.getEntity();
		ItemStack item = e.getItem().getItemStack();
		for (Stone stone:stones)
		{
			entity.sendMessage("bruh");
			if(stone.isItem(item))
			{
				if (entity instanceof Player && stone.getOwner() == null)
				{
					stone.setOwner((Player) entity);
					entity.sendMessage("You now own the " + stone.getName() + ".");
				}
				else
				{
					e.setCancelled(true);
					return;
				}
			}
		}
	}
	
	@EventHandler 
	public void onTarget(EntityTargetLivingEntityEvent e)
	{
		if (e.getTarget() == stones.get(4).getOwner() && stones.get(4).isHolding())
		{
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onLogin(PlayerJoinEvent e)
	{
		for (Stone stone:stones)
			e.getPlayer().getInventory().addItem(stone.createItem());
	}
	
	public boolean isHoldingAnyStoneInMain(Player player)
	{
		for (Stone stone:stones)
		{
			if (stone.getOwner() == player && stone.isHoldingInMain())
			{
				return true;
			}
		}
		return false;
	}
}
