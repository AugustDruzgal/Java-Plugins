package me.August.Abilities.Earth;

import java.util.ArrayList;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import me.August.TemporaryBlocks.TemporaryBlockManager;

public class AxeEarth extends Skill {
	
	ArrayList<Location> used = new ArrayList<>();
	
	public AxeEarth(Player p, Plugin pl)
	{
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		new BukkitRunnable()
		{
			int time = 0;
			Vector dir = player.getLocation().getDirection().clone().setY(0).normalize();
			Location loc = player.getLocation().clone();
			
			@Override
			public void run()
			{
				
				if (loc == null)
					time = 200;
				else if (time%1 == 0)
				{
					loc.add(dir);
					loc = getLowestAir(loc);
					if (time < 3)
						earthSpike(loc, loc.clone().add(new Vector(0, -1, 0)).getBlock().getType(), 1, time);
					else if (time < 7)
						earthSpike(loc, loc.clone().add(new Vector(0, -1, 0)).getBlock().getType(), 2, time);
					else
						earthSpike(loc, loc.clone().add(new Vector(0, -1, 0)).getBlock().getType(), 3, time);
				}
				time++;
				if (time > 30)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private Location getLowestAir(Location loc)
	{
		Location location = loc.clone().add(new Vector(0, 2, 0));
		for (int i = 0; i < 5; i++)
		{
			location.add(new Vector(0, -1, 0));
			if (!location.getBlock().isPassable())
			{
				return location.clone().add(new Vector(0, 1, 0));
			}
		}
		
		return null;
	}
	
	private void earthSpike(Location loc, Material type, int height, int distance)
	{
		Location location = loc.toBlockLocation();
		Location l = location.clone();
		l.setY(0);
		if (used.contains(l))
			return;
		used.add(l);
		burst(location, distance);
		new BukkitRunnable()
		{
			int time = 0;
			
			@Override
			public void run()
			{
				TemporaryBlockManager.createTemporaryBlock(location.clone().add(new Vector(0, time, 0)), Material.STONE, (int) (distance * 2 + 140 - 20 * time - Math.round(Math.random() * 2)), plugin);
				time++;
				if (time > height - 1)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	private void burst(Location loc, int distance)
	{
		loc.getWorld().playSound(loc, Sound.BLOCK_GRAVEL_BREAK, 1F, 1F);
		loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 30, 0.8, 0.3, 0.8, 1, Material.STONE.createBlockData(), true);
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && loc.distance(entity.getLocation()) < 1.5)
			{
				entity.setVelocity(loc.clone().subtract(entity.getLocation()).toVector().normalize().add(new Vector(0, -0.7, 0)).multiply(-1.2 - distance/30));
				entity.damage(2 + distance/3);
			}
		}
	}
}
