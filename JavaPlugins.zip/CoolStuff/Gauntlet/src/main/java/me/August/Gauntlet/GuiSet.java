package me.August.Gauntlet;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GuiSet {
	
	GuiItem parentGuiItem;
	
	GuiSlot[] guiSlots = {null, null, null, null, null, null, null, null, null};
	
	public GuiSet(GuiItem parentGuiItem)
	{
		this.parentGuiItem = parentGuiItem;
	}
	
	public void activateSlot(int slot, Player player)
	{
		if (slot > 8 || slot < 0 || guiSlots[slot] == null)
			return;
		guiSlots[slot].getGuiAction().action(player);
	}
	
	public void setSlot(int slot, GuiSlot guiSlot)
	{
		if (slot >= guiSlots.length)
			return;
		guiSlots[slot] = guiSlot;
	}
	
	public GuiItem getParentGuiItem()
	{
		return this.parentGuiItem;
	}
	
	public GuiSlot getSlot(int slot)
	{
		return guiSlots[slot];
	}
	
	public ItemStack[] getAsItemStackArray(Player player)
	{
		ItemStack[] items = new ItemStack[9];
		for (int i = 0; i < 9; i++)
		{
			items[i] = (guiSlots[i] != null) ? guiSlots[i]
					.getGuiDisplayItem().getAsItemStack(player, guiSlots[i].getGuiCooldown().getCooldown()) : null;
		}
		return items;
	}
	
	public GuiSlot[] getSlots()
	{
		return guiSlots;
	}
	
	public void setSlots(GuiSlot[] guiSlots)
	{
		this.guiSlots = guiSlots;
	}
	
	public void updateCooldown()
	{
		for (int i = 0; i < 9; i++)
		{
			if (guiSlots[i] != null) guiSlots[i].updateCooldown();
		}
	}
	
	public GuiSet clone()
	{
		GuiSet copyset = new GuiSet(parentGuiItem);
		GuiSlot[] copyslots = new GuiSlot[9];
		for (int i = 0; i < 9; i++)
		{
			copyslots[i] = this.guiSlots[i] != null ? this.guiSlots[i].clone() : null;
		}
		copyset.setSlots(copyslots);
		return copyset;
	}

}
