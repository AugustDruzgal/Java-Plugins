package me.August.InfinityStones;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.bukkit.plugin.Plugin;

public class LogFileManager {

	public static void logToFile(Plugin plugin, String str)
	{
		try
		{
			File datafolder = plugin.getDataFolder();
			if (!datafolder.exists())
			{
				datafolder.mkdir();
			}
			File savefile = new File(plugin.getDataFolder(), "data.txt");
			if (!savefile.exists())
			{
				savefile.createNewFile();
			}
			FileWriter fw = new FileWriter(savefile, true);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(str);
			pw.close();
			fw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void readFromFile(Plugin plugin)
	{
		try
		{
			File datafolder = plugin.getDataFolder();
			if (!datafolder.exists())
			{
				datafolder.mkdir();
			}
			File savefile = new File(plugin.getDataFolder(), "data.txt");
			if (!savefile.exists())
			{
				savefile.createNewFile();
			}
			FileWriter fw = new FileWriter(savefile, true);
			PrintWriter pw = new PrintWriter(fw);
		//	pw.println(str);
			pw.close();
			fw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
