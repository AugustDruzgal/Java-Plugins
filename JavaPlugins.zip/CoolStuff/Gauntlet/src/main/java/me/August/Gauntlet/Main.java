package me.August.Gauntlet;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class Main extends JavaPlugin {
	
	@Override
	public void onEnable()
	{
		Bukkit.getPluginManager().registerEvents(new EventListener(), this);
		
		PlayerGuiManager.initPlayerGuis();
		
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				GuiItemManager.updateCooldowns();
				PlayerGuiManager.updateGuis();
			}
		}.runTaskTimer(this, 0, 1);
		
		GuiItem guiItem = new GuiItem();
		guiItem.setCustomModelData(2);
		guiItem.setItemName("Dummy GUI item");
		guiItem.setItemNameColor(255, 200, 50);
		guiItem.setItemType(Material.COAL);
		

		GuiItem guiItem2 = new GuiItem();
		guiItem2.setCustomModelData(2);
		guiItem2.setItemName("Dummy2 GUI item");
		guiItem2.setItemNameColor(255, 100, 10);
		guiItem2.setItemType(Material.BLAZE_POWDER);
		
		GuiDisplayItem guiDisplayItem = new GuiDisplayItem(); // <======
		GuiDisplayItem guiDisplayItem2 = new GuiDisplayItem();
		GuiAction guiAction = new GuiAction()
		{
			@Override
			void action(Player player) {
				player.sendMessage("action activated!");
			}
		};
		
		GuiAction guiAction2 = new GuiAction()
		{
			@Override
			void action(Player player) {
				player.sendMessage("action 2 activated!");
			}
		};
		
		
		GuiSlot guiSlot = new GuiSlot(guiDisplayItem, guiAction, new GuiCooldown(100));
		GuiSlot guiSlot2 = new GuiSlot(guiDisplayItem2, guiAction2, new GuiCooldown(100));
		
		GuiSet[] guiSet = {new GuiSet(guiItem), new GuiSet(guiItem)};
		guiSet[0].setSlot(0, guiSlot);
		guiSet[1].setSlot(2, guiSlot2);
		
		guiItem.setGuiSets(guiSet);
		GuiItemManager.addGuiItem(guiItem, "dummy");
		
		GuiSet[] guiSet2 = {new GuiSet(guiItem2)};
		guiSet2[0].setSlot(5, guiSlot2);
		
		guiItem2.setGuiSets(guiSet2);
		GuiItemManager.addGuiItem(guiItem2, "dummy2");
		
		for (Player player:Bukkit.getOnlinePlayers())
		{
			GuiItemManager.initPlayer(player);
		}
	}
	
	@Override
	public void onDisable()
	{
		for (Player player:Bukkit.getOnlinePlayers()) 
		{
			PlayerGuiManager.getPlayerGui(player).restore();
		}
	}
}

