package me.August.Gauntlet;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GuiItemManager {
	
	static HashMap<Player, PlayerItemInfo> playerItemInfo = new HashMap<>();
	static ArrayList<GuiItem> guiItemList = new ArrayList<>();
	static HashMap<ItemStack, GuiItem> guiItemMap = new HashMap<>();
	static HashMap<String, GuiItem> guiIdItemMap = new HashMap<>();
	static HashMap<GuiItem, String> guiItemIdMap = new HashMap<>();
	
	public static void initPlayer(Player player)
	{
		playerItemInfo.put(player, new PlayerItemInfo());
		for (GuiItem item:guiItemList)
		{
			playerItemInfo.get(player).addPlayerItem(item.clone(), guiItemIdMap.get(item));
		}
	}
	
	public static void addGuiItem(GuiItem item, String id)
	{
		guiItemList.add(item);
		guiItemMap.put(item.getAsItemStack(), item);
		guiItemIdMap.put(item, id);
		guiIdItemMap.put(id, item);
	}
	
	public static GuiItem getGuiItem(String id)
	{
		return guiIdItemMap.get(id);
	}
	
	public static GuiItem getGuiItem(ItemStack item)
	{
		return guiItemMap.get(item);
	}
	
	public static PlayerItemInfo getInfo(Player player)
	{
		return playerItemInfo.get(player);
	}
	
	public static boolean isGuiItem(ItemStack item)
	{
		return guiItemMap.containsKey(item.asOne());
	}
	
	public static void updateCooldowns()
	{
		for (Player player:Bukkit.getOnlinePlayers())
		{
			playerItemInfo.get(player).updateCooldowns();
		}
	}
	
}
