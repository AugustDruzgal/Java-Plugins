package me.August.Abilities;

import java.util.HashMap;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import me.August.Abilities.Earth.Earthquake;
import me.August.Abilities.Earth.Rupture;
import me.August.Abilities.Earth.SeismicSlam;
import me.August.Abilities.Fire.FireBall;
import me.August.Abilities.Fire.FireBolt;
import me.August.Abilities.Fire.Immolate;
import me.August.Abilities.Ice.Blizzard;
import me.August.Abilities.Ice.FrostBolt;
import me.August.Abilities.Ice.IcePrison;
import me.August.Abilities.Storm.LightningBolt;
import me.August.Abilities.Storm.LightningOrb;
import me.August.Abilities.Storm.SuperCharge;
import me.August.Abilities.Util.PassiveSkill;
import me.August.Abilities.Util.Skill;
import me.August.Abilities.Wind.Leap;
import me.August.Abilities.Wind.SwordThrow;
import me.August.Abilities.Wind.WindSlash;

public class SkillManager {

	Player player;
	Plugin plugin;
	HashMap<String, AbilitySet> abilitysets;
	HashMap<Material, Boolean> swords;
	HashMap<Material, Boolean> axes;
	String current = "ice";
	Skill sword = null;
	int swordlevel = 5;
	Skill axe = null;
	int axelevel = 5;
	PassiveSkill passive = null;
	int passivelevel = 5;
	int bonuslevel = 0;
	String statusskill = "FreezingBlade";
	
	SkillManager(Player player)
	{
		this.player = player;
		plugin = Main.getPlugin();
		abilitysets = getSets();
		sword = abilitysets.get("ice").getSword();
		axe = abilitysets.get("ice").getAxe();
	}
	
	public void ActivateAbility(String str)
	{
		if (str == "sword" && sword != null)
		{
			sword.activate(swordlevel + bonuslevel);
			return;
		}
		if (str == "axe" && axe != null)
		{
			axe.activate(swordlevel + bonuslevel);
			return;
		}
	}
	
	public void setSword(Skill skill)
	{
		sword = skill;
		player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1F, 1F);
	}
	
	public void setAxe(Skill skill)
	{
		axe = skill;
		player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1F, 1F);
	}
	
	public void setBow(Skill skill)
	{
		player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1F, 1F);
	}
	
	public void setClass(String str)
	{
		AbilitySet set = abilitysets.get(str);
		if (set != null)
		{
			current = str;
			sword = abilitysets.get(str).getSword();
			axe = abilitysets.get(str).getAxe();
			passive = abilitysets.get(str).getPassive();
		}
	}
	
	public AbilitySet getSet(String str)
	{
		return abilitysets.get(str);
	}
	
	public String getCurrent()
	{
		return current;
	}
	
	public boolean isHoldingWeapon()
	{
		Material item = player.getInventory().getItemInMainHand().getType();
		return (swords.get(item) || axes.get(item));
	}
	
	public void runPassive()
	{
		if (passive != null)
		{
			passive.passive(passivelevel);
		}
	}
	
	public PassiveSkill getPassive()
	{
		return passive;
	}
	
	public void togglePassive()
	{
		passive.toggle();
	}
	
	public void setBonusLevel(int amount)
	{
		bonuslevel = amount;
	}
	
	public String getStatusSkill()
	{
		return statusskill;
	}
	
	private HashMap<String, AbilitySet> getSets()
	{
		HashMap<String, AbilitySet> sets = new HashMap<>();
		
		sets.put("air", new AbilitySet(new SwordThrow(player, plugin), new WindSlash(player, plugin), new Leap(player, plugin)));
		sets.put("storm", new AbilitySet(new LightningBolt(player, plugin), new LightningOrb(player, plugin), new SuperCharge(player, plugin)));
		sets.put("fire", new AbilitySet(new FireBolt(player, plugin), new FireBall(player, plugin), new Immolate(player, plugin)));
		sets.put("earth", new AbilitySet(new Rupture(player, plugin), new SeismicSlam(player, plugin), new Earthquake(player, plugin)));
		sets.put("ice", new AbilitySet(new FrostBolt(player, plugin), new IcePrison(player, plugin), new Blizzard(player, plugin)));
		
		return sets;
	}

	public void setLevels(int newlevel) 
	{
		swordlevel = newlevel;
		axelevel = newlevel;
		passivelevel = newlevel;
	}
}
