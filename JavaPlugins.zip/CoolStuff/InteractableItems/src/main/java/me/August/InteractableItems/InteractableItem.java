package me.August.InteractableItems;

import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class InteractableItem {
	
	ItemStack item;
	
	public InteractableItem()
	{
		
	}
	
	public void setItem(ItemStack i)
	{
		item = i;
	}
	
	public void effect(Player player)
	{
		player.sendMessage("this item has been used!");
	}
	
	public void registerInteractType(EquipmentSlot hand, Action interact)
	{
		Main.items.get(hand).get(interact).add(this);
	}
	
	public void removeInteractType(EquipmentSlot hand, Action interact)
	{
		Main.items.get(hand).get(interact).remove(this);
	}
	
	public boolean isAcceptable(ItemStack clickedItem)
	{
		boolean acceptable = true;
		
		if (!clickedItem.isSimilar(item))
			acceptable = false;
		
		return acceptable;
	}

}
