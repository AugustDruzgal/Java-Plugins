package me.August.InfinityStones;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public interface Utils {
	
	public static boolean targetLocationAttack(Player player, int range, PowerEffect effect)
	{
		Block block = player.getTargetBlock(range);
		Location loc;
		if (block == null || block.getType().isAir())
			return false;
		loc = block.getLocation().toCenterLocation().add(new Vector(0, 0.6, 0));
		return effect.effect(player, loc, null);
	}
	
	public static boolean targetEntityFrontAttack(Player player, int range, PowerEffect effect)
	{
		Location loc = player.getLocation().clone();
		Vector dir = loc.getDirection().clone();
		Vector dif = null;
		double angle;
		double dist = range;
		LivingEntity target = null;
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			dif = entity.getLocation().subtract(loc).toVector();
			if (dif.length() > dist)
				continue;
			angle = dif.angle(dir);
			if (angle > Math.PI * 0.5)
				continue;
			dist = dif.length();
			target = entity;
		}
		if (target == null)
			return false;
		return effect.effect(player, null, target);
	}
	
	public static boolean targetEntityTypeFrontAttack(Player player, EntityType type, int range, PowerEffect effect)
	{
		Location loc = player.getLocation().clone();
		Vector dir = loc.getDirection().clone();
		Vector dif = null;
		double angle;
		double dist = range;
		LivingEntity target = null;
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity.getType() != type)
				continue;
			dif = entity.getLocation().subtract(loc).toVector();
			if (dif.length() > dist)
				continue;
			angle = dif.angle(dir);
			if (angle > Math.PI * 0.5)
				continue;
			dist = dif.length();
			target = entity;
		}
		if (target == null)
			return false;
		return effect.effect(player, null, target);
	}
	
	public static boolean allEntityFrontAttack(Player player, int range, PowerEffect effect)
	{
		Location loc = player.getLocation().clone();
		Vector dir = loc.getDirection().clone();
		Vector dif = null;
		double angle;
		ArrayList<LivingEntity> targets = new ArrayList<>();
		boolean active = false;
		
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			dif = entity.getLocation().subtract(loc).toVector();
			if (dif.length() > range)
				continue;
			angle = dif.angle(dir);
			if (angle > Math.PI * 0.5)
				continue;
			targets.add(entity);
		}
		if (targets.size() == 0)
			return false;
		for (LivingEntity entity:targets)
		{
			active |= effect.effect(player, null, entity);
		}
		return active;
	}
	
	public static void particleSwirl(Entity entity, Particle particle, Plugin plugin)
	{
		new BukkitRunnable()
		{
			Vector offset = new Vector(1, 0, 0);
			Location loc;
			int time = 0;
			@Override
			public void run()
			{
				for (int i = 0; i < 10; i++)
				{
					offset.normalize().multiply(0.5 + 0.5 * Math.sin(Math.PI * (time * 0.1 + i * 0.01)));
					offset.rotateAroundY(Math.PI/15);
					loc = entity.getLocation().clone();
					loc.add(offset);
					loc.setY(loc.getY() + entity.getHeight() * (time * 0.1 + i * 0.01));
					entity.getWorld().spawnParticle(particle, loc, 1, 0, 0, 0, 0, null, true);
				}
				
				
				time++;
				if (time > 10)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public static void particleSwirl(Entity entity, Particle particle, Plugin plugin, Object data)
	{
		new BukkitRunnable()
		{
			Vector offset = new Vector(1, 0, 0);
			Location loc;
			int time = 0;
			@Override
			public void run()
			{
				for (int i = 0; i < 10; i++)
				{
					offset.normalize().multiply(0.5 + 0.5 * Math.sin(Math.PI * (time * 0.1 + i * 0.01)));
					offset.rotateAroundY(Math.PI/15);
					loc = entity.getLocation().clone();
					loc.add(offset);
					loc.setY(loc.getY() + entity.getHeight() * (time * 0.1 + i * 0.01));
					entity.getWorld().spawnParticle(particle, loc, 1, 0, 0, 0, 0, data, true);
				}
				
				
				time++;
				if (time > 10)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	public static void particleSphere(Particle particle, Location loc, double radius, int count)
	{
		Vector offset;
		Random random = new Random();
		for (int i = 0; i < count; i++)
		{
			offset = new Vector(0, radius, 0).rotateAroundX(random.nextDouble() * Math.PI * 2)
											.rotateAroundZ(random.nextDouble() * Math.PI * 2)
											.rotateAroundY(random.nextDouble() * Math.PI * 2);
			loc.getWorld().spawnParticle(particle, loc.clone().add(offset), 1, 0, 0, 0, 0, null, true);
		}
	}
	
	public static void particleSphere(Particle particle, Location loc, double radius, int count, Object data)
	{
		Vector offset;
		Random random = new Random();
		for (int i = 0; i < count; i++)
		{
			offset = new Vector(0, radius, 0).rotateAroundX(random.nextDouble() * Math.PI * 2)
											.rotateAroundZ(random.nextDouble() * Math.PI * 2)
											.rotateAroundY(random.nextDouble() * Math.PI * 2);
			loc.getWorld().spawnParticle(particle, loc.clone().add(offset), 1, 0, 0, 0, 0, data, true);
		}
	}
	
	public static void particleSpiral(Particle particle, Location loc, Vector dir, double length, Object data)
	{
		Location pos = loc.clone();
		Location temp;
		Vector inc = dir.clone().normalize().multiply(0.05);
		Vector offset = dir.clone().normalize().setY(0).normalize().rotateAroundY(Math.PI/2);
		double width = 0.1;
		
		for (int i = 0; i < length * 20; i++)
		{
			offset.rotateAroundAxis(dir, Math.PI/20);
			width += 0.04;
			pos.add(inc);
			temp = pos.clone().add(offset.clone().normalize().multiply(width));
			loc.getWorld().spawnParticle(particle, temp, 1, 0, 0, 0, 0, data, true);
		}
	}
	
	public static void particleBlockSurface(Particle particle, Location loc, int count)
	{
		Location blockloc = loc.toBlockLocation().subtract(new Vector(0.5, 0.5, 0.5)), temp;
		temp = blockloc.clone().add(new Vector(0, 0.56, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0, 0.5, 0, null, true);
		temp = blockloc.clone().add(new Vector(0, -0.56, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0, 0.5, 0, null, true);
		temp = blockloc.clone().add(new Vector(0.56, 0, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0, 0.5, 0.5, 0, null, true);
		temp = blockloc.clone().add(new Vector(-0.56, 0, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0, 0.5, 0.5, 0, null, true);
		temp = blockloc.clone().add(new Vector(0, 0, 0.56));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0.5, 0, 0, null, true);
		temp = blockloc.clone().add(new Vector(0, 0, -0.56));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0.5, 0, 0, null, true);
	}
	
	public static void particleBlockSurface(Particle particle, Location loc, int count, Object data)
	{
		Location blockloc = loc.toBlockLocation(), temp;
		temp = blockloc.clone().add(new Vector(0, 0.5, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0, 0.5, 0, data, true);
		temp = blockloc.clone().add(new Vector(0, -0.5, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0, 0.5, 0, data, true);
		temp = blockloc.clone().add(new Vector(0.5, 0, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0, 0.5, 0.5, 0, data, true);
		temp = blockloc.clone().add(new Vector(-0.5, 0, 0));
		loc.getWorld().spawnParticle(particle, temp, count, 0, 0.5, 0.5, 0, data, true);
		temp = blockloc.clone().add(new Vector(0, 0, 0.5));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0.5, 0, 0, data, true);
		temp = blockloc.clone().add(new Vector(0, 0, -0.5));
		loc.getWorld().spawnParticle(particle, temp, count, 0.5, 0.5, 0, 0, data, true);
	}
	
	public static ArrayList<LivingEntity> damageArea(Location loc, double radius, int amount, Player source)
	{
		ArrayList<LivingEntity> damaged = new ArrayList<>();
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity == source || entity.getScoreboardTags().contains("display"))
				continue;
			if (entity.getBoundingBox().expand(radius).contains(loc.toVector()))
			{
				entity.damage(amount, source);
				damaged.add(entity);
			}
		}
		return damaged;
	}
	
	public static ArrayList<Block> getBlocksInRadius(Location loc, long radius)
	{
		ArrayList<Block> blocks = new ArrayList<>();
		Location temp;
		for (int x = -Math.round(radius); x <= Math.round(radius); x++)
			for (int y = -Math.round(radius); y <= Math.round(radius); y++)
				for (int z = -Math.round(radius); z <= Math.round(radius); z++)
					if ((temp = loc.clone().add(new Vector(x, y, z))).distance(loc) <= radius)
						blocks.add(temp.getBlock());
		return blocks;
	}
	
	public static ArrayList<Entity> getEntitiesInRadius(Location loc, double radius)
	{
		ArrayList<Entity> entities = new ArrayList<>();
		for (Entity entity:loc.getWorld().getEntities())
			if (entity.getLocation().distance(loc) <= radius)
				entities.add(entity);
		return entities;
	}
	
	public static Location toOverworldLocation(Location loc)
	{
		Location overloc = loc.clone().multiply(8).toBlockLocation();
		overloc.setY(loc.getY());
		overloc.setWorld(Bukkit.getWorld("world"));
		return overloc;
	}
	
	public static Location toNetherLocation(Location loc)
	{
		Location netherloc = loc.clone().multiply(0.125).toBlockLocation();
		netherloc.setY(loc.getY());
		netherloc.setWorld(Bukkit.getWorld("world_nether"));
		return netherloc;
	}
	
	public static Location toLowestSafeLocation(Location loc)
	{
		Location newloc = loc.clone().toBlockLocation();
		Vector increment = new Vector(0, 1, 0);
		newloc.setY(loc.getWorld().getName() == "world" ? -64 : 0);
		while (!blockIsSafe(newloc) && !blockIsSafe(newloc.clone().add(increment)))
		{
			newloc.add(increment);
		}
		return newloc;
	}
	
	public static Location toSafeLocation(Location loc)
	{
		Location newloc = loc.clone().toBlockLocation();
		Vector increment = new Vector(0, 1, 0);
		newloc.setY(64);
		while (!blockIsSafe(newloc) && !blockIsSafe(newloc.clone().add(increment)))
		{
			newloc.add(increment);
		}
		while (blockIsSafe(newloc))
		{
			newloc.subtract(increment);
		}
		newloc.add(increment);
		return newloc;
	}
	
	private static boolean blockIsSafe(Location loc)
	{
		Block block = loc.getBlock();
		return (block.isPassable() && block.getType() != Material.LAVA);
	}
	
	public static void swapLocations(Location loc1, Location loc2, int radius, boolean teleportEntities, Plugin plugin)
	{
		ArrayList<Block> blocks1 = Utils.getBlocksInRadius(loc1.clone().toBlockLocation(), radius);
		ArrayList<Block> blocks2 = Utils.getBlocksInRadius(loc2.clone().toBlockLocation(), radius);
		ArrayList<Entity> entities1 = Utils.getEntitiesInRadius(loc1.clone(), radius);
		ArrayList<Entity> entities2 = Utils.getEntitiesInRadius(loc2.clone(), radius);
		World world1 = loc1.getWorld();
		World world2 = loc2.getWorld();
		Random random = new Random();
		int seed = random.nextInt();
		
		random.setSeed(seed);
		Collections.shuffle(blocks1, random);
		random.setSeed(seed);
		Collections.shuffle(blocks2, random);
		
		new BukkitRunnable()
		{
			int time = 0;
			int max = Math.min(blocks1.size(), blocks2.size());
			BlockData data1;
			BlockData data2;
			Location temp1;
			Location temp2;
			
			@Override
			public void run()
			{
				for (int i = 0; i < blocks1.size() * 0.075 + 10 && time < max; i++)
				{
					temp1 = blocks1.get(time).getLocation();
					temp2 = blocks2.get(time).getLocation();
					data1 = world1.getBlockData(temp1).clone();
					data2 = world2.getBlockData(temp2).clone();
					world1.setBlockData(temp1, data2);
					world2.setBlockData(temp2, data1);
					
					time++;
					if (teleportEntities && time == max - max/3)
					{
						for (Entity entity:entities1)
						{
							temp1 = entity.getLocation().clone();
							temp2 = temp1.clone().subtract(loc1.toVector());
							temp1 = loc2.clone().add(temp2.toVector());
							temp1.setDirection(entity.getLocation().getDirection());
							entity.teleport(temp1);
						}
						
						for (Entity entity:entities2)
						{
							temp1 = entity.getLocation().clone();
							temp2 = temp1.clone().subtract(loc2.toVector());
							temp1 = loc1.clone().add(temp2.toVector());
							temp1.setDirection(entity.getLocation().getDirection());
							entity.teleport(temp1);
						}	
					}
					if (time >= max)
					{
						cancel();
					}
				}
				for (Entity entity:entities1)
					entity.setVelocity(new Vector(0, 0.01, 0));
				for (Entity entity:entities2)
					entity.setVelocity(new Vector(0, 0.01, 0));
			}
		}.runTaskTimer(plugin, 0, 1);
	}
}
