package me.August.OnePunch;

import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	@Override
	public void onEnable() {
		Bukkit.getPluginManager().registerEvents(this, this);
	}
	
	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	public void smack(EntityDamageByEntityEvent e) {
		if(e.getDamager() instanceof LivingEntity || e.getDamager() instanceof Projectile) {
			Entity p = (Entity) e.getDamager();
			if(p instanceof LivingEntity) {
				((LivingEntity) p).setNoDamageTicks(10);
			}
			Vector dir = p.getLocation().getDirection().normalize();
			if(p instanceof Projectile) {
				dir = p.getVelocity().normalize();
			}
			LivingEntity en = (LivingEntity) e.getEntity();
			new MobLaunch(en, p, dir, this);
		}
	}
}
