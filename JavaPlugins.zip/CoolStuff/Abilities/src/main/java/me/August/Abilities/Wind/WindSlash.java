package me.August.Abilities.Wind;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;

public class WindSlash extends Skill {
	
	float attackradius, attackdamage;

	public WindSlash(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		attackradius = level * 0.3F + 5;
		attackdamage = 1 + 0.5F * level;
		particle(0);
		new BukkitRunnable()
		{
			int time = 0;
			@Override
			public void run()
			{
				time++;
				player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().clone().add(new Vector(0, 1, 0)), 40, 0, 0, 0, 0.7, null, true);
				if (time > 4)
				{
					attack(true);
					cancel();
				}
				else
					attack(false);
			}
		}.runTaskTimer(plugin, 0, 5);
	}
	
	private void attack(boolean knock)
	{
		Location loc = player.getLocation().clone().add(new Vector(0, 1, 0));
		int damageticks;
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getLocation().distance(loc) < attackradius)
			{
				damageticks = entity.getNoDamageTicks();
				entity.setNoDamageTicks(0);
				entity.damage(attackdamage, player);
				entity.setNoDamageTicks(damageticks);
				if (knock)
				{
					entity.setVelocity(entity.getLocation().clone().subtract(loc).toVector().setY(0).normalize().setY(0.3).multiply(1.4));
				}
			}
		}
	}
	
	private void particle(long time)
	{
		new BukkitRunnable()
		{
			int time = 0;
			Location loc;
			Vector vel = new Vector(0, 0, 1);
			
			@Override
			public void run() {
				time++;
				loc = player.getLocation().clone().add(new Vector(0, 1, 0));
				vel.rotateAroundY(Math.PI/21);
				for (int i = 0; i < 6; i++)
				{
					vel.rotateAroundY(Math.PI/3);
					player.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 0, vel.getX(), 0, vel.getZ(), 0.1 * attackradius, null, true);
				}
				if (time > 20)
				{
					cancel();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
		
	}

}
