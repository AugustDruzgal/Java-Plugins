package me.August.Gauntlet;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

public class GuiDisplayItem {
	
	Material material = Material.DIRT;
	int customModelData = 2;
	int cooldownCustomModelData = 3;
	String displayName = "dummy";
	TextColor displayNameColor = TextColor.color(255, 40, 60);
	
	public ItemStack getAsItemStack(Player player, int cooldown)
	{
		ItemStack itemStack = new ItemStack(material);
		ItemMeta itemMeta = itemStack.getItemMeta();
		itemMeta.setCustomModelData((cooldown > 0) ? cooldownCustomModelData : customModelData);
		itemMeta.displayName(Component.text(displayName).color(displayNameColor));
		itemStack.setItemMeta(itemMeta);
		itemStack.setAmount(cooldown/20 + 1);
		return itemStack;
	}
	
	public void setMaterial(Material material)
	{
		this.material = material;
	}
	
	public void setCustomModelData(int customModelData)
	{
		this.customModelData = customModelData;
	}
	
	public void setCooldownCustomModelData(int cooldownCustomModelData)
	{
		this.cooldownCustomModelData = cooldownCustomModelData;
	}
	
	public void setDisplayName(String displayName)
	{
		this.displayName = displayName;
	}
	
	public void setDisplayNameColor(TextColor displayNameColor)
	{
		this.displayNameColor = displayNameColor;
	}
	
	public void setDisplayNameColor(int r, int g, int b)
	{
		this.displayNameColor = TextColor.color(r, g, b);
	}
	
	public GuiDisplayItem clone()
	{
		GuiDisplayItem copyItem = new GuiDisplayItem();
		copyItem.setCooldownCustomModelData(this.cooldownCustomModelData);
		copyItem.setCustomModelData(this.customModelData);
		copyItem.setDisplayName(this.displayName);
		copyItem.setDisplayNameColor(this.displayNameColor);
		copyItem.setMaterial(this.material);
		return copyItem;
	}

}
