package me.August.Shock;

import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import javax.comm.*;

public class Main extends JavaPlugin implements Listener {
	
	@Override
	public void onEnable() {
		CommPortIdentifier cpi = CommPortIdentifier.getPortIdentifier("COM2");
		  if (cpi.getType() == CommPortIdentifier.PORT_SERIAL) {
		    try {
		      SerialPort modem = (SerialPort) cpi.open();
		    }
		    catch (PortInUseException e) {}
		  }
	}
	
	@Override
	public void onDisable() {
		
	}

}
