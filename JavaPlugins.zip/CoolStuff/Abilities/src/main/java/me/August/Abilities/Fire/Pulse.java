package me.August.Abilities.Fire;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Util.Skill;
import me.August.Abilities.Util.Utils;
import me.August.TemporaryBlocks.TemporaryBlockManager;

public class Pulse extends Skill implements Utils {

	public Pulse(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getAxes());
	}
	
	@Override
	public void effect(int level)
	{
		Vector offset = new Vector(5, 0, 0);
		Location loc;
		for (int i = 0; i < 100; i++)
		{
			offset.rotateAroundY(Math.PI/21);
			offset.rotateAroundAxis(offset.getCrossProduct(new Vector(0, 1, 0)), Math.PI/200);
			loc = player.getLocation().clone().add(offset);
			loc.getWorld().spawnParticle(Particle.FLAME, loc, 1, 0, 0, 0, 0.03, null, true);
		}
		player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 60, 1));
		loc = player.getLocation().clone();
		hit(loc);
		burn(loc);
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				player.setFireTicks(0);
			}
		}.runTaskLater(plugin, 25);
	}
	
	private void burn(Location loc)
	{
		Location temp;
		for (Block block:Utils.getNearbySurfaceBlocks(loc, 6))
		{
			temp = block.getLocation().add(new Vector(0, 1, 0));
			TemporaryBlockManager.createTemporaryBlock(temp, Material.FIRE, 20, plugin);
		}
	}
	
	private void hit(Location loc)
	{
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getLocation().distance(loc) <= 6)
			{
				entity.damage(4);
				entity.setFireTicks(20);
			}
		}
	}
	
}
