module Water {
	requires spigot;
}