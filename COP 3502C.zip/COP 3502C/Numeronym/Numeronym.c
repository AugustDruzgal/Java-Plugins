// August Druzgal au907615
// COP 3502C Spring Semester

#include <ctype.h>
#include "Numeronym.h"
#include <stdio.h>
#include <string.h>

// This function takes multiple string inputs and passes them to printNumeronym().
int main(int argc, char **argv)
{
	int i;
	
	for (i = 1; i < argc; i++) 
	{
		printNumeronym(argv[i]);
	}
	
	return 0;
}

// This function takes a pointer to a character array and prints it as a
// numeronym if its length exceeds 8 characters. 
void printNumeronym(char *str) 
{
	int len = strlen(str);
	
	if (len >= 9)
	{
		printf("%s -> %c%d%c\n", str, str[0], (len - 2), str[len-1]);
	} else {
		printf("%s (no change)\n", str);
	}
}

// This function takes a string input and prints the string with words
// exceeding 8 characters replaced by numeronyms of those words. 
void printShortenedSentence(char *str)
{
	int i, j, len;
	int word_start_marker = 0;
	
	len = strlen(str);
	
	// This loop iterates through each character in the array and marks spaces to
	// determine the length of each word, printing each word to the screen if it's
	// shorter than 8 characters and printing it as a numeronym if longer. 
	for (i = 0; i < len; i++) 
	{
		if (!isalpha(str[i])) 
		{
			if (i - word_start_marker >= 9)
			{
				printf("%c%d%c", str[word_start_marker], i - word_start_marker - 2, str[i-1]);
			} else {
				for (j = 0 ; j < (i - word_start_marker) ; j++)
				{
					printf("%c", str[word_start_marker + j]);
				}
			}
			
			printf("%c", str[i]);
			
			word_start_marker = i + 1;
			
		}
	}
	
	printf("\n");
}

// This function returns my difficulty rating for this assignment
double difficultyRating(void)
{
	return 2;
}

// This function returns my time spent on this project
double hoursSpent(void)
{
	return 2;
}
