package me.August.CustomItems;

import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

public class EventListener implements Listener {
	
	@EventHandler
	public void onInteract(PlayerInteractEvent e)
	{
		Player player = e.getPlayer();
		if (e.getAction() != Action.RIGHT_CLICK_AIR || e.getHand() != EquipmentSlot.HAND)
			return;
		CustomItemManager.onRightClick(e.getItem(), player);
	}
	
	@EventHandler
	public void onSelectItem(PlayerItemHeldEvent e)
	{
		Player player =  e.getPlayer();
		if (!PlayerData.isActive(player))
			return;
		e.setCancelled(true);
		CustomItemManager.onSelectItem(e.getPlayer().getInventory().getItem(e.getNewSlot()), player);
	}
	
	@EventHandler
	public void onDropItem(PlayerDropItemEvent e)
	{
		Player player = e.getPlayer();
		if (!PlayerData.isActive(player))
			return;
		e.setCancelled(true);
		if (CustomItemManager.isCustomItem(e.getItemDrop().getItemStack()))
		{
			CustomItemManager.getCustomItem(e.getItemDrop().getItemStack()).onDrop(player);
		}
	}
	
	@EventHandler
	public void onInventoryEvent(InventoryDragEvent e)
	{
		HumanEntity player = e.getWhoClicked();
		if (!(player instanceof Player) || !PlayerData.isActive((Player) player))
			return;
		e.setCancelled(true);
	}
	
	@EventHandler
	public void onInventoryEvent(InventoryClickEvent e)
	{
		HumanEntity player = e.getWhoClicked();
		if (!(player instanceof Player) || !PlayerData.isActive((Player) player))
			return;
//		if (e.getClick() == ClickType.RIGHT && e.getCursor().getMaxStackSize() < 64)
//			e.setCursor(null);
		if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SWAP_OFFHAND)
			e.setCancelled(true);
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e)
	{
		Player player = e.getPlayer();
		CustomItemManager.initPlayer(player);
	}
	
	@EventHandler
	public void onLeave(PlayerQuitEvent e)
	{
		
	}

}
