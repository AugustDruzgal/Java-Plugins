module InfinityGauntlet {
	requires spigot;
}