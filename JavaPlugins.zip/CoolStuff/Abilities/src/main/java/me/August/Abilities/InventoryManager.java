package me.August.Abilities;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class InventoryManager {
	
	private Player player;
	private HashMap<String, Inventory> invs;
	private String current;
	
	InventoryManager(Player p)
	{
		player = p;
		invs = new HashMap<String, Inventory>();
		invs.put("main", Bukkit.createInventory(player, 36, createInventoryName("Select Class")));
		invs.put("air", Bukkit.createInventory(player, 54, createInventoryName("Air")));
		invs.put("storm", Bukkit.createInventory(player, 54, createInventoryName("Storm")));
		invs.put("fire", Bukkit.createInventory(player, 54, createInventoryName("Fire")));
		invs.put("earth", Bukkit.createInventory(player, 54, createInventoryName("Earth")));
		invs.put("ice", Bukkit.createInventory(player, 54, createInventoryName("Ice")));
		invs.put("void", Bukkit.createInventory(player, 54, createInventoryName("Void")));
		initinvs();
		current = "none";
	}
	
	public void openInventory(String str)
	{
		Inventory inv = invs.get(str);
		if (inv != null)
		{
			player.openInventory(inv);
			current = str;
		}
	}
	
	public void setClosed()
	{
		current = "none";
	}
	
	public String getCurrent()
	{
		return current;
	}
	
	private void initinvs()
	{
		for(String inv:invs.keySet())
		{
			if (inv != "main")
				init(invs.get(inv));
		}
		initmain();
		initair();
		initstorm();
		initfire();
		initearth();
		initice();
		initvoid();
	}
	
	private void init(Inventory inv)
	{
		inv.setItem(10, new ItemStack(Material.IRON_SWORD));
		inv.setItem(19, new ItemStack(Material.IRON_AXE));
		inv.setItem(28, new ItemStack(Material.RED_DYE));
		inv.setItem(37, new ItemStack(Material.ORANGE_DYE));
		inv.setItem(46, new ItemStack(Material.YELLOW_DYE));
		inv.setItem(45, new ItemStack(Material.BARRIER));
	}
	
	private void initmain()
	{
		Inventory inv = invs.get("main");
		inv.setItem(10, new ItemStack(Material.LEATHER_HELMET));
		inv.setItem(11, new ItemStack(Material.CHAINMAIL_HELMET));
		inv.setItem(12, new ItemStack(Material.GOLDEN_HELMET));
		inv.setItem(14, new ItemStack(Material.IRON_HELMET));
		inv.setItem(15, new ItemStack(Material.DIAMOND_HELMET));
		inv.setItem(16, new ItemStack(Material.NETHERITE_HELMET));
		inv.setItem(19, new ItemStack(Material.MAGENTA_DYE));
		inv.setItem(20, new ItemStack(Material.MAGENTA_DYE));
		inv.setItem(21, new ItemStack(Material.MAGENTA_DYE));
		inv.setItem(23, new ItemStack(Material.MAGENTA_DYE));
		inv.setItem(24, new ItemStack(Material.MAGENTA_DYE));
		inv.setItem(25, new ItemStack(Material.MAGENTA_DYE));
	}
	
	private void initair()
	{
		Inventory inv = invs.get("air");
		inv.setItem(12, new ItemStack(Material.BOOK));
		inv.setItem(13, new ItemStack(Material.BOOK));
		inv.setItem(21, new ItemStack(Material.BOOK));
		inv.setItem(22, new ItemStack(Material.BOOK));
	}
	
	private void initstorm()
	{
		Inventory inv = invs.get("storm");
		inv.setItem(12, new ItemStack(Material.BOOK));
		inv.setItem(13, new ItemStack(Material.BOOK));
		inv.setItem(21, new ItemStack(Material.BOOK));
		inv.setItem(22, new ItemStack(Material.BOOK));
	}
	
	private void initfire()
	{
		Inventory inv = invs.get("fire");
		inv.setItem(12, new ItemStack(Material.BOOK));
		inv.setItem(13, new ItemStack(Material.BOOK));
		inv.setItem(21, new ItemStack(Material.BOOK));
		inv.setItem(22, new ItemStack(Material.BOOK));
	}
	
	private void initearth()
	{
		Inventory inv = invs.get("earth");
		inv.setItem(21, new ItemStack(Material.DIRT));
	}
	
	private void initice()
	{
		Inventory inv = invs.get("ice");
		inv.setItem(12, new ItemStack(Material.SNOWBALL));
		inv.setItem(21, new ItemStack(Material.ICE));
	}
	
	private void initvoid()
	{
		
	}

	private Component createInventoryName(String str) {
		TextComponent component = Component.text(str);
		component.color(TextColor.color(0, 255, 0));
		return component;
	}

}