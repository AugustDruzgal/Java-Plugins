package me.AugustDruzgal.MobMitosis;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	@Override
	public void onEnable() {
		Bukkit.getPluginManager().registerEvents(this, this);
	}
	
	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	public void playerkill(EntityDeathEvent e) {
		if(e.getEntity() instanceof LivingEntity && !(e.getEntity() instanceof Player)) {
			LivingEntity entity = (LivingEntity) e.getEntity();
			if(entity.getKiller() != null) {
				if(entity.getKiller() instanceof Player) {
					Location loc = entity.getLocation();
					LivingEntity entity1 = (LivingEntity) entity.getWorld().spawnEntity(loc, entity.getType());
					entity1.setVelocity(new Vector(0.7,0.7,0).rotateAroundY(Math.random()*2*Math.PI));
					LivingEntity entity2 = (LivingEntity) entity.getWorld().spawnEntity(loc, entity.getType());
					entity2.setVelocity(entity1.getVelocity().clone().rotateAroundY(Math.PI));
				}
			}
		}
	}
}
