package me.August.InfinityStones;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class SpaceStone extends Stone {

	SpaceStone(Plugin pl) {
		super(pl);
		name = "Space Stone";
		color = Color.fromRGB(20, 10, 255);
		time = 40;
	}
	
	@Override
	public void p()
	{
		player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 20, 2));
	}
	
	@Override
	public void a()
	{
		Vector dir = player.getLocation().getDirection().clone().normalize();
		dir.multiply(2.5).add(new Vector(0, 0.2, 0));
		player.setVelocity(dir);
		new BukkitRunnable()
		{
			int time = 0;
			@Override
			public void run()
			{
				time++;
				
				player.getWorld().spawnParticle(Particle.REDSTONE, player.getLocation().clone().add(new Vector(0, 0.25, 0)), 10, 0.3, 0.3, 0.3, 0, new DustOptions(Color.BLUE, 1), true);
				
				if (time > 40)
					cancel();
			}
		}.runTaskTimer(plugin, 0, 1);
	}
	
	@Override
	public ItemStack createItem()
	{
		ItemStack new_item = new ItemStack(Material.AMETHYST_SHARD);
		
		ItemMeta meta = new_item.getItemMeta();
		TextComponent name = Component.text("space stone").color(TextColor.color(20, 10, 225));
		meta.displayName(name);
		meta.setCustomModelData(3);
		new_item.setItemMeta(meta);
		
		return new_item;
	}

}
