package me.August.CustomItems;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AbilityItem {
	
	ItemStack item;
	int maxCooldown = 100;
	int customModelData;
	int cooldownCustomModelData;
	AbilityEffect abilityEffect;
	HashMap<Player, Integer> cooldowns = new HashMap<>();
	
	public AbilityItem(ItemStack item, AbilityEffect abilityEffect)
	{
		this.item = item;
		this.customModelData = item.getItemMeta().hasCustomModelData() ? item.getItemMeta().getCustomModelData() : 0;
		this.cooldownCustomModelData = this.customModelData + 1;
		this.abilityEffect = abilityEffect;
		CustomItemManager.addAbilityItem(this);
	}
	
	public void update()
	{
		for (Player player:Bukkit.getOnlinePlayers())
		{
			if (cooldowns.get(player) > 0)
				cooldowns.put(player, cooldowns.get(player) - 1);
		}
	}
	
	public void init(Player player)
	{
		cooldowns.put(player, 0);
	}
	
	public void activate(Player player)
	{
		if (cooldowns.get(player) == 0)
		{
			if (abilityEffect.effect(player))
				cooldowns.put(player, maxCooldown);
		}
	}
	
	public void setMaxCooldown(int maxCooldown)
	{
		this.maxCooldown = maxCooldown;
	}
	
	public void setCustomModelData(int customModelData)
	{
		this.customModelData = customModelData;
	}
	
	public void setCooldownCustomModelData(int cooldownCustomModelData)
	{
		this.cooldownCustomModelData = cooldownCustomModelData;
	}
	
	public ItemStack getCooldownItemStack(Player player)
	{
		ItemStack itemStack = item.clone();
		ItemMeta meta = item.getItemMeta();
		meta.setCustomModelData(getCooldown(player) > 0 ? cooldownCustomModelData : customModelData);
		itemStack.setItemMeta(meta);
		itemStack.setAmount(1 + getCooldown(player)/20);
		return itemStack;
	}
	
	public boolean compare(ItemStack compareItem)
	{
		ItemStack itemStack = item.clone();
		ItemStack citemStack = compareItem.clone();
		ItemMeta meta = itemStack.getItemMeta();
		ItemMeta cmeta = citemStack.getItemMeta();
		meta.setCustomModelData(0);
		cmeta.setCustomModelData(0);
		itemStack.setItemMeta(meta);
		citemStack.setItemMeta(cmeta);
		return itemStack.isSimilar(citemStack);
	}
	
	public int getCooldown(Player player)
	{
		return cooldowns.get(player);
	}
}
