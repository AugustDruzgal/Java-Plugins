package me.August.InfinityStones;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class PowerStone extends Stone {
	
	int active = 0;

	PowerStone(Plugin pl) {
		super(pl);
		name = "Power Stone";
		color = Color.fromRGB(255, 100, 225);
		time = 0;
	}
	
	@Override
	public void p()
	{
		if (player != null)
		{
			player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 20, 1));
		}
	}
	
	@Override
	public void a()
	{
		if (isHoldingInMain())
		{
			active = 1;
			player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1F, 3F);
			new BukkitRunnable()
			{
				int time = 0;
				Vector vec;
				Location loc;
				DustOptions dust = new DustOptions(Color.PURPLE, 1F);
				@Override
				public void run()
				{
					time++;
					loc = player.getLocation().clone().add(new Vector(0, 0.84, 0));
					player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 20, 3));
					for (int i = 0; i < 25; i++)
					{
						vec = Vector.getRandom().add(new Vector(-0.5, -0.5, -0.5)).normalize().multiply(1.6);
						player.getWorld().spawnParticle(Particle.REDSTONE, loc.clone().add(vec), 1, 0, 0, 0, 0, dust, true);
					}
					
					if (time > 70 || active == 0)
					{
						active = 0;
						player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1F, 3F);
						cancel();
					}
				}
			}.runTaskTimer(plugin, 0, 1);
		}
	}
	
	@Override
	public ItemStack createItem()
	{
		ItemStack new_item = new ItemStack(Material.AMETHYST_SHARD);
		
		ItemMeta meta = new_item.getItemMeta();
		TextComponent name = Component.text("power stone").color(TextColor.color(255, 100, 225));
		meta.displayName(name);
		meta.setCustomModelData(2);
		new_item.setItemMeta(meta);
		
		return new_item;
	}
	
	public boolean isActive()
	{
		if (active == 1)
			return true;
		return false;
	}

}
