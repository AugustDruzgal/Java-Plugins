package me.August.Gauntlet;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class EventListener implements Listener {
	
	@EventHandler
	public void onItemUse(PlayerInteractEvent e)
	{
		ItemStack item;	
		GuiItem guiItem;
		Player player = e.getPlayer();
		PlayerGui playerGui;
		
		if (e.getAction() != Action.RIGHT_CLICK_AIR || e.getHand() != EquipmentSlot.HAND)
			return;
		
		item = e.getItem();
		
		if (!GuiItemManager.isGuiItem(item))
		{
			player.sendMessage("not a GUI item");
			return;
		}
		
		guiItem = GuiItemManager.getGuiItem(item);
		playerGui = PlayerGuiManager.getPlayerGui(player);
		
		if (guiItem == playerGui.getPreviousGuiItem())
		{
			PlayerGuiManager.getPlayerGui(player).toggleGuiSet(GuiItemManager.getInfo(player).getGuiItem(item).getGuiSet(playerGui.getCurrentSetNum()), playerGui.getCurrentSetNum());
			return;
		}
		PlayerGuiManager.getPlayerGui(player).toggleGuiSet(GuiItemManager.getInfo(player).getGuiItem(item).getGuiSet(0), 0);
	}
	
	@EventHandler
	public void onSelectItem(PlayerItemHeldEvent e)
	{
		Player player = e.getPlayer();
		if (!PlayerGuiManager.getPlayerGui(player).getActiveState())
			return;
		e.setCancelled(true);
		PlayerGuiManager.getPlayerGui(player).getCurrentSet().getSlot(e.getNewSlot()).activateGuiAction(player);
	}
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent e)
	{
		Player player = e.getPlayer();
		PlayerGui playerGui = PlayerGuiManager.getPlayerGui(player);
		ItemStack item;
		int setNum;
		if (!playerGui.getActiveState())
			return;
		e.setCancelled(true);
		item = e.getItemDrop().getItemStack();
		if (playerGui.getCurrentSet().getParentGuiItem().getAsItemStack().isSimilar(item))
		{
			setNum = (playerGui.getCurrentSetNum() + 1)%GuiItemManager.getInfo(player).getGuiItem(item).getGuiSetAmount();
			playerGui.switchToGuiSet(GuiItemManager.getInfo(player).getGuiItem(item).getGuiSet(setNum), setNum);
		}
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e)
	{
		Player player = e.getPlayer();
		player.getInventory().addItem(GuiItemManager.getGuiItem("dummy").getAsItemStack());
		player.getInventory().addItem(GuiItemManager.getGuiItem("dummy2").getAsItemStack());
		PlayerGuiManager.addPlayerGui(player);
		GuiItemManager.initPlayer(player);
	}
	
	@EventHandler
	public void onLeave(PlayerQuitEvent e)
	{
		Player player = e.getPlayer();
		PlayerGuiManager.getPlayerGui(player).restore();
	}
	
	@EventHandler
	public void onDeath(PlayerDeathEvent e)
	{
		Player player = e.getPlayer();
		PlayerGuiManager.getPlayerGui(player).restore();
	}
}
