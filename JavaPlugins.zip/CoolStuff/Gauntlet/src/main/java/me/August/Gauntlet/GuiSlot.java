package me.August.Gauntlet;

import org.bukkit.entity.Player;

public class GuiSlot {
	
	private GuiDisplayItem guiDisplayItem;
	private GuiAction guiAction;
	private GuiCooldown guiCooldown;
	
	public GuiSlot(GuiDisplayItem guiDisplayItem, GuiAction guiAction, GuiCooldown guiCooldown)
	{
		this.guiDisplayItem = guiDisplayItem;
		this.guiAction = guiAction;
		this.guiCooldown = guiCooldown;
	}
	
	public void activateGuiAction(Player player)
	{
		if (this.getGuiCooldown().getCooldown() != 0)
			return;
		this.getGuiAction().action(player);
	}
	
	public GuiDisplayItem setGuiDisplayItem(GuiDisplayItem guiDisplayItem)
	{
		this.guiDisplayItem = guiDisplayItem;
		return this.guiDisplayItem;
	}
	
	public GuiDisplayItem getGuiDisplayItem()
	{
		return this.guiDisplayItem;
	}
	
	public GuiAction setGuiAction(GuiAction guiAction)
	{
		this.guiAction = guiAction;
		return this.guiAction;
	}
	
	public GuiAction getGuiAction()
	{
		return this.guiAction;
	}
	
	public GuiCooldown setGuiCooldown(GuiCooldown guiCooldown)
	{
		this.guiCooldown = guiCooldown;
		return this.guiCooldown;
	}
	
	public GuiCooldown getGuiCooldown()
	{
		return guiCooldown;
	}
	
	public void updateCooldown()
	{
		guiCooldown.updateCooldown();
	}
	
	public GuiSlot clone()
	{
		return new GuiSlot(this.guiDisplayItem.clone(), this.guiAction.clone(), this.guiCooldown.clone());
	}
}
