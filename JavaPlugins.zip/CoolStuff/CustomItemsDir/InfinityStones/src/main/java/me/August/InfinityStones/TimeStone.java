package me.August.InfinityStones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.CustomItems.AbilityEffect;
import me.August.CustomItems.AbilityItem;
import me.August.CustomItems.CustomItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class TimeStone {
	
	private static ItemStack loopItem;
	private static ItemStack dayItem;
	private static ItemStack ageItem;
	private static ItemStack stoneItem;
	private static Plugin plugin;
	private static HashMap<Player, Location> loopLocations = new HashMap<>();

	public static void initTimeStone(Plugin plugin)
	{
		TimeStone.plugin = plugin;
		initItems();
		createAbilities();
		createStoneItem();
	}
	
	private static void initItems()
	{
		ItemStack item;
		ItemMeta meta;
		List<Component> lore;
		TextComponent name;
		TextColor nameColor = TextColor.color(100, 255, 100);
		TextColor loreColor = TextColor.color(0, 255, 0);
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Time Stone").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("A stone containing the").color(loreColor));
		lore.add(Component.text("essence of time").color(loreColor));
		
		meta.setCustomModelData(5);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		stoneItem = item;
		
		item = new ItemStack(Material.EMERALD);
		meta = item.getItemMeta();
		
		name = Component.text("Temporal Loop").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Capture a moment in time").color(loreColor));
		lore.add(Component.text("and draw yourself back to").color(loreColor));
		lore.add(Component.text("it with a second cast of").color(loreColor));
		lore.add(Component.text("this ability").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		loopItem = item;
		
		item = new ItemStack(Material.EMERALD);
		meta = item.getItemMeta();
		
		name = Component.text("Celestial shift").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Accelerate the global passage").color(loreColor));
		lore.add(Component.text("of time, causing the day or night").color(loreColor));
		lore.add(Component.text("to end early").color(loreColor));
		
		meta.setCustomModelData(4);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		dayItem = item;
		
		item = new ItemStack(Material.EMERALD);
		meta = item.getItemMeta();
		
		name = Component.text("Age").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Bend time around the mobs").color(loreColor));
		lore.add(Component.text("in front of you, instantly").color(loreColor));
		lore.add(Component.text("growing them into adults.").color(loreColor));
		
		meta.setCustomModelData(6);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		ageItem = item;
	}
	
	public static void createAbilities()
	{
		AbilityItem item;
		item = new AbilityItem(loopItem, getLoopEffect());
		item.setCooldownCustomModelData(3);
		item.setMaxCooldown(150);
		item = new AbilityItem(dayItem, getDayEffect());
		item.setCooldownCustomModelData(5);
		item.setMaxCooldown(200);
		item = new AbilityItem(ageItem, getAgeEffect());
		item.setCooldownCustomModelData(7);
		item.setMaxCooldown(60);
	}
	
	public static ArrayList<ItemStack> getAbilityItems()
	{
		ArrayList<ItemStack> items = new ArrayList<>();
		items.add(loopItem);
		items.add(dayItem);
		items.add(ageItem);
		return items;
	}
	
	public static void createStoneItem()
	{
		CustomItem powerStone = new CustomItem(stoneItem, "time");
		powerStone.setNumHotbars(1);
		powerStone.setAbilityItems(getAbilityItems());
	}
	
	private static AbilityEffect getLoopEffect()
	{
		return new AbilityEffect() 
		{
			@Override
			public boolean effect(Player player) {
				
				Location loc;
				DustOptions dust = new DustOptions(Color.LIME, 1F);
				
				Utils.particleSwirl(player, Particle.REDSTONE, plugin, dust);
				
				if (loopLocations.get(player) == null)
				{
					loopLocations.put(player, player.getLocation());
				}
				else
				{
					player.getWorld().spawnParticle(Particle.EXPLOSION_NORMAL, player.getLocation(), 14, 0, 0, 0, 0.35, null, true);
					Utils.particleSphere(Particle.REDSTONE, player.getLocation().clone().add(new Vector(0, 1, 0)), 1.4, 50, dust);
					player.setFallDistance(0);
					player.teleport(loopLocations.get(player));
					player.getWorld().spawnParticle(Particle.EXPLOSION_NORMAL, player.getLocation(), 14, 0, 0, 0, 0.35, null, true);
					loopLocations.remove(player);
				}
				
				loc = player.getLocation().clone().add(new Vector(0, 0.2, 0));
				
				new BukkitRunnable()
				{
					int time = 0;
					
					@Override
					public void run()
					{
						particleTimeCircle(loc, new Vector(0, 1, 0.001), 3);
						time++;
						if (time > 8)
							cancel();
					}
				}.runTaskTimer(plugin, 0, 1);
				
				return true;
			}
		};
	}
	
	private static AbilityEffect getDayEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player)
			{
				boolean day = player.getWorld().getTime() < 14500 && player.getWorld().getTime() > 1000;
				
				new BukkitRunnable()
				{
					Location loc;
					Vector dir;
					@Override
					public void run()
					{
						if (day && player.getWorld().getTime() > 14500)
							cancel();
						else if (!day && player.getWorld().getTime() < 14500 && player.getWorld().getTime() > 1000)
							cancel();
						player.getWorld().setTime(player.getWorld().getTime() + 200);
						loc = player.getLocation().clone().add(new Vector(0, 1, 0));
						dir = loc.getDirection().clone().multiply(3);
						loc.add(dir);
						particleTimeCircle(loc, dir, 3);
					}
				}.runTaskTimer(plugin, 0, 1);
				return true;
			}
		};
	}
	
	private static AbilityEffect getAgeEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player)
			{
				Location loc = player.getLocation().clone().add(new Vector(0, 1, 0));
				Vector dir = loc.getDirection().clone();
				if (Utils.allEntityFrontAttack(player, 10, getAgePowerEffect()))
				{
					Utils.particleSpiral(Particle.REDSTONE, loc, dir, 2.5, new DustOptions(Color.LIME, 1F));
					return true;
				}
				return false;
			}
		};
	}
	
	private static PowerEffect getAgePowerEffect()
	{
		return new PowerEffect()
		{
			DustOptions dust = new DustOptions(Color.LIME, 1F);
			
			@Override
			boolean effect(Player player, Location loc, LivingEntity target) {
				if (target instanceof Ageable)
				{
					((Ageable) target).setAdult();
					Utils.particleSwirl(target, Particle.REDSTONE, plugin, dust);
					return true;
				}
				return false;
			}
		};
	}
	
	private static void particleTimeCircle(Location loc, Vector axis, double size)
	{
		Location temp;
		DustOptions dust = new DustOptions(Color.LIME, 0.5F);
		Vector outoffset = axis.clone().rotateAroundY(Math.PI/2);
		Vector inoffset = axis.clone().rotateAroundY(Math.PI/2);
		Vector dir;
		outoffset.normalize().setY(0).normalize().multiply(size);
		inoffset.normalize().setY(0).normalize().multiply(size * 0.6);
		
		for (int i = 0; i < 20 * size; i++)
		{
			outoffset.rotateAroundAxis(axis, Math.PI / (10 * size));
			inoffset.rotateAroundAxis(axis, Math.PI / (10 * size));
			temp = loc.clone().add(outoffset);
			loc.getWorld().spawnParticle(Particle.REDSTONE, temp, 1, 0, 0, 0, 0, dust, true);
			temp = loc.clone().add(inoffset);
			loc.getWorld().spawnParticle(Particle.REDSTONE, temp, 1, 0, 0, 0, 0, dust, true);
		}
		
		for (int j = 0; j < 8; j++)
		{
			outoffset.rotateAroundAxis(axis, Math.PI/4);
			inoffset = outoffset.clone().rotateAroundAxis(axis, Math.PI/2);
			dir = outoffset.clone().subtract(inoffset).multiply(((double)1)/(7*size));
			for (int i = 0; i < 7 * size; i++)
			{
				inoffset.add(dir);
				temp = loc.clone().add(inoffset);
				loc.getWorld().spawnParticle(Particle.REDSTONE, temp, 1, 0, 0, 0, 0, dust, true);
			}
		}	
	}
}
