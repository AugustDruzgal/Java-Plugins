// August Druzgal
// COP 3502C Spring 2022

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TriePrediction.h"

// Function prototypes
// printTrieHelper and printTrie Credit: Dr. S.
void printTrieHelper(TrieNode *root, char *buffer, int k);

void printTrie(TrieNode *root, int useSubtrieFormatting);

void printSubtrie(TrieNode *root, char *str);

// A helper function for printPredictions
void printPrediction(TrieNode *root, char *word)
{
	getMostFrequentWord(getNode(root, word)->subtrie, word);
	printf(" %s", word);
}

// This function prints the next n predicted words to follow the passed word
void printPredictions(TrieNode *root, char *word, int n)
{
	int i;
	char current[MAX_CHARACTERS_PER_WORD];
	strcpy(current, word);
	printf("%s", word);
	for (i = 0; i < n; i++)
	{
		if (containsWord(root, current) && getNode(root, current)->subtrie != NULL)
			printPrediction(root, current);
	}
	printf("\n");
}

// This function creates a new TrieNode
TrieNode *createNode(void)
{
	int i;
	TrieNode *newNode = malloc(sizeof(TrieNode));
	
	newNode->count = 0;
	for (i = 0; i < 26; i++)
	{
		newNode->children[i] = NULL;
	}
	newNode->subtrie = NULL;
	
	return newNode;
}

// builds a trie using the contents of the passed file
TrieNode *buildTrie(char *filename)
{
	char c;
	TrieNode *root, *node, *subnode;
	FILE *input = fopen(filename, "r");
	if (input == NULL)
		return NULL;
	
	root = createNode();
	node = root;
	subnode = NULL;
	
	while (fscanf(input, "%c", &c) != EOF)
	{
		// if the next character is alphabetical, insert it below the current node and move to it
		if(isalpha(c))
		{
			c = tolower(c);
			if (node->children[c - 'a'] == NULL)
				node->children[c - 'a'] = createNode();
			node = node->children[c - 'a'];
			if (subnode != NULL)
			{
				if (subnode->children[c - 'a'] == NULL)
					subnode->children[c - 'a'] = createNode();
				subnode = subnode->children[c - 'a'];
			}
		}
		// if the next character is the end of a word, count the word and return to root
		else if (c == ' ' || c == '\n')
		{
			if (node != root)
			{
				node->count++;
				if (subnode != NULL)
					subnode->count++;
				if (node->subtrie == NULL)
					node->subtrie = createNode();
				subnode = node->subtrie;
				node = root;
			}
		}
		// if the next character is punctuation, ignore it
		else if (c == '!' || c == '?' || c == '.')
		{
			if (node != root)
			{
				node->count++;
				if (subnode != NULL)
					subnode->count++;
				subnode = NULL;
				node = root;
			}
		}
	}
	
	fclose(input);
	
	return root;
}

// This function follows the instructions of an input file to process a passed trie
int processInputFile(TrieNode *root, char *filename)
{
	FILE *input = fopen(filename, "r");
	char buffer[MAX_CHARACTERS_PER_WORD * MAX_WORDS_PER_LINE], key[MAX_CHARACTERS_PER_WORD];
	int i;
	
	if (input == NULL)
		return 0;
	
	// read each line of the file and follow the instructions
	while (fgets(buffer, MAX_CHARACTERS_PER_WORD*MAX_WORDS_PER_LINE, input) != NULL)
	{
		// @ str n - print the next n predicted words following str based on the trie
		if (buffer[0] == '@')
		{
			i = 0;
			while (isalpha(buffer[i+2]))
			{
				key[i] = buffer[i+2];
				i++;
			}
			key[i] = '\0';
			printPredictions(root, key, atoi(buffer+i+3));
		}
		// ! - print the contents of the trie
		else if (buffer[0] == '!')
			printTrie(root, 0);
		// str - print the subtrie of the passed word
		else if (isalpha(buffer[0]))
		{
			i = 0;
			while (isalpha(buffer[i]) || ispunct(buffer[i]))
			{
				key[i] = buffer[i];
				i++;
			}
			key[i] = '\0';
			printSubtrie(root, key);
		}
			
	}
	fclose(input);
	return 0;
}

// Destroy the passed trie and free all allocated memory within it
TrieNode *destroyTrie(TrieNode *root)
{
	int i;
	if (root == NULL)
		return NULL;
	for (i = 0; i < 26; i++)
		destroyTrie(root->children[i]);
	destroyTrie(root->subtrie);
	free(root);
	return NULL;
}

// Return the node for a given string if it is contained within the trie
TrieNode *getNode(TrieNode *root, char *str)
{
	int i;
	int len;
	TrieNode *node = root;
	
	if (root == NULL)
		return NULL;
	if (str == NULL)
		return NULL;
	len = strlen(str);
	
	for (i = 0; i < len; i++)
	{
		node = node->children[tolower(str[i]) - 'a'];
		if (node == NULL)
			return NULL;
	}
	return (node->count > 0)?node:NULL;
}

// A helper function for getMostFrequentWord
int getMostFrequentWordHelper(char *buffer, int path, int *max, TrieNode *node)
{
	int i;
	int n = 0;
	if (node == NULL)
		return 0;
	// recursively compare max with the count of all nodes contained in the trie
	if (node->count > *max)
	{
		*max = node->count;
		buffer[1] = '\0';
		n++;
	}
	for (i = 0; i < 26; i++)
		n += getMostFrequentWordHelper(buffer + 1, i, max, node->children[i]);
	// store the path to this node in buffer if the count of this node or any below it exceed max.
	if (n > 0)
		buffer[0] = 'a' + path;
	return (n > 0);
}

// This function stores the most common word in the trie within a passed string
void getMostFrequentWord(TrieNode *root, char *str)
{
	int i;
	int max = 0;
	
	if (str == NULL)
		return;
	if (root == NULL)
	{
		str[0] = '\0';
		return;
	}
	
	for (i = 0; i < 26; i++)
		getMostFrequentWordHelper(str, i, &max, root->children[i]);
	if (max == 0)
		str[0] = '\0';
}

// This function checks if a word is contained within the trie
int containsWord(TrieNode *root, char *str)
{
	int i = 0;
	int len; 
	if (root == NULL || str == NULL)
		return 0;
	len = strlen(str);
	
	for (i = 0; i < len; i++)
	{
		root = root->children[tolower(str[i]) - 'a'];
		if (root == NULL)
			return 0;
	}
	return (root->count > 0);
}

// A modified version of getNode which returns a node if it's stored in the trie, instead of only
// if it's stored in the trie with a count greater than one, for use in prefixCount
TrieNode *getPrefixNode(TrieNode *root, char *str)
{
	int i;
	int len;
	TrieNode *node = root;
	
	if (str == NULL)
		return NULL;
	if (root == NULL)
		return NULL;
	len = strlen(str);
	
	for (i = 0; i < len; i++)
	{
		node = node->children[tolower(str[i]) - 'a'];
		if (node == NULL)
			return NULL;
	}
	return node;
}

// A helper function for prefixCount
int prefixCountHelper(TrieNode *root)
{
	int i, count = 0;
	if (root == NULL)
		return 0;
	for (i = 0; i < 26; i++)
		count += prefixCountHelper(root->children[i]);
	count += root->count;
	return count;
}

// returns the number of words stored in the passed trie that begin with str
int prefixCount(TrieNode *root, char *str)
{
	TrieNode *prefix;
	if (root == NULL || NULL == (prefix = getPrefixNode(root, str)))
		return 0;
	return prefixCountHelper(prefix);
}

// Returns the amount of new nodes that would be necessary to store a word in the passed trie
int newNodeCount(TrieNode *root, char *str)
{
	TrieNode *node = root;
	int len;
	int i = 0;
	
	if (str == 0)
		return 0;
	
	len = strlen(str);
	
	if (root == NULL)
		return len + 1;
	
	while (isalpha(str[i]))
	{
		if (node->children[str[i] - 'a'] == NULL)
			return len;
		node = node->children[str[i] - 'a'];
		i++;
		len--;
	}
	return len;
}

// Returns my difficulty rating for this assignment
double difficultyRating(void)
{
	return 3.0;
}

// Returns my hours spent on this assignment
double hoursSpent(void)
{
	return 4.0;
}

// This function builds a trie and processes it using the passed corpus and input file
int main(int argc, char **argv)
{
	TrieNode *root = buildTrie(argv[1]);
	processInputFile(root, argv[2]);
	destroyTrie(root);
	return 0;
}

// Helper function called by printTrie(). (Credit: Dr. S.)
void printTrieHelper(TrieNode *root, char *buffer, int k)
{
	int i;

	if (root == NULL)
		return;

	if (root->count > 0)
		printf("%s (%d)\n", buffer, root->count);

	buffer[k + 1] = '\0';

	for (i = 0; i < 26; i++)
	{
		buffer[k] = 'a' + i;

		printTrieHelper(root->children[i], buffer, k + 1);
	}

	buffer[k] = '\0';
}

// If printing a subtrie, the second parameter should be 1; otherwise, if
// printing the main trie, the second parameter should be 0. (Credit: Dr. S.)
void printTrie(TrieNode *root, int useSubtrieFormatting)
{
	char buffer[1026];

	if (useSubtrieFormatting)
	{
		strcpy(buffer, "- ");
		printTrieHelper(root, buffer, 2);
	}
	else
	{
		strcpy(buffer, "");
		printTrieHelper(root, buffer, 0);
	}
}

// This function prints the contents of the subtrie for the passed word
void printSubtrie(TrieNode *root, char *str)
{
	int i;
	int len = strlen(str);
	TrieNode *node;
	
	printf("%s\n", str);
	
	if (!containsWord(root, str))
	{
		printf("(INVALID STRING)\n");
		return;
	}
	
	node = getNode(root, str);
	
	if (node->subtrie == NULL)
	{
		printf("(EMPTY)\n");
		return;
	}
	
	printTrie(node->subtrie, 1);
}