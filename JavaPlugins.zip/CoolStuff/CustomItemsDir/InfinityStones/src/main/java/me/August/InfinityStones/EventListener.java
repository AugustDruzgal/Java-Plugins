package me.August.InfinityStones;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Scoreboard;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;

import me.August.CustomItems.CustomItemManager;

public class EventListener implements Listener {
	
	private static HashMap<Location, Double> containers = new HashMap<>();
	private static Plugin plugin;
	
	public EventListener(Plugin plugin)
	{
		EventListener.plugin = plugin;
	}
	
	public static void protectLocation(Location loc, double radius, int duration)
	{
		containers.put(loc, radius);
		new BukkitRunnable()
		{
			@Override
			public void run()
			{
				containers.remove(loc);
			}
		}.runTaskLater(plugin, duration);
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e)
	{
		Player player = e.getPlayer();
		Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
		player.getInventory().addItem(CustomItemManager.getCustomItem("power").getItemStack());
		scoreboard.getTeam("players").addEntry(player.getName());
	}
	
	@EventHandler
	public void onFlow(BlockFromToEvent e)
	{
		for (Location loc:containers.keySet())
		{
			if (e.getBlock().getWorld() != loc.getWorld())
				continue;
			if (e.getBlock().getLocation().distance(loc) < containers.get(loc) ||
					e.getToBlock().getLocation().distance(loc) < containers.get(loc))
				e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onSpawn(EntityAddToWorldEvent e)
	{
		Entity entity = e.getEntity();
		Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
		if (entity instanceof Monster)
			scoreboard.getTeam("monsters").addEntity(entity);
		else if (entity instanceof Animals)
			scoreboard.getTeam("animals").addEntity(entity);
		else if (entity instanceof Boss)
			scoreboard.getTeam("bosses").addEntity(entity);
		else if (!(entity instanceof LivingEntity))
			scoreboard.getTeam("nonliving").addEntity(entity);
		else
			scoreboard.getTeam("generic").addEntity(entity);
	}

}
