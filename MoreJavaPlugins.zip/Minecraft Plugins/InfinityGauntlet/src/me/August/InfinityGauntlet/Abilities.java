package me.August.InfinityGauntlet;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Abilities {
	
	public static ItemStack powerblast() {
		ItemStack item = new ItemStack(Material.AMETHYST_SHARD, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + "Power Blast");
		meta.setCustomModelData(2);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack powerwave() {
		ItemStack item = new ItemStack(Material.AMETHYST_SHARD, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + "Power Wave");
		meta.setCustomModelData(3);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack timewarp() {
		ItemStack item = new ItemStack(Material.EMERALD, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.GREEN + "" + "Time Warp");
		meta.setCustomModelData(2);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack timeblast() {
		ItemStack item = new ItemStack(Material.EMERALD, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.GREEN + "" + "Time Blast");
		meta.setCustomModelData(3);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack spacestrike() {
		ItemStack item = new ItemStack(Material.DIAMOND, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.BLUE + "" + "Meteor Strike");
		meta.setCustomModelData(2);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack spacewarp() {
		ItemStack item = new ItemStack(Material.DIAMOND, 1);
		ItemMeta meta = item.getItemMeta();
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.setDisplayName(ChatColor.BLUE + "" + "Teleport");
		meta.setCustomModelData(3);
		item.setItemMeta(meta);
		return item;
	}

}
