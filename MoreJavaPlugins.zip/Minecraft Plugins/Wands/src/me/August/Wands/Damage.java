package me.August.Wands;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class Damage extends BoltSpell{
	
	Damage(Player p, Plugin pl) {
		super(p, pl);
		// TODO Auto-generated constructor stub
		
		setIcons(Material.SPIDER_EYE, 1, Material.SPIDER_EYE, 2);
		setMaxCooldown(50);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
	}
	
	@Override
	public void castEffect(Location loc) {
		
		loc.getWorld().playSound(loc, Sound.ENTITY_WITCH_THROW, 1, 2F);
		
	}
	
	@Override
	public void hitEffect(LivingEntity entity, Location loc) {
		
		entity.damage(2);
		entity.setVelocity(loc.getDirection().clone().normalize().add(new Vector(0,0.3,0)).normalize().multiply(0.9));
		
		entity.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1, 1.5F);
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 1, 1);
		
		loc.getWorld().spawnParticle(Particle.BLOCK_DUST, loc, 20, 0.3, 0.3, 0.3, 1, Material.NETHER_BRICKS.createBlockData(), true);
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 10, 0.2, 0.2, 0.2, 1, new DustOptions(Color.RED, 1), true);
		
	}
	
	@Override
	public void spellParticle(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 1, new DustOptions(Color.RED, 1), true);
		
	}
	
	@Override
	public void hitGroundEffect(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.BLOCK_DUST, loc, 20, 0.3, 0.3, 0.3, 1, Material.NETHER_BRICKS.createBlockData(), true);
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 10, 0.2, 0.2, 0.2, 1, new DustOptions(Color.RED, 1), true);
		
	}

}
