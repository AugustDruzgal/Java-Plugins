package me.August.Abilities.Ice;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.ParticleProjectile;
import me.August.Abilities.Util.Skill;

public class FrostBolt extends Skill {

	public FrostBolt(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() < 70)
		{
			return;
		}
		manager.removeMana(70);
		startCooldown(70, true);
		Location location = player.getLocation().clone();
		location = location.add(new Vector(0, 1, 0));
		location = location.add(location.getDirection().clone().multiply(0.75));
		DustOptions color = new DustOptions(Color.AQUA, 1);
		
		new ParticleProjectile(location, location.getDirection(), player, plugin) {
			
			@Override
			public void moveParticle(Location loc, int time) {
				loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 1, 0, 0, 0, 1, Material.BLUE_ICE.createBlockData(), true);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0, color, true);
			}
			
			@Override
			public void impactParticle(Location loc) {
				loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 20, 0.6, 0.6, 0.6, 1, Material.BLUE_ICE.createBlockData(), true);
				loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 20, 0.6, 0.6, 0.6, 0, color, true);
			}
			
			@Override
			public void hitEffect(LivingEntity entity) {
				entity.setNoDamageTicks(0);
				entity.damage(5);
				entity.setVelocity(this.getDirection().setY(0.3).multiply(0.5));
				entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 70, 2));
			}
			
			@Override
			public void castParticle(Location loc) {
				loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 25, 0.5, 0.5, 0.5, 1, Material.BLUE_ICE.createBlockData(), true);
			}
		}.setCurve(true, 0.03, 50).setSpeed(1).setLifetime(100).start();
	}

}
