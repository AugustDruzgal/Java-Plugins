package me.August.InfinityGauntlet;

import java.util.ArrayList;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class PowerBlast {
	
	ArrayList<LivingEntity> hitEntities;
	Player player;
	int amount;
	
	PowerBlast(Player p, Plugin plugin) {
		
		player = p;
		hitEntities = new ArrayList<LivingEntity>();
		
		new BukkitRunnable() {
			
			Location loc;
			Location loc1;
			Vector dir;
			int timer = 0;
			
			@Override
			public void run() {
				loc = player.getLocation().clone().add(new Vector(0,1.3,0));
				loc1 = loc.clone();
				dir = loc.getDirection().normalize().multiply(0.25);
				
				for(int i = 0 ; i < 300 ; i++) {
					loc.add(dir);
					hit(loc);
					if (!loc.getBlock().isPassable()) {
						
						amount = i;
						
						new BukkitRunnable() {
							
							int timer = 0;
							
							@Override
							public void run() {
								electricparticle(loc1, amount*0.25F);
								timer++;
								if(timer > 3) {cancel();}
							}
							
						}.runTaskTimer(plugin, 0, 1);
						
						i = 69420;
						if(timer%1 == 0) {
							loc.getWorld().createExplosion(loc.clone().subtract(dir), 3);
						}
					}
					if (i == 399) {
						
						amount = i;
						
						new BukkitRunnable() {
							
							int timer = 0;
							
							@Override
							public void run() {
								electricparticle(loc1, amount*0.25F);
								timer++;
								if(timer > 3) {cancel();}
							}
							
						}.runTaskTimer(plugin, 0, 1);
					}
				}
				timer++;
				if (timer%1 == 0) {
					hitEntities = new ArrayList<LivingEntity>();
				}
				
				if (timer > 0) {
					cancel();
				}
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void hit(Location loc) {
		for(LivingEntity entity : player.getWorld().getLivingEntities()) {
			if(entity.getLocation().clone().add(new Vector(0,1,0)).distance(loc) < 1 && !hitEntities.contains(entity) && entity != player) {
				entity.damage(5);
				entity.setVelocity(loc.getDirection().clone().add(new Vector(0,0.5,0)).normalize().multiply(3));
				hitEntities.add(entity);
			}
		}
	}
	
	public void electricparticle(Location l, float blocks) {
		Location loc = l.clone();
		Vector dir = loc.getDirection().clone().normalize().multiply(0.25);
		Vector offset1 = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.2).rotateAroundNonUnitAxis(loc.getDirection(), Math.PI * 2 * Math.random());
		Vector offset2 = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.2).rotateAroundNonUnitAxis(loc.getDirection(), Math.PI * 2 * Math.random());
		Location offset1loc = loc.clone().add(offset1);
		Location offset2loc = loc.clone().add(dir).add(offset2);
		Location offset12loc;
		for(int i = 0; i < (4 * blocks) ; i++) {
			offset1 = offset2;
			offset2 = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2).multiply(0.3).rotateAroundNonUnitAxis(loc.getDirection(), Math.PI * 2 * Math.random());
			offset1loc = loc.clone().add(offset1);
			offset2loc = loc.clone().add(dir).add(offset2);
			loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 10, 0.02, 0.02, 0.02, 0.1, new DustOptions(Color.WHITE, 0.35F), true);
			for(int j = 0 ; j < 20 ; j++) {
				offset12loc = offset1loc.clone().add(offset1loc.clone().subtract(offset2loc).multiply(-j*0.05).toVector());
				loc.getWorld().spawnParticle(Particle.REDSTONE, offset12loc, 1, 0, 0, 0, 0.1, new DustOptions(Color.PURPLE, 0.25F), true);
			}
			loc.add(dir);
		}
	}
}
