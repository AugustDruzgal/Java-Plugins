package me.August.Wands;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class Poison extends BoltSpell {

	Poison(Player p, Plugin pl) {
		super(p, pl);
		// TODO Auto-generated constructor stub
		
		setIcons(Material.SLIME_BALL, 1, Material.SLIME_BALL, 2);
		setMaxCooldown(120);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
	}
	
	@Override
	public void castEffect(Location loc) {
		
		loc.getWorld().playSound(loc, Sound.ENTITY_SLIME_JUMP, 1, 2F);
		
	}
	
	@Override
	public void hitEffect(LivingEntity entity, Location loc) {
		
		entity.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, 100, 4));
		entity.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 100, 2));
		entity.setVelocity(loc.getDirection().clone().normalize().add(new Vector(0,0.3,0)).normalize().multiply(0.9));
		
		entity.getWorld().playSound(loc, Sound.BLOCK_SLIME_BLOCK_BREAK, 1, 1.5F);
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 1, 1);
		
		loc.getWorld().spawnParticle(Particle.BLOCK_DUST, loc, 20, 0.3, 0.3, 0.3, 1, Material.SLIME_BLOCK.createBlockData(), true);
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 10, 0.2, 0.2, 0.2, 1, new DustOptions(Color.GREEN, 1), true);
		
	}
	
	@Override
	public void spellParticle(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.BLOCK_DUST, loc, 1, 0, 0, 0, 1, Material.SLIME_BLOCK.createBlockData(), true);
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 1, new DustOptions(Color.GREEN, 1), true);
		
	}
	
	@Override
	public void hitGroundEffect(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.BLOCK_DUST, loc, 20, 0.3, 0.3, 0.3, 1, Material.SLIME_BLOCK.createBlockData(), true);
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 10, 0.2, 0.2, 0.2, 1, new DustOptions(Color.GREEN, 1), true);
		
	}

}
