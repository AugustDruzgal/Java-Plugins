// August Druzgal au907615
// COP 3502C Spring Semester

#include "LonelyPartyArray.h"
#include <stdio.h>
#include <stdlib.h>


// Function prototype for printall()
void printall(LPA *party);


// This function creates an empty LPA with the specified number of fragments and fragment lengths.
LonelyPartyArray *createLonelyPartyArray(int num_fragments, int fragment_length)
{
	int i;
	
	if (num_fragments <= 0 || fragment_length <= 0)
		return NULL;
	
	// allocate memory and set up base values for LPA variables
	LPA *newLPA = malloc(sizeof(LPA));
	
	if (newLPA == NULL)
		return NULL;
	
	newLPA->size = 0;
	newLPA->num_fragments = num_fragments;
	newLPA->fragment_length = fragment_length;
	newLPA->num_active_fragments = 0;
	
	// allocate memory for arrays stored within the LPA, and free allocated memory if this fails
	newLPA->fragments = malloc(sizeof(int *) * num_fragments);
	if (newLPA->fragments == NULL)
	{
		free(newLPA);
		return NULL;
	}
	
	newLPA->fragment_sizes = malloc(sizeof(int) * num_fragments);
	if (newLPA->fragment_sizes == NULL) 
	{
		free(newLPA->fragments);
		free(newLPA);
		return NULL;
	}
	
	for (i = 0; i < newLPA->num_fragments; i++)
	{
		newLPA->fragments[i] = NULL;
		newLPA->fragment_sizes[i] = 0;
	}
	
	printf("-> A new LonelyPartyArray has emerged from the void. (capacity: ");
	printf("%d", (newLPA->num_fragments * newLPA->fragment_length));
	printf(", fragments: %d)\n", newLPA->num_fragments);
	return newLPA;
}

// This function deletes and deallocates all malloc'ed memory relating to the provided LPA.  
LonelyPartyArray *destroyLonelyPartyArray(LonelyPartyArray *party)
{
	int i;
	
	if (party == NULL)
		return NULL;
	
	// deallocate all allocated fragments in party->fragments
	for (i = 0; i < party->num_fragments; i++)
	{
		if (party->fragments[i] != NULL)
		{
			free(party->fragments[i]);
			party->fragments[i] = NULL;
		}
	}
	
	// deallocate all allocated memory in the LPA
	free(party->fragments);
	free(party->fragment_sizes);
	free(party);
	
	printf("-> The LonelyPartyArray has returned to the void.\n");
	return NULL;
}

// This function sets a specific index in the target LPA to the provided value, if able.
int set(LonelyPartyArray *party, int index, int key)
{
	int i, fragment, fragment_index;
	
	// check if the LPA pointer and index are valid
	if (party == NULL)
	{
		printf("-> Bloop! NULL pointer detected in set().\n");
		return LPA_FAILURE;
	} else if (party->num_fragments * party->fragment_length <= index || index < 0)
	{
		printf("-> Bloop! Invalid access in set(). (index: ");
		printf("%d, fragment: %d,", index, index/party->fragment_length);
		printf(" offset: %d)\n", index%party->fragment_length);
		return LPA_FAILURE;
	}
	
	fragment = index / party->fragment_length;
	fragment_index = index % party->fragment_length;
	
	// if the fragment that houses the target index isn't allocated, allocate memory for it
	if (party->fragments[fragment] == NULL)
	{
		party->fragments[fragment] = malloc(sizeof(int) * party->fragment_length);
		if (party->fragments[fragment] == NULL)
			return LPA_FAILURE;
		
		for (i = 0; i < party->fragment_length; i++) 
			party->fragments[fragment][i] = UNUSED;
		party->num_active_fragments++;
		printf("-> Spawned fragment %d. (capacity: %d, ", fragment, party->fragment_length);
		printf("indices: %d..", fragment*party->fragment_length);
		printf("%d)\n", fragment*party->fragment_length + (party->fragment_length - 1));
	}
	
	// set the value of the index to the key, and increase the size values of the LPA if necessary
	if (party->fragments[fragment][fragment_index] == UNUSED)
	{
		party->fragment_sizes[fragment]++;
		party->size++;
	}
	party->fragments[fragment][fragment_index] = key;
	
	
	return LPA_SUCCESS;
}

// This function retrieves the value from a specific index in the target LPA, if able.
int get(LonelyPartyArray *party, int index)
{
	int fragment, fragment_index;
	
	// check if the index is and LPA pointer are valid
	if (party == NULL)
	{
		printf("-> Bloop! NULL pointer detected in get().\n");
		return LPA_FAILURE;
	} else if (index >= party->fragment_length * party->num_fragments || index < 0)
	{
		printf("-> Bloop! Invalid access in get(). (index: %d, fragment: ", index);
		printf("%d, offset: %d)\n", index / party->fragment_length, index % party->fragment_length);
		return LPA_FAILURE;
	}
	
	fragment = index / party->fragment_length;
	fragment_index = index % party->fragment_length;
	
	// return the value at the index, or unused if the index is not allocated
	if (party->fragments[fragment] != NULL)
		return party->fragments[fragment][fragment_index];
	else
		return UNUSED;
	
	return LPA_FAILURE;
}

// This function deletes the value from a specific index in the target LPA, if able.
int delete(LonelyPartyArray *party, int index)
{
	int i, fragment, fragment_index;
	
	// check if the LPA pointer and index is valid
	if (party == NULL)
	{
		printf("-> Bloop! NULL pointer detected in delete().\n");
		return LPA_FAILURE;
	}
	
	fragment = index / party->fragment_length;
	fragment_index = index % party->fragment_length;
	
	if (party->num_fragments * party->fragment_length <= index || index < 0)
	{
		printf("-> Bloop! Invalid access in delete(). (index: %d", index);
		printf(", fragment: %d, offset: %d)\n", fragment, fragment_index);
		return LPA_FAILURE;
	}
	
	// check if the index is in use
	if (party->fragments[fragment] == NULL)
		return LPA_FAILURE;
	
	if (party->fragments[fragment][fragment_index] == UNUSED)
		return LPA_FAILURE;

	// set the index to unused, then deallocate the accessed fragment if it is empty
	party->fragments[fragment][fragment_index] = UNUSED;
	party->fragment_sizes[fragment]--;
	party->size--;
	
	if (party->fragment_sizes[fragment] == 0)
	{
		free(party->fragments[fragment]);
		party->fragments[fragment] = NULL;
		party->num_active_fragments--;
		printf("-> Deallocated fragment %d. (capacity: %d, ", fragment, party->fragment_length);
		printf("indices: %d..%d)\n", fragment*party->fragment_length, fragment*party->fragment_length + (party->fragment_length - 1));
	}
	return LPA_SUCCESS;
}

// This function iterates through the target LPA and checks if it contains the specified value.
int containsKey(LonelyPartyArray *party, int key)
{
	int i, j;
	// check if the LPA pointer is valid
	if (party == NULL)
		return 0;
	// check every value in the LPA to see if it equals the key
	for (i = 0; i < party->num_fragments; i++)
		if (party->fragment_sizes[i] != 0)
			for (j = 0; j < party->fragment_length; j++)
				if (party->fragments[i][j] == key)
					return 1;
	return 0;
}

// This function checks if the specified index contains a value, or it it is unused.
int isSet(LonelyPartyArray *party, int index)
{
	int fragment, fragment_index;
	
	// check the validity of the LPA pointer and index
	if (party == NULL)
		return 0;
	if (index >= party->fragment_length * party->num_fragments)
		return 0;
	
	fragment = index / party->fragment_length;
	fragment_index = index % party->fragment_length;
	
	// return 1 if the fragment is in use, 0 if not
	if (party->fragments[fragment] == NULL)
		return 0;
	if (party->fragments[fragment][fragment_index] == UNUSED)
		return 0;
	return 1;
}

// If there is a valid integer in the specified index, this function prints it to the screen.
int printIfValid(LonelyPartyArray *party, int index)
{
	int fragment, fragment_index;
	
	// check the validity of the LPA pointer and index
	if (party == NULL)
		return LPA_FAILURE;
	
	fragment = index / party->fragment_length;
	fragment_index = index % party->fragment_length;
	
	if (index >= party->fragment_length * party->num_fragments || index < 0)
		return LPA_FAILURE;
	
	// if the index is in use, print it
	if (party->fragments[fragment] == NULL)
		return LPA_FAILURE;
	if (party->fragments[fragment][fragment_index] != UNUSED)
	{
		printf("%d\n", party->fragments[fragment][fragment_index]);
		return LPA_SUCCESS;
	}
	return LPA_FAILURE;
}

// This function resets the target LPA to its empty base state.
LonelyPartyArray *resetLonelyPartyArray(LonelyPartyArray *party)
{
	int i;
	
	// check the validity of the LPA pointer
	if (party == NULL)
	{
		printf("-> Bloop! NULL pointer detected in resetLonelyPartyArray().");
		return party;
	}
	
	// free all fragments and set all related LPA variables to 0
	for (i = 0; i < party->num_fragments; i++)
		if (party->fragments[i] != NULL)
		{
			party->fragment_sizes[i] = 0;
			free(party->fragments[i]);
			party->fragments[i] = NULL;
		}
		
	party->num_active_fragments = 0;
	party->size = 0;
	printf("-> The LonelyPartyArray has returned to its nascent state. (capacity: ");
	printf("%d, fragments: %d)\n", party->num_fragments * party->fragment_length, party->num_fragments);
	
	return party;
}

// This function returns the total amount of integers currently stored in the target LPA.
int getSize(LonelyPartyArray *party)
{
	if (party == NULL)
		return -1;
	return party->size;
}

// This function returns the total amount of integers that can be stored in the target LPA.
int getCapacity(LonelyPartyArray *party)
{
	if (party == NULL)
		return -1;
	return (party->num_fragments * party->fragment_length);
}

// This function returns the total amount of integers that can be stored in the currently allocated
// portions of the target LPA's memory.
int getAllocatedCellCount(LonelyPartyArray *party)
{
	if (party == NULL)
		return -1;
	return (party->num_active_fragments * party->fragment_length);
}

// This function returns the byte size of an array of equivalent volume to the target LPA.
long long unsigned int getArraySizeInBytes(LonelyPartyArray *party)
{
	if (party == NULL)
		return 0;
	return (party->fragment_length * party->num_fragments * sizeof(int));
}

// This function returns the byte size of the target LPA, including all allocated memory.
long long unsigned int getCurrentSizeInBytes(LonelyPartyArray *party)
{
	int i, j;
	long long unsigned int bytes = 0;
	
	// check the validity of the LPA pointer
	if (party == NULL)
		return 0;
	
	// count the total byte size of the LPA by counting the size of all allocated memory
	bytes += sizeof(party);
	bytes += sizeof(party->size);
	bytes += sizeof(party->num_active_fragments);
	bytes += sizeof(party->fragment_length);
	bytes += sizeof(party->num_fragments);
	bytes += sizeof(party->fragments);
	bytes += sizeof(party->fragment_sizes);
	
	for (i = 0; i < party->num_fragments; i++)
	{
		bytes += sizeof(party->fragments[i]);
		bytes += sizeof(party->fragment_sizes[i]);
		if (party->fragments[i] != NULL)
			for (j = 0; j < party->fragment_length; j++)
				bytes += sizeof(party->fragments[i][j]);
	}
	
	return bytes;
}

// This function returns my difficulty rating for this assignment.
double difficultyRating(void)
{
	return 3;
}

// This function returns my estimate of my hours spent on this assignment. 
double hoursSpent(void)
{
	return 6;
}

// This function clones the target LPA and returns a pointer to the newly initialized clone.
LonelyPartyArray *cloneLonelyPartyArray(LonelyPartyArray *party)
{
	int i, value;
	
	// check the validity of the LPA pointer
	if (party == NULL)
		return NULL;
	
	// allocate memory and initialize base variables for the new LPA
	LPA *newLPA = malloc(sizeof(LPA));
	
	if (newLPA == NULL)
		return NULL;
	
	newLPA->num_fragments = party->num_fragments;
	newLPA->fragment_length = party->fragment_length;
	newLPA->num_active_fragments = 0;
	newLPA->size = 0;
	
	// if any memory allocation fails, free all allocated memory and end the function
	newLPA->fragments = malloc(sizeof(int *) * newLPA->num_fragments);
	if (newLPA->fragments == NULL)
	{
		free(newLPA);
		return NULL;
	}
	
	newLPA->fragment_sizes = malloc(sizeof(int) * newLPA->num_fragments);
	if (newLPA->fragment_sizes == NULL) 
	{
		free(newLPA->fragments);
		free(newLPA);
		return NULL;
	}
	
	for (i = 0; i < newLPA->num_fragments; i++)
	{
		newLPA->fragments[i] = NULL;
		newLPA->fragment_sizes[i] = 0;
	}
	
	// clone all values from the source LPA to the new LPA
	for (i = 0; i < newLPA->num_fragments * newLPA->fragment_length; i++)
	{
		value = get(party, i);
		if (value != UNUSED)
			set(newLPA, i, value);
	}
	
	printf("-> Successfully cloned the LonelyPartyArray. (capacity: ");
	printf("%d", newLPA->num_fragments * newLPA->fragment_length);
	printf(", fragments: %d)", newLPA->num_fragments);
	
	return newLPA;
	
}
// This function prints a basic visualization of the LPA, for debugging purposes. The visualization
// includes the allocation state of each fragment, the total number of active fragments, and the 
// total amount of integers stored in the LPA. 
void printall(LPA *party) 
{	
	int i, j;
	
	// print a cool and intuitive grid to represent the target LPA, Szumlanski style!
	printf("+");
	for (i = 0; i < party->fragment_length - 1; i++)
		printf("--------");
	printf("-------+\n");
	for (i = 0; i < party->num_fragments; i++)
	{
		if (party->fragment_sizes[i] > 0)
		{
			printf("[");
			for (j = 0; j < party->fragment_length; j++)
				if (party->fragments[i][j] == UNUSED)
					printf("UNUSED\t");
				else
					printf("%d\t", party->fragments[i][j]);
			printf("] - %p\tSize:%d\n", party->fragments[i], party->fragment_sizes[i]);
		} else {
			printf("[");
			for (j = 0; j < party->fragment_length; j++)
				printf("UNUSED\t");
			printf("] - Uninitialized\tSize:%d\n", party->fragment_sizes[i]);
		}
	}
	printf("+");
	for (i = 0; i < party->fragment_length - 1; i++)
		printf("--------");
	printf("-------+\n");
	// print some variable data from the target LPA
	printf("active fragments: %d, size: %d\n", party->num_active_fragments, party->size);
}
