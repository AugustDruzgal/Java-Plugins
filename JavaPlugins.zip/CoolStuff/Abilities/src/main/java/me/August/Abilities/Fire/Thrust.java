package me.August.Abilities.Fire;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.Abilities.Main;
import me.August.Abilities.ManaManager;
import me.August.Abilities.Util.Skill;

public class Thrust extends Skill {

	public Thrust(Player p, Plugin pl) {
		super(p, pl);
		setAcceptable(getSwords());
	}
	
	@Override
	public void effect(int level)
	{
		ManaManager manager = Main.getManager(player).getManaManager();
		if (manager.getMana() >= 15)
		{
			new BukkitRunnable()
			{
				int time = 0;
				@Override
				public void run()
				{
					boost();
					time++;
					manager.removeMana(4);
					manager.setPause(1);
					if (time > 4)
						cancel();
				}
			}.runTaskTimer(plugin, 0, 1);
		}
	}
	
	private void boost()
	{
		Vector offset;
		Location loc = player.getLocation().clone();
		Vector dir = loc.getDirection();
		player.setVelocity(dir.clone().normalize().multiply(0.65));
		for (int i = 0; i < 10; i++)
		{
			loc = player.getLocation().clone();
			offset = Vector.getRandom().subtract(new Vector(0.5, 0.5, 0.5)).normalize().multiply(0.8);
			player.getWorld().spawnParticle(Particle.FLAME, loc.add(offset), 0, dir.getX() * -1, dir.getY() * -1, dir.getZ() * -1, 0.8, null, true);
		}
		hit();
		loc = player.getLocation().clone().add(new Vector(0, 1, 0));
		player.getWorld().spawnParticle(Particle.LAVA, loc, 2, 1.5, 1.5, 1.5, 1, null, true);
		player.setFallDistance(0);
	}
	
	private void hit()
	{
		Location loc = player.getLocation().clone();
		for (LivingEntity entity:player.getWorld().getLivingEntities())
		{
			if (entity != player && loc.toVector().distance(entity.getLocation().toVector()) < 2.5)
			{
				entity.damage(1.5);
				entity.setFireTicks(entity.getFireTicks() + 20);
				entity.setVelocity(player.getVelocity().clone().setY(0).normalize().setY(0.2).multiply(1.4));
				player.setVelocity(player.getVelocity().clone().normalize().multiply(0.5));
			}
		}
	}

}
