package me.August.InfinityStones;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class SoulStone extends Stone {

	SoulStone(Plugin pl) {
		super(pl);
		name = "Soul Stone";
		color = Color.fromRGB(225, 255, 100);
		time = 200;
	}
	
	@Override
	public void p()
	{
		
	}
	
	@Override
	public void a()
	{
		
	}
	
	@Override
	public ItemStack createItem()
	{
		ItemStack new_item = new ItemStack(Material.AMETHYST_SHARD);
		
		ItemMeta meta = new_item.getItemMeta();
		TextComponent name = Component.text("soul stone").color(TextColor.color(225, 255, 100));
		meta.displayName(name);
		meta.setCustomModelData(7);
		new_item.setItemMeta(meta);
		
		return new_item;
	}

}
