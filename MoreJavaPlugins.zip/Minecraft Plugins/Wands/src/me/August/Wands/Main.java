package me.August.Wands;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener {

	static HashMap<Player, WandManager> wandManagers = new HashMap<Player, WandManager>();
	
	@Override
	public void onEnable() {
		Bukkit.getPluginManager().registerEvents(this, this);
		for(Player player:Bukkit.getOnlinePlayers()) {
			wandManagers.put(player, new WandManager(player, this));
			if (!player.getInventory().contains(createWand())) {
				player.getInventory().addItem(createWand());
			}
		}
	}
	
	@Override
	public void onDisable() {
		for(Player player:Bukkit.getOnlinePlayers()) {
			if(wandManagers.containsKey(player)) {
				if(wandManagers.get(player).isActive()) {
					wandManagers.get(player).activateWand();
				}
			}
		}
	}
	
	@EventHandler
	public void onJoin(PlayerLoginEvent e) {
		Player player = e.getPlayer();
		if (wandManagers.get(player) == null) {
			wandManagers.put(player, new WandManager(player, this));
		}
		if (!player.getInventory().contains(createWand())) {
			player.getInventory().addItem(createWand());
		}
	}
	
	@EventHandler
	public void onLeave(PlayerQuitEvent e) {
		Player player = e.getPlayer();
		if (wandManagers.get(player).isActive()) {
			wandManagers.get(player).activateWand();
		}
	}
	
	@EventHandler
	public void onActivate(PlayerInteractEvent e) {
		Player player = e.getPlayer();
		
		if (e.getAction() == Action.RIGHT_CLICK_AIR && player.getInventory().getItemInMainHand().isSimilar(createWand())) {
			player.getWorld().playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1F, 1.2F);
			wandManagers.get(player).activateWand();
		}
	}
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent e) {
		
		if (wandManagers.get(e.getPlayer()).isActive()) {
			
			e.setCancelled(true);
			
		}
		
	}
	
	@EventHandler
	public void onPickUp(EntityPickupItemEvent e) {
		
		if (wandManagers.containsKey(e.getEntity())) {
		
			if (wandManagers.get(e.getEntity()).isActive()) {
			
				e.setCancelled(true);
			
			}
		
		}
		
	}
	
	public static ItemStack createWand() {
		ItemStack wand = new ItemStack(Material.STICK, 1);
		ItemMeta wandmeta = wand.getItemMeta();
		wandmeta.setDisplayName(ChatColor.AQUA + "Wand");
		wand.setItemMeta(wandmeta);
		
		return wand;
	}
	
}
