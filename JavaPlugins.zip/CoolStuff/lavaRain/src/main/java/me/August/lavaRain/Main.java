package me.August.lavaRain;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.weather.LightningStrikeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Main extends JavaPlugin implements Listener {
	
	int active = 0;
	
	@Override
	public void onEnable()
	{
		Bukkit.getPluginManager().registerEvents(this, this);
		active = 1;
		new BukkitRunnable()
		{
			List<LivingEntity> entities = new ArrayList<LivingEntity>();
			@Override
			public void run()
			{
				if (active == 0)
					cancel();
				for (World world:Bukkit.getWorlds())
				{
					if (world.hasStorm())
					{
						entities = world.getLivingEntities();
						for (LivingEntity entity:entities)
						{
							if (canSeeSky(entity))
								if (entity.getLocation().getBlock().getTemperature() < 0.15)
									if (entity.getFreezeTicks() > 500)
										entity.setFreezeTicks(500);
									else
										entity.setFreezeTicks(entity.getFreezeTicks() + 4);
								else if (entity.getLocation().getBlock().getTemperature() < 0.95)
									entity.setFireTicks(20);
						}
					}
				}
			}
		}.runTaskTimer(this, 0, 1);
	}
	
	@Override
	public void onDisable()
	{
		active = 0;
	}
	
	@EventHandler
	public void onWeatherChange(WeatherChangeEvent e)
	{
		if (e.toWeatherState() == true)
			e.getWorld().setWeatherDuration(1200);
		else
			e.getWorld().setWeatherDuration((int) (1200 + Math.round(Math.random() * 10800)));
	}
	
	@EventHandler
	public void onLightning(LightningStrikeEvent e)
	{
		e.getWorld().createExplosion(e.getLightning().getLocation().clone().add(new Vector(0, -1, 0)), 4, true);
	}
	
	private boolean canSeeSky(LivingEntity e)
	{
		Location loc = e.getLocation().clone().add(new Vector(0, e.getHeight() - 0.2, 0));
		while (loc.getY() <= 320)
		{
			if(!loc.getBlock().isPassable())
				return false;
			loc.add(new Vector(0, 1, 0));
		}
		return true;
	}
}
