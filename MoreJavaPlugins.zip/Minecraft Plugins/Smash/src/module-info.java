module Smash {
	requires spigot;
}