package me.August.InfinityStones;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import me.August.CustomItems.AbilityEffect;
import me.August.CustomItems.AbilityItem;
import me.August.CustomItems.CustomItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;

public class PowerStone implements Utils {
	
	private static ItemStack stoneItem;
	private static ItemStack blastItem;
	private static ItemStack pulseItem;
	private static ItemStack detonateItem;
	private static Plugin plugin;
	
	public static void initPowerStone(Plugin plugin)
	{
		PowerStone.plugin = plugin;
		initItems();
		createAbilities();
		createStoneItem();
	}
	
	private static void initItems()
	{
		ItemStack item;
		ItemMeta meta;
		List<Component> lore;
		TextComponent name;
		TextColor nameColor = TextColor.color(255, 140, 255);
		TextColor loreColor = TextColor.color(200, 0, 200);
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Power Stone").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("A stone containing the").color(loreColor));
		lore.add(Component.text("essence of power").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		stoneItem = item;
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Power Blast").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Launch an explosive blast").color(loreColor));
		lore.add(Component.text("that deals high damage").color(loreColor));
		
		meta.setCustomModelData(2);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		blastItem = item;
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Shockwave").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("Create a forceful wave").color(loreColor));
		lore.add(Component.text("that deals large knockback").color(loreColor));
		
		meta.setCustomModelData(4);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		pulseItem = item;
		
		item = new ItemStack(Material.AMETHYST_SHARD);
		meta = item.getItemMeta();
		
		name = Component.text("Detonate").color(nameColor);
		lore = new ArrayList<>();
		lore.add(Component.text("After a short delay, create").color(loreColor));
		lore.add(Component.text("a massive explosion that").color(loreColor));
		lore.add(Component.text("obliterates anything in its").color(loreColor));
		lore.add(Component.text("range").color(loreColor));
		
		meta.setCustomModelData(5);
		meta.displayName(name);
		meta.lore(lore);
		item.setItemMeta(meta);
		detonateItem = item;
	}
	
	public static void createAbilities()
	{
		new AbilityItem(blastItem, getBlastEffect()).setMaxCooldown(100);
		new AbilityItem(pulseItem, getPulseEffect()).setMaxCooldown(140);
		new AbilityItem(detonateItem, getDetonateEffect()).setMaxCooldown(200);
	}
	
	public static ArrayList<ItemStack> getAbilityItems()
	{
		ArrayList<ItemStack> items = new ArrayList<>();
		items.add(blastItem);
		items.add(pulseItem);
		items.add(detonateItem);
		return items;
	}
	
	public static void createStoneItem()
	{
		CustomItem powerStone = new CustomItem(stoneItem, "power");
		ArrayList<ItemStack> abilityItems = new ArrayList<>();
		abilityItems.add(blastItem);
		abilityItems.add(pulseItem);
		abilityItems.add(detonateItem);
		powerStone.setNumHotbars(1);
		powerStone.setAbilityItems(abilityItems);
	}
	
	private static AbilityEffect getBlastEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				player.sendMessage("boom! blasted!");
				return true;
			}
		};
	}
	
	private static AbilityEffect getPulseEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				Vector dir = player.getLocation().getDirection().clone().normalize().multiply(0.05);
				Location loc = player.getLocation().clone().add(new Vector(0, 1, 0));
				Vector offset = dir.clone().setY(0).normalize().rotateAroundY(Math.PI/2);
				BlockData data = Material.PURPLE_WOOL.createBlockData();
				double width = 0.1;
				for (int i = 0; i < 300; i++)
				{
					width += 0.02;
					loc = loc.add(dir);
					offset = offset.rotateAroundAxis(dir, Math.PI/25);
					offset.normalize().multiply(width);
					player.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc.clone().add(offset), 1, 0, 0, 0, 1, data, true);
					if ((i+1)%100 == 0)
						knockbackRadius(player, dir, loc, width + 1, 4);
				}
				return true;
			}
		};
	}
	
	private static void knockbackRadius(Player player, Vector dir, Location loc, double radius, double force)
	{
		for (LivingEntity entity:loc.getWorld().getLivingEntities())
		{
			if (entity != player && entity.getLocation().add(new Vector(0, entity.getEyeHeight(), 0)).distance(loc) < radius)
			{
				entity.setVelocity(dir.clone().normalize().add(new Vector(0, 0.2, 0)).multiply(force));
			}
		}
	}
	
	private static AbilityEffect getDetonateEffect()
	{
		return new AbilityEffect()
		{
			@Override
			public boolean effect(Player player) {
				return Utils.targetLocationAttack(player, 30, getExplosionEffect());
			}
		};
	}
	
	private static PowerEffect getExplosionEffect()
	{
		return new PowerEffect()
		{
			@Override
			boolean effect(Player player, Location loc, LivingEntity target)
			{
				new BukkitRunnable()
				{
					Random random = new Random();
					ArrayList<Location> locs = new ArrayList<>();
					DustOptions dust = new DustOptions(Color.PURPLE, 1);
					int time = 0;
					@Override
					public void run()
					{
						if (time == 0)
							for (int i = 0; i < 24; i++)
							{
								locs.add(loc.clone().add(new Vector(5 - random.nextInt(10), 7 - random.nextInt(14),  5- random.nextInt(10))));
							}
						time++;
						if (time >= 70)
						{
							player.getWorld().createExplosion(locs.get((time-70)*2), 6, true);
							loc.getWorld().spawnParticle(Particle.REDSTONE, locs.get((time-70)*2), 80, 5, 5, 5, 0.05, dust, true);
							player.getWorld().createExplosion(locs.get((time-70)*2 + 1), 6, true);
							loc.getWorld().spawnParticle(Particle.REDSTONE, locs.get((time-70)*2 + 1), 80, 5, 5, 5, 0.05, dust, true);
						}
						else
						{
							Utils.particleSphere(Particle.REDSTONE, loc, 2, 30, dust);
						}
						if (time == 81)
							cancel();
					}
				}.runTaskTimer(plugin, 0, 1);
				return true;
			}
		};
	}
}
