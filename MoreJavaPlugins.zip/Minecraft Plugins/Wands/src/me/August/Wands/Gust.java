package me.August.Wands;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Gust extends BoltSpell {

	Gust(Player p, Plugin pl) {
		
		super(p, pl);
		setIcons(Material.FEATHER, 1, Material.FEATHER, 2);
		setMaxCooldown(60);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
		
	}
		
	@Override
	public void hitEffect(LivingEntity entity, Location loc) {
		
		entity.setVelocity(loc.getDirection().clone().setY(loc.getDirection().getY() + 0.4).multiply(2.7));
		loc.getWorld().spawnParticle(Particle.CLOUD, loc, 14, 0, 0, 0, 0.33, null, true);
		player.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_CRIT, 2, 1.3F);
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 2, 1.3F);
		
	}
	
	@Override
	public void spellParticle(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.CLOUD, loc, 1, 0, 0, 0, 0, null, true);
		
	}
	
	@Override
	public void hitGroundEffect(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.CLOUD, loc, 14, 0, 0, 0, 0.33, null, true);
		loc.getWorld().playSound(loc, Sound.BLOCK_WOOL_HIT, 1F, 0.8F);
		
	}
	
	@Override
	public void castEffect(Location loc) {
		
		loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_FLAP, 1F, 2F);
		
	}

}
