package me.August.Wands;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public class WandManager {
	
	Player player;
	Plugin plugin;
	int activeInventory = 0;
	Inventory mainInv, wandInv;
	ArrayList<Spell> spells = new ArrayList<Spell>();
	
	WandManager(Player p, Plugin pl) {
		
		player = p;
		plugin = pl;
		mainInv = Bukkit.createInventory(player, InventoryType.PLAYER);
		wandInv = Bukkit.createInventory(player, InventoryType.PLAYER);
		wandInv.setItem(8, Main.createWand());
		mainInv.setItem(0, Main.createWand());
		initializeSpells();
		
		player.getInventory().setContents(mainInv.getContents());
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				
				if(activeInventory == 1) {
					
					for (Spell spell:spells) {
						
						spell.updateDisplay(spell.cooldown);
						spell.displayIcon();
						
						if (player.getInventory().getHeldItemSlot() == spell.slot) {
							
							spell.attemptCast();
							
						}
						
					}
					
					if (player.getInventory().getHeldItemSlot() != 8) {
						player.getInventory().setHeldItemSlot(8);
					}
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	public void activateWand() {
		
		activeInventory = (activeInventory+1)%2;
		
		if (activeInventory == 0) {
			wandInv.setContents(player.getInventory().getContents().clone());
			player.getInventory().setContents(mainInv.getContents().clone());
		} else {
			player.getInventory().setHeldItemSlot(8);
			mainInv.setContents(player.getInventory().getContents().clone());
			player.getInventory().setContents(wandInv.getContents().clone());
		}
		
	}
	
	public boolean isActive() {
		if (activeInventory == 0) {
			return false;
		} else {
			return true;
		}
		
	}
	
	public void setCooldowns(int cooldown) {
		for (Spell spell:spells) {
			spell.setCooldown(cooldown);
		}
	}
	
	public void initializeSpells() {
		activateWand();
		spells.add(new Firebolt(player, plugin));
		spells.add(new Fiendfire(player, plugin));
		spells.add(new Lightningbolt(player, plugin));
		spells.add(new Gust(player, plugin));
		spells.add(new Blast(player, plugin));
		spells.add(new Poison(player, plugin));
		spells.add(new Damage(player,plugin));
		spells.add(new Stun(player, plugin));
		spells.add(new Death(player, plugin));
		activateWand();
	}

}
