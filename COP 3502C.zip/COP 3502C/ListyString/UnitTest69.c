// August Druzgal
// COP 3502, Spring 2022

// =========================
// ListyString: UnitTest69.c
// =========================
// Unit test for everything NULL and empty


#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "ListyString.h"

int unit_test(int argc, char **argv)
{
	// Set up an empty string.
	ListyString *listyEMPTY = malloc(sizeof(ListyString));
	listyEMPTY->head = NULL;
	listyEMPTY->length = 0;
	
	// Set up a NULL string.
	ListyString *listyNULL = NULL;
	
	// Set up a clone string.
	ListyString *listyClone = NULL;
	
	// Test reverseListyString

	reverseListyString(listyEMPTY);
	reverseListyString(listyNULL);

	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	assert(listyNULL == NULL);
	
	free(listyEMPTY);
	
	// Test createListyString
	
	listyNULL = createListyString(NULL);
	listyEMPTY = createListyString("");
	
	assert(listyNULL != NULL);
	assert(listyNULL->head == NULL);
	assert(listyNULL->length == 0);
	
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	free(listyNULL);
	listyNULL = NULL;
	
	printf("createListyString works\n");
	fflush(stdout);
	
	// Test cloneListyString
	
	listyClone = cloneListyString(listyNULL);
	assert(listyClone == NULL);
	
	listyClone = cloneListyString(listyEMPTY);
	assert(listyClone != NULL);
	assert(listyClone->head == NULL);
	assert(listyClone->length == 0);
	
	free(listyClone);
	listyClone = NULL;
	
	printf("cloneListyString works\n");
	fflush(stdout);
	
	// Test listyCat
	// "Concatenate _____ to the end of _____"
	
	// NULL + NULL
	listyNULL = listyCat(listyNULL, NULL);
	assert(listyNULL == NULL);
	
	// NULL + EMPTY
	listyNULL = listyCat(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head == NULL);
	assert(listyNULL->length == 0);
	
	free(listyNULL);
	listyNULL = NULL;
	
	// NULL + stuff
	listyNULL = listyCat(listyNULL, "yay");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	// stuff + EMPTY
	listyNULL = listyCat(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	// stuff + NULL
	listyNULL = listyCat(listyNULL, NULL);
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	
	// EMPTY + EMPTY
	listyEMPTY = listyCat(listyEMPTY, "");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// EMPTY + NULL
	listyEMPTY = listyCat(listyEMPTY, NULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// EMPTY + stuff
	listyEMPTY = listyCat(listyEMPTY, "yay");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'y');
	assert(listyEMPTY->head->next->data == 'a');
	assert(listyEMPTY->head->next->next->data == 'y');
	assert(listyEMPTY->head->next->next->next == NULL);
	assert(listyEMPTY->length == 3);
	
	destroyListyString(listyEMPTY);
	listyEMPTY = createListyString("");
	
	printf("listyCat works\n");
	fflush(stdout);
	
	// Test listyPrepend
	// "prepend _____ with _____"
	
	// NULL + NULL
	listyNULL = listyPrepend(listyNULL, NULL);
	assert(listyNULL == NULL);
	
	// NULL + EMPTY
	listyNULL = listyPrepend(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head == NULL);
	assert(listyNULL->length == 0);
	
	free(listyNULL);
	listyNULL = NULL;
	
	// NULL + stuff
	listyNULL = listyPrepend(listyNULL, "yay");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	// stuff + EMPTY
	listyNULL = listyPrepend(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	// stuff + NULL
	listyNULL = listyPrepend(listyNULL, NULL);
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	
	// EMPTY + EMPTY
	listyEMPTY = listyPrepend(listyEMPTY, "");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// EMPTY + NULL
	listyEMPTY = listyPrepend(listyEMPTY, NULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// EMPTY + stuff
	listyEMPTY = listyPrepend(listyEMPTY, "yay");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'y');
	assert(listyEMPTY->head->next->data == 'a');
	assert(listyEMPTY->head->next->next->data == 'y');
	assert(listyEMPTY->head->next->next->next == NULL);
	assert(listyEMPTY->length == 3);
	
	destroyListyString(listyEMPTY);
	listyEMPTY = createListyString("");
	
	printf("listyPrepend works\n");
	fflush(stdout);
	
	// Test replaceChar
	// "replace ______ with ______ on ______ string"
	
	// something w/ something on NULL
	replaceChar(listyNULL, 'a', "bb");
	assert(listyNULL == NULL);
	
	// something w/ NULL on NULL
	replaceChar(listyNULL, 'a', NULL);
	assert(listyNULL == NULL);
	
	// something w/ EMPTY on NULL
	replaceChar(listyNULL, 'a', "");
	assert(listyNULL == NULL);
	
	// something w/ something on EMPTY
	replaceChar(listyEMPTY, 'a', "bb");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// something w/ NULL on EMPTY
	replaceChar(listyEMPTY, 'a', NULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// something w/ EMPTY on EMPTY
	replaceChar(listyEMPTY, 'a', "");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	listyEMPTY = listyCat(listyEMPTY, "bro");
	
	// something w/ NULL on something
	replaceChar(listyEMPTY, 'a', NULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'b');
	assert(listyEMPTY->head->next != NULL);
	assert(listyEMPTY->head->next->data == 'r');
	assert(listyEMPTY->head->next->next != NULL);
	assert(listyEMPTY->head->next->next->data == 'o');
	assert(listyEMPTY->head->next->next->next == NULL);
	assert(listyEMPTY->length == 3);
	
	// something w/ EMPTY on something (does not exist in string)
	replaceChar(listyEMPTY, 'a', "");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'b');
	assert(listyEMPTY->head->next != NULL);
	assert(listyEMPTY->head->next->data == 'r');
	assert(listyEMPTY->head->next->next != NULL);
	assert(listyEMPTY->head->next->next->data == 'o');
	assert(listyEMPTY->head->next->next->next == NULL);
	assert(listyEMPTY->length == 3);
	
	// something w/ NULL on something (exists in string)
	replaceChar(listyEMPTY, 'b', NULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'r');
	assert(listyEMPTY->head->next != NULL);
	assert(listyEMPTY->head->next->data == 'o');
	assert(listyEMPTY->head->next->next == NULL);
	assert(listyEMPTY->length == 2);
	
	listyPrepend(listyEMPTY, "b");
	
	// something w/ EMPTY on something (exists in string)
	replaceChar(listyEMPTY, 'b', "");
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'r');
	assert(listyEMPTY->head->next != NULL);
	assert(listyEMPTY->head->next->data == 'o');
	assert(listyEMPTY->head->next->next == NULL);
	assert(listyEMPTY->length == 2);
	
	destroyListyString(listyEMPTY);
	listyEMPTY = createListyString("");
	
	printf("replaceChar works\n");
	fflush(stdout);
	
	// Test listyCensor
	
	// censor characters in NULL string
	listyCensor(listyNULL, NULL);
	listyCensor(listyNULL, "");
	listyCensor(listyNULL, "a");
	listyCensor(listyNULL, "abcdef");
	
	assert(listyNULL == NULL);
	
	// censor characters in EMPTY string
	listyCensor(listyEMPTY, NULL);
	listyCensor(listyEMPTY, "");
	listyCensor(listyEMPTY, "a");
	listyCensor(listyEMPTY, "abcdef");
	
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	listyNULL = createListyString("yay");
	
	// censor NULL, EMPTY, and nonexistent characters in non-EMPTY string
	listyCensor(listyNULL, NULL);
	listyCensor(listyNULL, "");
	listyCensor(listyEMPTY, "b");
	listyCensor(listyEMPTY, "bro");
	
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	
	printf("listyCensor works\n");
	
	// Test stringWeave
	// "weave _____ listyString with _____ string"
	
	// something w/ NULL
	listyNULL = createListyString("yay");
	listyNULL = stringWeave(listyNULL, NULL);
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	// something w/ EMPTY
	listyNULL = createListyString("yay");
	listyNULL = stringWeave(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	
	// NULL w/ NULL
	listyNULL = stringWeave(listyNULL, NULL);
	assert(listyNULL == NULL);
	
	// NULL w/ EMPTY
	listyNULL = stringWeave(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head == NULL);
	assert(listyNULL->length == 0);
	
	// EMPTY w/ NULL
	listyNULL = stringWeave(listyNULL, NULL);
	assert(listyNULL != NULL);
	assert(listyNULL->head == NULL);
	assert(listyNULL->length == 0);
	
	// EMPTY w/ EMPTY
	listyNULL = stringWeave(listyNULL, "");
	assert(listyNULL != NULL);
	assert(listyNULL->head == NULL);
	assert(listyNULL->length == 0);
	
	// EMPTY w/ something
	listyNULL = stringWeave(listyNULL, "yay");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	
	// NULL w/ something
	listyNULL = stringWeave(listyNULL, "yay");
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	
	printf("stringWeave works\n");
	fflush(stdout);
	
	// Test listyWeave
	// "weave _____ listyString with _____ listyString"
	
	listyClone = NULL;
	
	// NULL w/ NULL
	listyNULL = listyWeave(listyNULL, listyClone);
	assert(listyNULL == NULL);
	assert(listyClone == NULL);
	
	// NULL w/ EMPTY
	listyNULL = listyWeave(listyNULL, listyEMPTY);
	assert(listyNULL == NULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	listyClone = createListyString("");
	
	// EMPTY w/ EMPTY
	listyEMPTY = listyWeave(listyEMPTY, listyClone);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	assert(listyClone != NULL);
	assert(listyClone->head == NULL);
	assert(listyClone->length == 0);
	
	// EMPTY w/ NULL
	listyEMPTY = listyWeave(listyEMPTY, listyNULL);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	assert(listyNULL == NULL);
	
	free(listyClone);
	listyClone = createListyString("yay");
	
	// something w/ NULL
	listyClone = listyWeave(listyClone, listyNULL);
	assert(listyClone != NULL);
	assert(listyClone->head != NULL);
	assert(listyClone->head->data == 'y');
	assert(listyClone->head->next->data == 'a');
	assert(listyClone->head->next->next->data == 'y');
	assert(listyClone->head->next->next->next == NULL);
	assert(listyClone->length == 3);
	assert(listyNULL == NULL);
	
	// something w/ EMPTY
	listyClone = listyWeave(listyClone, listyEMPTY);
	assert(listyClone != NULL);
	assert(listyClone->head != NULL);
	assert(listyClone->head->data == 'y');
	assert(listyClone->head->next->data == 'a');
	assert(listyClone->head->next->next->data == 'y');
	assert(listyClone->head->next->next->next == NULL);
	assert(listyClone->length == 3);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head == NULL);
	assert(listyEMPTY->length == 0);
	
	// NULL w/ something
	listyNULL = listyWeave(listyNULL, listyClone);
	assert(listyNULL != NULL);
	assert(listyNULL->head != NULL);
	assert(listyNULL->head->data == 'y');
	assert(listyNULL->head->next->data == 'a');
	assert(listyNULL->head->next->next->data == 'y');
	assert(listyNULL->head->next->next->next == NULL);
	assert(listyNULL->length == 3);
	assert(listyClone != NULL);
	assert(listyClone->head != NULL);
	assert(listyClone->head->data == 'y');
	assert(listyClone->head->next->data == 'a');
	assert(listyClone->head->next->next->data == 'y');
	assert(listyClone->head->next->next->next == NULL);
	assert(listyClone->length == 3);
	
	// EMPTY w/ something
	listyEMPTY = listyWeave(listyEMPTY, listyClone);
	assert(listyEMPTY != NULL);
	assert(listyEMPTY->head != NULL);
	assert(listyEMPTY->head->data == 'y');
	assert(listyEMPTY->head->next->data == 'a');
	assert(listyEMPTY->head->next->next->data == 'y');
	assert(listyEMPTY->head->next->next->next == NULL);
	assert(listyEMPTY->length == 3);
	assert(listyClone != NULL);
	assert(listyClone->head != NULL);
	assert(listyClone->head->data == 'y');
	assert(listyClone->head->next->data == 'a');
	assert(listyClone->head->next->next->data == 'y');
	assert(listyClone->head->next->next->next == NULL);
	assert(listyClone->length == 3);
	
	listyNULL = destroyListyString(listyNULL);
	listyClone = destroyListyString(listyClone);
	listyEMPTY = destroyListyString(listyEMPTY);
	listyEMPTY = createListyString("");
	
	printf("listyWeave works\n");
	fflush(stdout);
	
	// Test listyCmp
	
	listyClone = NULL;
	
	assert(listyCmp(listyNULL, listyClone) == 0);
	assert(listyCmp(listyEMPTY, listyClone) != 0);
	assert(listyCmp(listyClone, listyNULL) == 0);
	assert(listyCmp(listyClone, listyEMPTY) != 0);
	
	listyClone = createListyString("");
	
	assert(listyCmp(listyEMPTY, listyClone) == 0);
	assert(listyCmp(listyClone, listyEMPTY) == 0);
	
	listyClone = listyPrepend(listyClone, "yay");
	
	assert(listyCmp(listyClone, listyEMPTY) != 0);
	assert(listyCmp(listyEMPTY, listyClone) != 0);
	assert(listyCmp(listyClone, listyNULL) != 0);
	assert(listyCmp(listyNULL, listyClone) != 0);
	
	listyClone = destroyListyString(listyClone);

	printf("listyCmp works\n");
	fflush(stdout);
	
	// Test charCount
	
	assert(charCount(listyNULL, 'a') == -1);
	assert(charCount(listyEMPTY, 'a') == 0);
	
	printf("charCount works\n");
	fflush(stdout);
	
	// Test listyLength
	
	assert(listyLength(listyNULL) == -1);
	assert(listyLength(listyEMPTY) == 0);
	
	printf("listyLength works\n");

	printf("Hooray! You (probably) don't suck ass at CS1!\n");

	return 0;
}
