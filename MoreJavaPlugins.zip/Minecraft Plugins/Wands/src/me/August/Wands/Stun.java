package me.August.Wands;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Particle.DustOptions;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class Stun extends BoltSpell {

	Stun(Player p, Plugin pl) {
		super(p, pl);
		setIcons(Material.BLUE_DYE, 1, Material.BLUE_DYE, 2);
		setMaxCooldown(60);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
	}
	
	@Override
	public void castEffect(Location loc) {
		
		player.getWorld().playSound(loc, Sound.BLOCK_DEEPSLATE_BREAK, 1, 2F);
		
	}
	
	@Override
	public void spellParticle(Location loc, int time) {

		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0, new DustOptions(Color.BLUE, 1), true);
		loc.getWorld().spawnParticle(Particle.REDSTONE, loc, 1, 0, 0, 0, 0, new DustOptions(Color.WHITE, 0.5F), true);
		
	}
	
	@Override
	public void hitEffect(LivingEntity entity, Location loc) {
		
		entity.setVelocity(loc.getDirection().clone().setY(loc.getDirection().getY() + 0.3).multiply(0.9));
		loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 14, 0, 0, 0, 0.33, null, true);
		player.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_CRIT, 2, 1.3F);
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 2, 1.3F);
		
	}
	
	@Override
	public void hitGroundEffect(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.FIREWORKS_SPARK, loc, 14, 0, 0, 0, 0.33, null, true);
		player.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_CRIT, 2, 1.3F);
		player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 2, 1.3F);
		
	}


}
