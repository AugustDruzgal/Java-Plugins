package me.August.Superpowers;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

public class BindCommand implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) 
	{
		if (!(sender instanceof Player))
			return true;
		
		Player player = (Player) sender;
		String power = Character.toUpperCase((args[0].toCharArray())[0]) + args[0].substring(1, args[0].length()).toLowerCase();
		Integer slot = Integer.decode(args[1]);
		
		if (!Main.getPlayerPower(player).hasPower(power))
		{
			player.sendMessage(Component.text("Invalid power - " + power).color(TextColor.color(255, 50, 50)));
			return true;
		}
		
		if (slot > 8 || slot < 0)
		{
			player.sendMessage(Component.text("Invalid slot").color(TextColor.color(255, 50, 50)));
			return true;
		}
		
		player.sendMessage(Component.text("Power " + power + " bound to slot " + slot.toString() + ".").color(TextColor.color(100, 200, 255)));
		HotkeyManager.bind(player, power, slot);
		
		return true;
	}
	
}
