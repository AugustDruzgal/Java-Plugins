package me.August.OnePunch;

import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class MobLaunch {
	
	MobLaunch(LivingEntity e, Entity player, Vector dir, Plugin plugin) {
		new BukkitRunnable() {
			
			int timer = 0;
			LivingEntity entity = e;
			
			public void run() {
				timer++;
				entity.setNoDamageTicks(10);
				entity.setVelocity(dir.clone().multiply(timer));
				entity.getWorld().createExplosion(entity.getLocation(), timer-1, true);
				entity.getWorld().spawnParticle(Particle.LAVA, entity.getLocation(), timer*5, timer*0.5, timer*0.5, timer*0.5, null);
				player.getWorld().playSound(player.getLocation(), Sound.BLOCK_CALCITE_HIT, 100, (float) timer/10);
				if(timer > 30) {
					entity.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, entity.getLocation(), 2300, 10, 10, 10, null);
					cancel();
				}
			}
		}.runTaskTimer(plugin, 0, 1);
	}

}
