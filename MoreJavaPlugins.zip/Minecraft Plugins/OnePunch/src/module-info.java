module OnePunch {
	requires spigot;
}