package me.August.Wands;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class Death extends BoltSpell {

	Death(Player p, Plugin pl) {
		super(p, pl);
		setIcons(Material.WITHER_SKELETON_SKULL, 1, Material.WITHER_SKELETON_SKULL, 2);
		setMaxCooldown(200);
		player.getInventory().addItem(spellicon);
		updateDisplay(0);
	}
	
	@Override
	public void hitGroundEffect(Location loc) {
		
		new BukkitRunnable() {
		
		int timer = 0;
		Vector offset = new Vector(5, 0, 0);
			
			@Override
			public void run() {
				
				timer++;
				
				for (int i = 0 ; i < 10 ; i++) {
					
					loc.getWorld().spawnParticle(Particle.SMOKE_NORMAL, loc.clone().add(offset).add(new Vector(0, timer * 0.1, 0)), 1, 0, 0, 0, 0, null, true);
					offset.rotateAroundY(Math.PI/5);
					
				}
				
				offset.rotateAroundY(Math.PI/40);
				
				if (timer > 20) {
					
					summonDragon(loc);
					
					cancel();
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}
	
	@Override
	public void spellParticle(Location loc) {
		
		loc.getWorld().spawnParticle(Particle.BLOCK_CRACK, loc, 2, 0, 0, 0, 0, Material.END_STONE.createBlockData(), true);
		
	}
	
	public void summonDragon(Location loc) {
		EnderDragon dragon = (EnderDragon) loc.getWorld().spawnEntity(loc.clone().add(new Vector(0,-10,0)), EntityType.ENDER_DRAGON);
		dragon.setInvulnerable(true);
		
		new BukkitRunnable() {
		
			int timer = 0;
			Vector dir = new Vector(1,2,0).normalize();
			
			@Override
			public void run() {
				
				dragon.setVelocity(new Vector(0,1,0));
				dragon.getLocation().setDirection(dir);
				dir.rotateAroundY(Math.PI/8);
				
				timer++;
				
				if (timer > 50) {
					cancel();
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}

}
