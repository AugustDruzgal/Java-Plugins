package me.August.MechArmor;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class FlameThrower {
	
	FlameThrower(Player player, Plugin plugin) {
		
		Location loc = player.getLocation().clone().add(new Vector(0, 0.75, 0).add(player.getLocation().getDirection().normalize().multiply(0.5)));
		Vector dir = loc.getDirection().clone().add(new Vector(0.15-Math.random()*0.3, 0.45-Math.random()*0.3, 0.15-Math.random()*0.3));
		dir.normalize().multiply(0.6);
		
		new BukkitRunnable() {
			
			int timer = 0;
			
			@Override 
			public void run() {
				
				loc.add(dir);
				dir.normalize().add(new Vector(0,-0.03,0)).normalize().multiply(0.6);
				player.getWorld().spawnParticle(Particle.SMALL_FLAME, loc, 6, 0, 0, 0, 0.007, null, true);
				
				if(!loc.getBlock().isPassable()) {
					
					loc.subtract(dir);
					if(loc.getBlock().isPassable() && !loc.getBlock().isLiquid()) {
						
						loc.getBlock().setType(Material.FIRE);
						player.getWorld().playSound(loc, Sound.BLOCK_BLASTFURNACE_FIRE_CRACKLE, 1, 1);
						timer = 69;
						
					}
					
				}
				
				timer++;
				
				if(timer > 50) {
					
					cancel();
					
				}
				
			}
			
		}.runTaskTimer(plugin, 0, 1);
		
	}

}
